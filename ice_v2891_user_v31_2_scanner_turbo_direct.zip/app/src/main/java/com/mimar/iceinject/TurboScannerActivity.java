package com.mimar.iceinject;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Camera;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.LuminanceSource;
import com.google.zxing.NotFoundException;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Scanner native real-time untuk halaman kerja ICE.
 * Kamera menganalisis frame secara langsung, lalu hasil dikirim ke MainActivity
 * agar diproses melalui bridge scanner website. Aktivitas tidak menekan submit.
 */
@SuppressWarnings("deprecation")
public class TurboScannerActivity extends Activity implements SurfaceHolder.Callback, Camera.PreviewCallback {
    public static final String ACTION_RESULT = "com.mimar.iceinject.TURBO_SCAN_RESULT";
    public static final String ACTION_FEEDBACK = "com.mimar.iceinject.TURBO_SCAN_FEEDBACK";
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_TOKEN = "token";
    public static final String EXTRA_OK = "ok";
    public static final String EXTRA_REASON = "reason";
    public static final String EXTRA_ONE_SHOT = "one_shot";

    private static final long FRAME_GAP_MS = 105L;
    private static final long DUPLICATE_BLOCK_MS = 1800L;
    private static final long AUTO_FOCUS_MS = 1500L;
    private static final long AUTO_ZOOM_AFTER_MS = 2600L;
    private static final long FEEDBACK_TIMEOUT_MS = 3500L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService decoder = Executors.newSingleThreadExecutor();
    private final AtomicBoolean decoding = new AtomicBoolean(false);

    private SurfaceView preview;
    private SurfaceHolder holder;
    private ScanGuideView guide;
    private TextView status;
    private TextView counter;
    private Button flashButton;
    private Button zoomOutButton;
    private Button zoomInButton;
    private Button focusButton;

    private Camera camera;
    private int cameraId = -1;
    private int previewWidth = 0;
    private int previewHeight = 0;
    private int previewFormat = 0;
    private boolean surfaceReady = false;
    private boolean flashOn = false;
    private boolean receiverRegistered = false;
    private boolean oneShotMode = true;
    private long lastFrameAt = 0L;
    private long lastSuccessAt = 0L;
    private long lastAnyDetectionAt = 0L;
    private String lastAcceptedCode = "";
    private String candidateCode = "";
    private int candidateHits = 0;
    private int tokenCounter = 0;
    private int deliveredCount = 0;
    private int failedCount = 0;
    private int pendingToken = 0;
    private String pendingCode = "";
    private byte[] previewBuffer;
    private ToneGenerator tone;

    private final Runnable focusLoop = new Runnable() {
        @Override public void run() {
            if (camera != null) requestAutoFocus(null);
            handler.postDelayed(this, AUTO_FOCUS_MS);
        }
    };

    private final Runnable autoZoomLoop = new Runnable() {
        @Override public void run() {
            long quiet = SystemClock.elapsedRealtime() - Math.max(lastSuccessAt, lastAnyDetectionAt);
            if (camera != null && quiet >= AUTO_ZOOM_AFTER_MS) {
                stepZoom(1, true);
                lastAnyDetectionAt = SystemClock.elapsedRealtime();
            }
            handler.postDelayed(this, 900L);
        }
    };

    private final BroadcastReceiver feedbackReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || !ACTION_FEEDBACK.equals(intent.getAction())) return;
            int token = intent.getIntExtra(EXTRA_TOKEN, 0);
            if (token == 0 || token != pendingToken) return;
            handler.removeCallbacks(feedbackTimeout);
            boolean ok = intent.getBooleanExtra(EXTRA_OK, false);
            String reason = safe(intent.getStringExtra(EXTRA_REASON));
            String code = safe(intent.getStringExtra(EXTRA_CODE));
            pendingToken = 0;
            pendingCode = "";
            if (ok) {
                deliveredCount++;
                showStatus("✓ Langsung diproses website\n" + code, true);
                updateCounter();
                if (oneShotMode) {
                    Intent result = new Intent();
                    result.putExtra(EXTRA_CODE, code);
                    setResult(RESULT_OK, result);
                    handler.postDelayed(new Runnable() {
                        @Override public void run() { finish(); }
                    }, 260L);
                    return;
                }
            } else {
                failedCount++;
                showStatus("Belum terkirim: " + readableReason(reason) + "\nArahkan ulang atau buka menu scan website", false);
            }
            updateCounter();
        }
    };

    private final Runnable feedbackTimeout = new Runnable() {
        @Override public void run() {
            if (pendingToken == 0) return;
            failedCount++;
            showStatus("Scanner website belum memberi respons\nBuka menu scan pada halaman lalu coba lagi", false);
            pendingToken = 0;
            pendingCode = "";
            updateCounter();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Izin kamera belum diberikan", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        oneShotMode = getIntent() == null || getIntent().getBooleanExtra(EXTRA_ONE_SHOT, true);
        try { tone = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 78); } catch (Throwable ignored) {}
        registerFeedbackReceiver();
        buildUi();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        preview = new SurfaceView(this);
        holder = preview.getHolder();
        holder.addCallback(this);
        root.addView(preview, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        guide = new ScanGuideView(this);
        guide.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    requestAutoFocus(new float[] { event.getX(), event.getY(), v.getWidth(), v.getHeight() });
                    showStatus("Memfokuskan area yang disentuh…", false);
                }
                return true;
            }
        });
        root.addView(guide, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(this);
        title.setText(oneShotMode
                ? "ICE SCANNER TURBO\nScan sekali — langsung diproses website"
                : "ICE SCANNER TURBO\nArahkan QR / barcode ke kotak — terbaca otomatis");
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setGravity(Gravity.CENTER);
        title.setPadding(dp(12), dp(10), dp(12), dp(10));
        title.setBackground(rounded(Color.argb(220, 15, 23, 42), dp(14)));
        FrameLayout.LayoutParams titleParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        titleParams.setMargins(dp(14), dp(16), dp(14), 0);
        root.addView(title, titleParams);

        counter = new TextView(this);
        counter.setTextColor(Color.WHITE);
        counter.setTextSize(13);
        counter.setGravity(Gravity.CENTER);
        counter.setPadding(dp(10), dp(7), dp(10), dp(7));
        counter.setBackground(rounded(Color.argb(215, 2, 6, 23), dp(12)));
        FrameLayout.LayoutParams counterParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.RIGHT);
        counterParams.setMargins(0, dp(94), dp(14), 0);
        root.addView(counter, counterParams);
        updateCounter();

        status = new TextView(this);
        status.setText("Membuka kamera…");
        status.setTextColor(Color.WHITE);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(dp(14), dp(10), dp(14), dp(10));
        status.setBackground(rounded(Color.argb(225, 30, 41, 59), dp(14)));
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        statusParams.setMargins(dp(14), 0, dp(14), dp(92));
        root.addView(status, statusParams);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(8), dp(8), dp(8), dp(12));
        controls.setBackgroundColor(Color.argb(235, 2, 6, 23));

        flashButton = button("FLASH", Color.rgb(71, 85, 105));
        flashButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleFlash(); }
        });
        controls.addView(flashButton, buttonParams(1f));

        zoomOutButton = button("ZOOM −", Color.rgb(51, 65, 85));
        zoomOutButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stepZoom(-2, false); }
        });
        controls.addView(zoomOutButton, buttonParams(1f));

        zoomInButton = button("ZOOM +", Color.rgb(51, 65, 85));
        zoomInButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stepZoom(2, false); }
        });
        controls.addView(zoomInButton, buttonParams(1f));

        focusButton = button("FOKUS", Color.rgb(124, 58, 237));
        focusButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestAutoFocus(null); }
        });
        controls.addView(focusButton, buttonParams(1f));

        Button done = button("SELESAI", Color.rgb(22, 163, 74));
        done.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        controls.addView(done, buttonParams(1f));

        FrameLayout.LayoutParams controlParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        root.addView(controls, controlParams);
        setContentView(root);
    }

    private LinearLayout.LayoutParams buttonParams(float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(56), weight);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    private Button button(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(2), 0, dp(2), 0);
        b.setBackground(rounded(color, dp(13)));
        return b;
    }

    @Override protected void onResume() {
        super.onResume();
        if (surfaceReady) openCamera();
    }

    @Override protected void onPause() {
        handler.removeCallbacks(focusLoop);
        handler.removeCallbacks(autoZoomLoop);
        releaseCamera();
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (receiverRegistered) {
            try { unregisterReceiver(feedbackReceiver); } catch (Throwable ignored) {}
            receiverRegistered = false;
        }
        try { decoder.shutdownNow(); } catch (Throwable ignored) {}
        try { if (tone != null) tone.release(); } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Override public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        openCamera();
    }

    @Override public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (camera != null) startPreview();
    }

    @Override public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        releaseCamera();
    }

    private void openCamera() {
        if (!surfaceReady || camera != null) return;
        try {
            cameraId = findBackCamera();
            camera = cameraId >= 0 ? Camera.open(cameraId) : Camera.open();
            camera.setPreviewDisplay(holder);
            configureCamera();
            startPreview();
            handler.removeCallbacks(focusLoop);
            handler.removeCallbacks(autoZoomLoop);
            handler.postDelayed(focusLoop, 450L);
            handler.postDelayed(autoZoomLoop, 1200L);
            lastAnyDetectionAt = SystemClock.elapsedRealtime();
            showStatus("Siap memindai otomatis\nKetuk barcode untuk fokus", false);
        } catch (Throwable error) {
            releaseCamera();
            showStatus("Kamera gagal dibuka: " + safeError(error), false);
        }
    }

    private int findBackCamera() {
        try {
            int count = Camera.getNumberOfCameras();
            Camera.CameraInfo info = new Camera.CameraInfo();
            for (int i = 0; i < count; i++) {
                Camera.getCameraInfo(i, info);
                if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) return i;
            }
        } catch (Throwable ignored) {}
        return -1;
    }

    private void configureCamera() {
        if (camera == null) return;
        Camera.Parameters p = camera.getParameters();

        Camera.Size previewSize = choosePreviewSize(p.getSupportedPreviewSizes());
        if (previewSize != null) p.setPreviewSize(previewSize.width, previewSize.height);

        List<String> focusModes = p.getSupportedFocusModes();
        if (focusModes != null) {
            if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            } else if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
            } else if (focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            }
        }

        List<String> scenes = p.getSupportedSceneModes();
        if (scenes != null && scenes.contains(Camera.Parameters.SCENE_MODE_BARCODE)) {
            p.setSceneMode(Camera.Parameters.SCENE_MODE_BARCODE);
        }
        try {
            if (p.isVideoStabilizationSupported()) p.setVideoStabilization(true);
        } catch (Throwable ignored) {}

        int minExposure = p.getMinExposureCompensation();
        int maxExposure = p.getMaxExposureCompensation();
        if (maxExposure > minExposure) {
            int target = Math.min(maxExposure, Math.max(minExposure, 1));
            try { p.setExposureCompensation(target); } catch (Throwable ignored) {}
        }

        camera.setParameters(p);
        camera.setDisplayOrientation(calculateDisplayOrientation());

        Camera.Size actual = camera.getParameters().getPreviewSize();
        previewWidth = actual.width;
        previewHeight = actual.height;
        previewFormat = camera.getParameters().getPreviewFormat();
    }

    private Camera.Size choosePreviewSize(List<Camera.Size> sizes) {
        if (sizes == null || sizes.isEmpty()) return null;
        Camera.Size best = sizes.get(0);
        double bestScore = Double.MAX_VALUE;
        for (Camera.Size s : sizes) {
            long pixels = (long) s.width * (long) s.height;
            if (pixels > 2300000L) continue;
            double ratio = (double) Math.max(s.width, s.height) / (double) Math.min(s.width, s.height);
            double ratioPenalty = Math.abs(ratio - (16.0 / 9.0)) * 900.0;
            double sizePenalty = Math.abs(Math.max(s.width, s.height) - 1280) * 0.7;
            double score = ratioPenalty + sizePenalty;
            if (score < bestScore) {
                best = s;
                bestScore = score;
            }
        }
        return best;
    }

    private int calculateDisplayOrientation() {
        if (cameraId < 0) return 90;
        try {
            Camera.CameraInfo info = new Camera.CameraInfo();
            Camera.getCameraInfo(cameraId, info);
            int degrees = rotationDegrees();
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                int result = (info.orientation + degrees) % 360;
                return (360 - result) % 360;
            }
            return (info.orientation - degrees + 360) % 360;
        } catch (Throwable ignored) {
            return 90;
        }
    }

    private int rotationDegrees() {
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        if (rotation == Surface.ROTATION_90) return 90;
        if (rotation == Surface.ROTATION_180) return 180;
        if (rotation == Surface.ROTATION_270) return 270;
        return 0;
    }

    private void startPreview() {
        if (camera == null || previewWidth <= 0 || previewHeight <= 0) return;
        try {
            camera.stopPreview();
        } catch (Throwable ignored) {}
        try {
            int bits = android.graphics.ImageFormat.getBitsPerPixel(previewFormat);
            int size = previewWidth * previewHeight * Math.max(bits, 12) / 8;
            previewBuffer = new byte[size + 1024];
            camera.addCallbackBuffer(previewBuffer);
            camera.setPreviewCallbackWithBuffer(this);
            camera.startPreview();
        } catch (Throwable error) {
            showStatus("Preview kamera gagal: " + safeError(error), false);
        }
    }

    private void releaseCamera() {
        Camera c = camera;
        camera = null;
        if (c == null) return;
        try { c.setPreviewCallbackWithBuffer(null); } catch (Throwable ignored) {}
        try { c.cancelAutoFocus(); } catch (Throwable ignored) {}
        try { c.stopPreview(); } catch (Throwable ignored) {}
        try { c.release(); } catch (Throwable ignored) {}
        previewBuffer = null;
    }

    @Override public void onPreviewFrame(final byte[] data, final Camera sourceCamera) {
        if (data == null || sourceCamera == null) return;
        long now = SystemClock.elapsedRealtime();
        if (now - lastFrameAt < FRAME_GAP_MS || decoding.get() || pendingToken != 0) {
            returnBuffer(sourceCamera, data);
            return;
        }
        lastFrameAt = now;
        if (!decoding.compareAndSet(false, true)) {
            returnBuffer(sourceCamera, data);
            return;
        }

        final byte[] copy = data.clone();
        final int w = previewWidth;
        final int h = previewHeight;
        returnBuffer(sourceCamera, data);

        decoder.execute(new Runnable() {
            @Override public void run() {
                String value = "";
                try { value = decodeFrame(copy, w, h); } catch (Throwable ignored) {}
                final String result = safe(value).trim();
                handler.post(new Runnable() {
                    @Override public void run() {
                        decoding.set(false);
                        if (result.length() > 0) handleDecoded(result);
                    }
                });
            }
        });
    }

    private void returnBuffer(Camera c, byte[] data) {
        try { if (camera == c) c.addCallbackBuffer(data); } catch (Throwable ignored) {}
    }

    private String decodeFrame(byte[] data, int width, int height) throws Exception {
        if (width <= 0 || height <= 0) return "";
        int cropWidth = Math.max(120, (int) (width * 0.86f));
        int cropHeight = Math.max(120, (int) (height * 0.62f));
        int left = Math.max(0, (width - cropWidth) / 2);
        int top = Math.max(0, (height - cropHeight) / 2);

        PlanarYUVLuminanceSource source = new PlanarYUVLuminanceSource(
                data, width, height, left, top, cropWidth, cropHeight, false);
        MultiFormatReader reader = new MultiFormatReader();
        reader.setHints(buildHints());
        try {
            String result = tryDecode(reader, source);
            if (result.length() > 0) return result;
            if (source.isRotateSupported()) {
                result = tryDecode(reader, source.rotateCounterClockwise());
                if (result.length() > 0) return result;
            }
            return "";
        } finally {
            reader.reset();
        }
    }

    private EnumMap<DecodeHintType, Object> buildHints() {
        EnumMap<DecodeHintType, Object> hints = new EnumMap<DecodeHintType, Object>(DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Arrays.asList(
                BarcodeFormat.QR_CODE,
                BarcodeFormat.DATA_MATRIX,
                BarcodeFormat.AZTEC,
                BarcodeFormat.PDF_417,
                BarcodeFormat.CODE_128,
                BarcodeFormat.CODE_39,
                BarcodeFormat.ITF,
                BarcodeFormat.EAN_13,
                BarcodeFormat.EAN_8,
                BarcodeFormat.UPC_A,
                BarcodeFormat.UPC_E,
                BarcodeFormat.CODABAR));
        return hints;
    }

    private String tryDecode(MultiFormatReader reader, LuminanceSource source) {
        try {
            Result r = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(source)));
            return r == null ? "" : safe(r.getText());
        } catch (NotFoundException first) {
            reader.reset();
            try {
                Result r = reader.decodeWithState(new BinaryBitmap(new GlobalHistogramBinarizer(source)));
                return r == null ? "" : safe(r.getText());
            } catch (NotFoundException second) {
                reader.reset();
                try {
                    Result r = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(source.invert())));
                    return r == null ? "" : safe(r.getText());
                } catch (Throwable ignored) {
                    return "";
                }
            }
        } finally {
            reader.reset();
        }
    }

    private void handleDecoded(String code) {
        long now = SystemClock.elapsedRealtime();
        lastAnyDetectionAt = now;

        if (code.equals(candidateCode)) candidateHits++;
        else {
            candidateCode = code;
            candidateHits = 1;
        }
        if (candidateHits < 2) {
            showStatus("Barcode terdeteksi — memastikan hasil…", false);
            return;
        }
        candidateHits = 0;
        candidateCode = "";

        if (code.equals(lastAcceptedCode) && now - lastSuccessAt < DUPLICATE_BLOCK_MS) return;
        lastAcceptedCode = code;
        lastSuccessAt = now;
        pendingToken = ++tokenCounter;
        pendingCode = code;

        playSuccessFeedback();
        showStatus("Terbaca: " + code + "\nLangsung memproses di website…", true);
        Intent result = new Intent(ACTION_RESULT);
        result.setPackage(getPackageName());
        result.putExtra(EXTRA_CODE, code);
        result.putExtra(EXTRA_TOKEN, pendingToken);
        sendBroadcast(result);
        handler.removeCallbacks(feedbackTimeout);
        handler.postDelayed(feedbackTimeout, FEEDBACK_TIMEOUT_MS);
    }

    private void playSuccessFeedback() {
        try { if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 110); } catch (Throwable ignored) {}
        try {
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (vibrator != null) vibrator.vibrate(75L);
        } catch (Throwable ignored) {}
    }

    private void requestAutoFocus(float[] point) {
        Camera c = camera;
        if (c == null) return;
        try {
            Camera.Parameters p = c.getParameters();
            if (point != null && point.length >= 4) {
                Rect area = toCameraArea(point[0], point[1], point[2], point[3]);
                if (p.getMaxNumFocusAreas() > 0) {
                    p.setFocusAreas(Arrays.asList(new Camera.Area(area, 1000)));
                }
                if (p.getMaxNumMeteringAreas() > 0) {
                    p.setMeteringAreas(Arrays.asList(new Camera.Area(area, 900)));
                }
            }
            List<String> modes = p.getSupportedFocusModes();
            if (modes != null && modes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                p.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
            }
            c.cancelAutoFocus();
            c.setParameters(p);
            c.autoFocus(new Camera.AutoFocusCallback() {
                @Override public void onAutoFocus(boolean success, Camera camera) {
                    if (success) showStatus("Fokus siap — mencari barcode…", false);
                }
            });
        } catch (Throwable ignored) {}
    }

    private Rect toCameraArea(float x, float y, float viewWidth, float viewHeight) {
        int cx = clamp((int) (x / Math.max(1f, viewWidth) * 2000f - 1000f), -1000, 1000);
        int cy = clamp((int) (y / Math.max(1f, viewHeight) * 2000f - 1000f), -1000, 1000);
        int half = 160;
        return new Rect(clamp(cx - half, -1000, 1000), clamp(cy - half, -1000, 1000),
                clamp(cx + half, -1000, 1000), clamp(cy + half, -1000, 1000));
    }

    private void stepZoom(int amount, boolean automatic) {
        Camera c = camera;
        if (c == null) return;
        try {
            Camera.Parameters p = c.getParameters();
            if (!p.isZoomSupported()) {
                if (!automatic) Toast.makeText(this, "Zoom tidak didukung", Toast.LENGTH_SHORT).show();
                return;
            }
            int current = p.getZoom();
            int max = p.getMaxZoom();
            int target = clamp(current + amount, 0, max);
            if (target == current) return;
            p.setZoom(target);
            c.setParameters(p);
            if (automatic) showStatus("Auto-zoom membantu membaca barcode kecil…", false);
            else showStatus("Zoom " + target + "/" + max, false);
        } catch (Throwable ignored) {}
    }

    private void toggleFlash() {
        Camera c = camera;
        if (c == null) return;
        try {
            Camera.Parameters p = c.getParameters();
            List<String> modes = p.getSupportedFlashModes();
            if (modes == null || !modes.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
                Toast.makeText(this, "Flash tidak didukung kamera ini", Toast.LENGTH_SHORT).show();
                return;
            }
            flashOn = !flashOn;
            p.setFlashMode(flashOn ? Camera.Parameters.FLASH_MODE_TORCH : Camera.Parameters.FLASH_MODE_OFF);
            c.setParameters(p);
            flashButton.setText(flashOn ? "FLASH ON" : "FLASH");
            flashButton.setBackground(rounded(
                    flashOn ? Color.rgb(234, 179, 8) : Color.rgb(71, 85, 105), dp(13)));
        } catch (Throwable error) {
            Toast.makeText(this, "Flash gagal diubah", Toast.LENGTH_SHORT).show();
        }
    }

    private void registerFeedbackReceiver() {
        IntentFilter filter = new IntentFilter(ACTION_FEEDBACK);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(feedbackReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(feedbackReceiver, filter);
            }
            receiverRegistered = true;
        } catch (Throwable ignored) {}
    }

    private void updateCounter() {
        if (counter != null) counter.setText("Terkirim " + deliveredCount + "  •  Gagal " + failedCount);
    }

    private void showStatus(final String message, final boolean success) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (status == null) return;
                status.setText(message);
                status.setBackground(rounded(
                        success ? Color.argb(230, 21, 128, 61) : Color.argb(225, 30, 41, 59), dp(14)));
            }
        });
    }

    private String readableReason(String reason) {
        if ("scanner_not_ready".equals(reason) || "bridge_missing".equals(reason)) return "scanner website belum siap";
        if ("duplicate".equals(reason)) return "kode sama baru saja diproses";
        if ("queue_full".equals(reason)) return "antrean scanner sedang penuh";
        if (reason.length() == 0) return "tidak ada respons";
        return reason;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static String safeError(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        return message == null || message.trim().length() == 0
                ? error.getClass().getSimpleName() : message;
    }

    private static class ScanGuideView extends View {
        private final Paint mask = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint laser = new Paint(Paint.ANTI_ALIAS_FLAG);

        ScanGuideView(Context context) {
            super(context);
            setWillNotDraw(false);
            mask.setColor(Color.argb(115, 0, 0, 0));
            line.setColor(Color.WHITE);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(5f);
            laser.setColor(Color.rgb(34, 197, 94));
            laser.setStrokeWidth(4f);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth();
            float h = getHeight();
            float boxW = w * 0.86f;
            float boxH = Math.min(h * 0.34f, boxW * 0.54f);
            float left = (w - boxW) / 2f;
            float top = (h - boxH) / 2f - h * 0.03f;
            RectF box = new RectF(left, top, left + boxW, top + boxH);

            canvas.drawRect(0, 0, w, box.top, mask);
            canvas.drawRect(0, box.bottom, w, h, mask);
            canvas.drawRect(0, box.top, box.left, box.bottom, mask);
            canvas.drawRect(box.right, box.top, w, box.bottom, mask);

            float c = Math.min(54f, boxW * 0.12f);
            canvas.drawLine(box.left, box.top, box.left + c, box.top, line);
            canvas.drawLine(box.left, box.top, box.left, box.top + c, line);
            canvas.drawLine(box.right, box.top, box.right - c, box.top, line);
            canvas.drawLine(box.right, box.top, box.right, box.top + c, line);
            canvas.drawLine(box.left, box.bottom, box.left + c, box.bottom, line);
            canvas.drawLine(box.left, box.bottom, box.left, box.bottom - c, line);
            canvas.drawLine(box.right, box.bottom, box.right - c, box.bottom, line);
            canvas.drawLine(box.right, box.bottom, box.right, box.bottom - c, line);
            canvas.drawLine(box.left + 18f, box.centerY(), box.right - 18f, box.centerY(), laser);
        }
    }
}
