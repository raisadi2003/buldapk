package com.mimar.iceinject;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;
import android.os.SystemClock;

/**
 * Alarm cadangan untuk membangunkan sinkronisasi ketika OEM menunda thread service.
 * Alarm tidak melakukan request sendiri; request tetap hanya dijalankan service jika
 * Android menyatakan koneksi internet tervalidasi.
 */
public class LicenseHeartbeatReceiver extends BroadcastReceiver {
    private static final int REQUEST_CODE = 289139;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null) return;
        PowerManager.WakeLock shortLock = null;
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                shortLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        context.getPackageName() + ":license-heartbeat");
                shortLock.acquire(15_000L);
            }
            if (LicenseBackgroundService.shouldRun(context)) {
                LicenseBackgroundService.start(context);
                schedule(context, 5_000L);
            } else {
                cancel(context);
            }
        } finally {
            try {
                if (shortLock != null && shortLock.isHeld()) shortLock.release();
            } catch (Throwable ignored) {}
        }
    }

    public static void schedule(Context context, long delayMs) {
        if (context == null || !LicenseBackgroundService.shouldRun(context)) return;
        try {
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarm == null) return;
            PendingIntent pending = pendingIntent(context);
            long trigger = SystemClock.elapsedRealtime() + Math.max(1_000L, delayMs);
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                } else if (Build.VERSION.SDK_INT >= 19) {
                    alarm.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                } else {
                    alarm.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                }
            } catch (Throwable exactDenied) {
                if (Build.VERSION.SDK_INT >= 23) {
                    alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                } else {
                    alarm.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void cancel(Context context) {
        if (context == null) return;
        try {
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarm != null) alarm.cancel(pendingIntent(context));
        } catch (Throwable ignored) {}
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, LicenseHeartbeatReceiver.class);
        intent.setAction("com.mimar.iceinject.action.LICENSE_HEARTBEAT");
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }
}
