package com.mimar.iceinject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.database.Cursor;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.MimeTypeMap;
import android.os.Environment;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;

import org.json.JSONObject;
import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class MainActivity extends Activity {
    // Diganti otomatis saat build admin/user.
    private static final boolean ADMIN_BUILD = true;

    private static final String PREFS = "ice_inject_prefs";
    private static final String PREF_URL = "company_url";
    private static final String PREF_LICENSE_SERVER = "license_server";
    private static final String PREF_LICENSE_KEY = "license_key";
    private static final String PREF_LICENSE_TOKEN = "license_token";
    private static final String PREF_LICENSE_EXPIRY = "license_expiry_ms";
    private static final String PREF_LICENSE_CREATED = "license_created_ms";
    private static final String PREF_LICENSE_DURATION_LABEL = "license_duration_label";
    private static final String PREF_LAST_SERVER_TIME = "last_server_time_ms";
    private static final String PREF_LAST_SERVER_ELAPSED = "last_server_elapsed_ms";
    private static final String PREF_LAST_CHECK = "last_license_check_ms";
    private static final String PREF_DEVICE_ID = "device_id_fallback";
    private static final String PREF_BOOKMARKS = "browser_bookmarks";
    private static final String PREF_DESKTOP_MODE = "desktop_mode";
    private static final String PREF_QR_ACCOUNTS = "saved_qr_accounts";
    private static final String PREF_QR_FOLDERS = "saved_qr_folders";
    private static final String PREF_BATCH_QUEUE = "batch_queue_json";
    private static final String PREF_BATCH_SEEN = "batch_seen_json";
    private static final String PREF_BATCH_SENT = "batch_sent";
    private static final String PREF_BATCH_FAILED = "batch_failed";
    private static final String PREF_BATCH_DUPLICATES = "batch_duplicates";
    private static final String PREF_BATCH_DELAY = "batch_delay_ms";
    private static final String PREF_HU_BUBBLE_HIDDEN = "hu_bubble_hidden";
    private static final String PREF_HU_BUBBLE_X = "hu_bubble_x";
    private static final String PREF_HU_BUBBLE_Y = "hu_bubble_y";

    private static final String DEFAULT_URL = "https://lp4m-lpw.liebrapermana.com";
    private static final String DEFAULT_LICENSE_SERVER = "https://accuracy.fwh.is";
    private static final String APP_VERSION = "2.8.9.1 Admin";
    // Mode kerja: boleh tetap masuk di WiFi lokal tanpa internet jika lisensi sudah pernah valid online.
    // Batas ini tidak memperpanjang masa key; tetap mengikuti expired dari server.
    private static final long OFFLINE_WORK_GRACE_MS = 18L * 60L * 60L * 1000L;
    private static final long LICENSE_CHECK_INTERVAL_MS = 15000L;
    private static final int CAMERA_PERMISSION_REQUEST = 42;
    private static final int LOCATION_PERMISSION_REQUEST = 43;
    private static final int PHOTO_QR_REQUEST = 44;
    private static final int MULTI_PHOTO_QR_REQUEST = 45;
    private static final int IN_APP_PHOTO_QR_REQUEST = 46;
    private static final int DOWNLOAD_PERMISSION_REQUEST = 47;
    private static final int QR_EXPORT_REQUEST = 48;
    private static final int QR_IMPORT_REQUEST = 49;
    private static final String DOWNLOAD_FOLDER = "ICE Download";

    private SharedPreferences preferences;
    private String bridgeScript = "";
    private final Handler handler = new Handler(Looper.getMainLooper());

    private LinearLayout root;
    private LinearLayout tabBar;
    private EditText addressInput;
    private TextView securityIcon;
    private Button reloadButton;
    private Button bookmarkButton;
    private Button tabsButton;
    private Button scanToggleButton;
    private ProgressBar pageProgress;
    private boolean pageLoading = false;
    private FrameLayout webContainer;
    private ImageButton nativeCopyHuButton;
    private LinearLayout findInPageBar;
    private EditText findInPageInput;
    private TextView findInPageCount;
    private WebView findInPageWebView;
    private String findInPageQuery = "";
    private LinearLayout toolsPanel;
    private LinearLayout showToolsBar;
    private EditText codeInput;
    private TextView statusText;
    private TextView callbackBadge;
    private TextView licenseBadge;
    private Button batchManualSendButton;
    private Button batchQueueButton;
    private Dialog batchDialog;
    private EditText batchPasteInput;
    private EditText batchDelayInput;
    private TextView batchStatsText;
    private Button batchStartButton;

    private final List<String> batchQueue = new ArrayList<String>();
    private final LinkedHashMap<String, Boolean> batchSeen = new LinkedHashMap<String, Boolean>();
    private int batchSent = 0;
    private int batchFailed = 0;
    private int batchDuplicates = 0;
    private int batchDelayMs = 800;
    private boolean batchRunning = false;
    private boolean batchPaused = false;
    private boolean batchAwaitingResult = false;
    private boolean batchManualSingleMode = false;
    private boolean batchRestorePausedAfterManual = false;
    private int batchRetryCount = 0;
    private int batchSendToken = 0;

    private final Runnable batchRunnable = new Runnable() {
        @Override
        public void run() {
            processNextBatchCode();
        }
    };

    private final List<TabState> tabs = new ArrayList<TabState>();
    private TabState currentTab;
    private int nextTabNumber = 1;
    private boolean toolsVisible = false;
    private boolean browserStarted = false;
    private boolean licenseUnlocked = ADMIN_BUILD;
    private boolean licenseCheckInProgress = false;

    private String runtimeUsername = "";
    private String runtimeSessionToken = "";
    private long runtimeSessionExpiry = 0L;
    private final Runnable licenseWatchdog = new Runnable() {
        @Override
        public void run() {
            if (!ADMIN_BUILD) {
                if (licenseUnlocked) {
                    // Mode kerja: saat aplikasi dipakai tetap cek server berkala jika internet tersedia.
                    // Jika sedang WiFi lokal tanpa internet, cache aktif diberi toleransi terbatas.
                    validateLicenseAsync(false);
                } else {
                    // sedang terkunci, jangan munculkan dialog berulang.
                }
                handler.postDelayed(this, LICENSE_CHECK_INTERVAL_MS);
            }
        }
    };
    private PermissionRequest pendingPermissionRequest;
    private GeolocationPermissions.Callback pendingGeolocationCallback;
    private String pendingGeolocationOrigin;
    private boolean pendingPhotoCaptureAfterPermission = false;
    private boolean multiPhotoCaptureMode = false;
    private int multiPhotoAdded = 0;
    private int multiPhotoDuplicates = 0;
    private int multiPhotoFailed = 0;
    private File pendingQrPhotoFile;
    private Uri pendingQrPhotoUri;
    private boolean multiPhotoReceiverRegistered = false;

    private final BroadcastReceiver multiPhotoResultReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !MultiPhotoCameraActivity.ACTION_RESULT.equals(intent.getAction())) return;
            String kind = intent.getStringExtra(MultiPhotoCameraActivity.EXTRA_KIND);
            if ("failed".equals(kind)) {
                multiPhotoFailed++;
                return;
            }
            if (!"code".equals(kind)) return;
            String code = intent.getStringExtra(MultiPhotoCameraActivity.EXTRA_CODE);
            code = code == null ? "" : code.trim();
            if (code.length() == 0) return;

            boolean added = addPhotoCodeToBatch(code);
            if (added) multiPhotoAdded++;
            else multiPhotoDuplicates++;

            Intent feedback = new Intent(MultiPhotoCameraActivity.ACTION_FEEDBACK);
            feedback.setPackage(getPackageName());
            feedback.putExtra(MultiPhotoCameraActivity.EXTRA_CODE, code);
            feedback.putExtra(MultiPhotoCameraActivity.EXTRA_ADDED, added);
            feedback.putExtra(MultiPhotoCameraActivity.EXTRA_QUEUE_SIZE, batchQueue.size());
            sendBroadcast(feedback);
        }
    };

    private static class TabState {
        int number;
        WebView webView;
        Button button;
        String title;
        String currentUrl;
        int callbackCount;
        int loadToken;
        boolean destroyed;
        String lastHandoverClipboardSignature = "";
    }

    private static class BookmarkItem {
        String name;
        String url;

        BookmarkItem(String name, String url) {
            this.name = name;
            this.url = url;
        }
    }

    private static class QrAccount {
        String name;
        String qr;
        String folder;

        QrAccount(String name, String qr) {
            this(name, qr, "Akun Utama");
        }

        QrAccount(String name, String qr, String folder) {
            this.name = name;
            this.qr = qr;
            this.folder = folder == null || folder.trim().length() == 0 ? "Akun Utama" : folder.trim();
        }
    }

    private interface ApiCallback {
        void onResult(boolean success, JSONObject data, String error);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Method status = Window.class.getMethod("setStatusBarColor", int.class);
                status.invoke(getWindow(), Color.rgb(32, 33, 36));
                Method navigation = Window.class.getMethod("setNavigationBarColor", int.class);
                navigation.invoke(getWindow(), Color.rgb(32, 33, 36));
            } catch (Throwable ignored) {}
        }

        preferences = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        bridgeScript = readAsset("bridge.js");
        loadBatchState();
        registerMultiPhotoReceiver();

        buildInterface();
        requestCameraPermissionIfNeeded();

        if (ADMIN_BUILD) {
            licenseUnlocked = true;
            setLicenseBadge("ADMIN", Color.rgb(147, 51, 234));
            startBrowserIfNeeded();
        } else {
            // v2.8.0: mode login user/password.
            // Setiap aplikasi dibuka dari awal harus login online lagi. Sesi hanya disimpan di memori saat APK masih hidup.
            licenseUnlocked = false;
            runtimeUsername = "";
            runtimeSessionToken = "";
            runtimeSessionExpiry = 0L;
            setLicenseBadge("LOGIN", Color.rgb(202, 138, 4));
            if (preferences.getString(PREF_LICENSE_SERVER, "").length() == 0) {
                preferences.edit().putString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER).apply();
            }
            preferences.edit()
                    .remove(PREF_LICENSE_TOKEN)
                    .remove(PREF_LICENSE_EXPIRY)
                    .remove(PREF_LICENSE_CREATED)
                    .putLong(PREF_LAST_CHECK, 0L)
                    .apply();
            showActivationDialog(true);
        }
        startLicenseWatchdog();
    }

    private void buildInterface() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(248, 249, 250));

        // Bilah atas bergaya Chrome.
        LinearLayout browserBar = new LinearLayout(this);
        browserBar.setOrientation(LinearLayout.HORIZONTAL);
        browserBar.setGravity(Gravity.CENTER_VERTICAL);
        browserBar.setPadding(dp(8), dp(7), dp(8), dp(7));
        browserBar.setBackground(makeRounded(Color.rgb(20, 25, 35), dp(0)));

        Button homeTop = toolbarButton("⌂");
        homeTop.setContentDescription("Beranda");
        homeTop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        browserBar.addView(homeTop, new LinearLayout.LayoutParams(dp(40), dp(44)));

        LinearLayout addressCapsule = new LinearLayout(this);
        addressCapsule.setOrientation(LinearLayout.HORIZONTAL);
        addressCapsule.setGravity(Gravity.CENTER_VERTICAL);
        addressCapsule.setPadding(dp(10), 0, dp(3), 0);
        addressCapsule.setBackground(makeRoundedStroke(Color.rgb(38, 45, 59), dp(24), Color.rgb(71, 85, 105), dp(1)));

        securityIcon = new TextView(this);
        securityIcon.setText("●");
        securityIcon.setTextColor(Color.rgb(129, 201, 149));
        securityIcon.setTextSize(10);
        securityIcon.setGravity(Gravity.CENTER);
        securityIcon.setContentDescription("Keamanan halaman");
        securityIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPageInfo();
            }
        });
        addressCapsule.addView(securityIcon, new LinearLayout.LayoutParams(dp(24), dp(44)));

        addressInput = new EditText(this);
        addressInput.setSingleLine(true);
        addressInput.setTextColor(Color.WHITE);
        addressInput.setHintTextColor(Color.rgb(189, 193, 198));
        addressInput.setTextSize(14);
        addressInput.setHint("Cari atau ketik alamat");
        addressInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        addressInput.setSelectAllOnFocus(true);
        addressInput.setPadding(dp(2), 0, dp(3), 0);
        addressInput.setBackgroundColor(Color.TRANSPARENT);
        addressInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                navigateAddressBar();
                return true;
            }
        });
        addressCapsule.addView(addressInput, new LinearLayout.LayoutParams(0, dp(44), 1));

        reloadButton = toolbarButton("↻");
        reloadButton.setContentDescription("Muat ulang");
        reloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab == null) return;
                if (pageLoading) {
                    currentTab.webView.stopLoading();
                } else {
                    injectBridge(currentTab);
                    reloadCurrentTabRouted();
                }
            }
        });
        addressCapsule.addView(reloadButton, new LinearLayout.LayoutParams(dp(40), dp(40)));

        LinearLayout.LayoutParams capsuleParams = new LinearLayout.LayoutParams(0, dp(44), 1);
        capsuleParams.setMargins(dp(6), 0, dp(5), 0);
        browserBar.addView(addressCapsule, capsuleParams);

        bookmarkButton = toolbarButton("☆");
        bookmarkButton.setTextSize(20);
        bookmarkButton.setContentDescription("Bookmark");
        bookmarkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleCurrentBookmark();
            }
        });
        browserBar.addView(bookmarkButton, new LinearLayout.LayoutParams(dp(40), dp(44)));

        tabsButton = toolbarButton("1");
        tabsButton.setTextSize(12);
        tabsButton.setBackground(makeRoundedStroke(
                Color.TRANSPARENT, dp(7), Color.rgb(218, 220, 224), dp(1)));
        tabsButton.setContentDescription("Daftar tab");
        tabsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTabsDialog();
            }
        });
        LinearLayout.LayoutParams tabsParams = new LinearLayout.LayoutParams(dp(38), dp(34));
        tabsParams.setMargins(dp(4), 0, 0, 0);
        browserBar.addView(tabsButton, tabsParams);

        Button menuButton = toolbarButton("⋮");
        menuButton.setTextSize(24);
        menuButton.setContentDescription("Menu browser");
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBrowserMenu();
            }
        });
        browserBar.addView(menuButton, new LinearLayout.LayoutParams(dp(40), dp(44)));

        root.addView(browserBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));

        pageProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        pageProgress.setMax(100);
        pageProgress.setProgress(0);
        pageProgress.setVisibility(View.GONE);
        try {
            pageProgress.getProgressDrawable().setColorFilter(
                    Color.rgb(96, 165, 250), PorterDuff.Mode.SRC_IN);
        } catch (Throwable ignored) {}
        root.addView(pageProgress, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(2)));

        // Dipertahankan secara internal untuk kompatibilitas, tetapi tab dibuka lewat tombol jumlah tab.
        tabBar = new LinearLayout(this);
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        tabBar.setVisibility(View.GONE);

        webContainer = new FrameLayout(this);
        webContainer.setBackgroundColor(Color.WHITE);
        root.addView(webContainer, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        // Gelembung HU mengambang: dapat digeser ke seluruh area halaman.
        // Tekan lama untuk membuka menu COPY HU. Visibilitasnya diatur dari menu titik tiga.
        createFloatingHuBubble();

        // Panel alat scan yang bisa disembunyikan tanpa kehilangan tombol untuk membukanya lagi.
        toolsPanel = new LinearLayout(this);
        toolsPanel.setOrientation(LinearLayout.VERTICAL);
        toolsPanel.setPadding(dp(10), dp(8), dp(10), dp(9));
        toolsPanel.setBackground(makeRoundedStroke(Color.rgb(17, 24, 39), dp(24), Color.rgb(51, 65, 85), dp(1)));

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);

        statusText = new TextView(this);
        statusText.setText("ICE Inject siap");
        statusText.setTextColor(Color.rgb(203, 213, 225));
        statusText.setTextSize(12);
        statusText.setSingleLine(true);
        statusRow.addView(statusText, new LinearLayout.LayoutParams(0, dp(34), 1));


        licenseBadge = new TextView(this);
        licenseBadge.setText("LISENSI");
        licenseBadge.setTextColor(Color.WHITE);
        licenseBadge.setTextSize(10);
        licenseBadge.setGravity(Gravity.CENTER);
        licenseBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        licenseBadge.setBackground(makeRounded(Color.rgb(71, 85, 105), dp(14)));
        statusRow.addView(licenseBadge);

        callbackBadge = new TextView(this);
        callbackBadge.setText("CB: 0");
        callbackBadge.setTextColor(Color.WHITE);
        callbackBadge.setTextSize(10);
        callbackBadge.setGravity(Gravity.CENTER);
        callbackBadge.setPadding(dp(8), dp(4), dp(8), dp(4));
        callbackBadge.setBackground(makeRounded(Color.rgb(71, 85, 105), dp(14)));
        LinearLayout.LayoutParams callbackParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        callbackParams.setMargins(dp(5), 0, 0, 0);
        statusRow.addView(callbackBadge, callbackParams);

        Button hideButton = smallButton("Tutup");
        hideButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideTools();
            }
        });
        statusRow.addView(hideButton);
        toolsPanel.addView(statusRow);

        codeInput = new EditText(this);
        codeInput.setHint("Ketik isi QR / barcode");
        codeInput.setSingleLine(true);
        codeInput.setTextSize(17);
        codeInput.setTextColor(Color.WHITE);
        codeInput.setHintTextColor(Color.rgb(148, 163, 184));
        codeInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        codeInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        codeInput.setBackground(makeRounded(Color.rgb(2, 6, 23), dp(10)));
        codeInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                sendCode(true);
                return true;
            }
        });
        toolsPanel.addView(codeInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52)));

        LinearLayout sendRow = new LinearLayout(this);
        sendRow.setOrientation(LinearLayout.HORIZONTAL);
        sendRow.setPadding(0, dp(7), 0, 0);

        Button sendButton = actionButton("Kirim", Color.rgb(37, 99, 235));
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCode(false);
            }
        });
        sendRow.addView(sendButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button sendClearButton = actionButton("Kirim + Kosongkan", Color.rgb(13, 148, 136));
        sendClearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCode(true);
            }
        });
        LinearLayout.LayoutParams clearParams = new LinearLayout.LayoutParams(0, dp(46), 1.45f);
        clearParams.setMargins(dp(7), 0, 0, 0);
        sendRow.addView(sendClearButton, clearParams);

        Button checkButton = actionButton("Cek", Color.rgb(71, 85, 105));
        checkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkScanner();
            }
        });
        LinearLayout.LayoutParams checkParams = new LinearLayout.LayoutParams(0, dp(46), 0.65f);
        checkParams.setMargins(dp(7), 0, 0, 0);
        sendRow.addView(checkButton, checkParams);

        toolsPanel.addView(sendRow);

        Button photoQrButton = actionButton("📷 Foto QR lalu scan", Color.rgb(124, 58, 237));
        photoQrButton.setContentDescription("Buka kamera, foto QR, lalu kirim hasil ke scanner");
        photoQrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startQrPhotoCapture();
            }
        });
        LinearLayout.LayoutParams photoQrParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        photoQrParams.setMargins(0, dp(7), 0, 0);
        toolsPanel.addView(photoQrButton, photoQrParams);

        Button multiPhotoQrButton = actionButton("📸 Jepret Banyak → Antrean", Color.rgb(147, 51, 234));
        multiPhotoQrButton.setContentDescription("Jepret QR berulang, kumpulkan ke antrean, lalu kirim bertahap");
        multiPhotoQrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMultiQrPhotoCapture();
            }
        });
        LinearLayout.LayoutParams multiPhotoQrParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        multiPhotoQrParams.setMargins(0, dp(7), 0, 0);
        toolsPanel.addView(multiPhotoQrButton, multiPhotoQrParams);

        batchManualSendButton = actionButton("Kirim 1 dari antrean", Color.rgb(22, 163, 74));
        batchManualSendButton.setContentDescription("Kirim satu kode pertama dari antrean QR");
        batchManualSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendNextBatchCodeManually();
            }
        });
        LinearLayout.LayoutParams manualBatchParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        manualBatchParams.setMargins(0, dp(7), 0, 0);
        toolsPanel.addView(batchManualSendButton, manualBatchParams);

        batchQueueButton = actionButton("Antrean QR", Color.rgb(234, 88, 12));
        batchQueueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showBatchQueueDialog();
            }
        });
        LinearLayout.LayoutParams batchButtonParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44));
        batchButtonParams.setMargins(0, dp(7), 0, 0);
        toolsPanel.addView(batchQueueButton, batchButtonParams);
        updateBatchUi();

        toolsPanel.setVisibility(View.GONE);
        root.addView(toolsPanel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        // Navigasi bawah: selalu terlihat sehingga panel input bisa dimunculkan lagi kapan saja.
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(5), dp(4), dp(5), dp(4));
        bottomBar.setBackground(makeRounded(Color.rgb(20, 25, 35), dp(0)));

        Button backButton = bottomButton("‹", "Kembali");
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab != null && currentTab.webView.canGoBack()) currentTab.webView.goBack();
            }
        });
        bottomBar.addView(backButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button forwardButton = bottomButton("›", "Maju");
        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab != null && currentTab.webView.canGoForward()) currentTab.webView.goForward();
            }
        });
        bottomBar.addView(forwardButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button homeButton = bottomButton("⌂", "Beranda");
        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goHome();
            }
        });
        bottomBar.addView(homeButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button newTabButton = bottomButton("＋", "Tab baru");
        newTabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!licenseUnlocked) {
                    showActivationDialog(true);
                    return;
                }
                createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
            }
        });
        bottomBar.addView(newTabButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        scanToggleButton = bottomButton("⌨", "Input scanner");
        scanToggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (toolsVisible) hideTools(); else showTools();
            }
        });
        bottomBar.addView(scanToggleButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        root.addView(bottomBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54)));

        // Kompatibilitas field lama; tombol pemuncul kini selalu ada di navigasi bawah.
        showToolsBar = new LinearLayout(this);
        showToolsBar.setVisibility(View.GONE);

        try {
            getWindow().setStatusBarColor(Color.BLACK);
            getWindow().setNavigationBarColor(Color.BLACK);
        } catch (Throwable ignored) {}
        setContentView(root);
    }



    // Kompatibilitas alur lama: permintaan API kini mengikuti jaringan default Android.
    private ApiCallback beginInternetRouteForCallback(final ApiCallback callback) {
        return callback;
    }

    private void finishLicenseCheckRoute() {
        licenseCheckInProgress = false;
    }

    private void loadUrlRouted(final TabState tab, final String rawUrl) {
        if (tab == null || tab.destroyed || tab.webView == null) return;
        final String url = rawUrl == null ? DEFAULT_URL : normalizeUrl(rawUrl);
        tab.currentUrl = url;
        tab.webView.loadUrl(url);
    }

    private void reloadCurrentTabRouted() {
        if (currentTab == null || currentTab.destroyed || currentTab.webView == null) return;
        try {
            currentTab.webView.reload();
        } catch (Throwable ignored) {}
    }

    private void startBrowserIfNeeded() {
        if (browserStarted) return;
        browserStarted = true;
        createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
    }

    private void createNewTab(String url, boolean switchNow) {
        final TabState tab = new TabState();
        tab.number = nextTabNumber++;
        tab.title = "Tab " + tab.number;
        tab.currentUrl = normalizeUrl(url);

        tab.webView = new WebView(this);
        tab.webView.setVisibility(View.GONE);
        configureWebView(tab);
        webContainer.addView(tab.webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        if (nativeCopyHuButton != null) nativeCopyHuButton.bringToFront();

        tab.button = null;
        tabs.add(tab);
        updateTabCount();

        // Tampilkan tab lebih dulu supaya sentuhan terasa langsung, baru mulai memuat halaman.
        if (switchNow) switchToTab(tab);
        loadUrlRouted(tab, tab.currentUrl);
    }


    private void switchToTab(TabState tab) {
        if (tab == null || tab.destroyed) return;

        for (TabState item : tabs) {
            boolean active = item == tab;
            item.webView.setVisibility(active ? View.VISIBLE : View.GONE);
            try {
                if (active) {
                    item.webView.onResume();
                    item.webView.resumeTimers();
                } else {
                    item.webView.onPause();
                    item.webView.pauseTimers();
                }
            } catch (Throwable ignored) {}
        }

        currentTab = tab;
        updateCallbackBadge(tab.callbackCount);
        updateBrowserUi(tab);
        setStatus("Tab " + tab.number + ": " + shortUrl(tab.currentUrl));
    }


    private void closeCurrentTab() {
        if (currentTab == null) return;
        if (tabs.size() <= 1) {
            loadUrlRouted(currentTab, preferences.getString(PREF_URL, DEFAULT_URL));
            return;
        }
        closeTab(currentTab);
    }

    private void closeTab(TabState tab) {
        int index = tabs.indexOf(tab);
        if (index < 0) return;

        tabs.remove(tab);
        webContainer.removeView(tab.webView);
        tab.destroyed = true;
        try { tab.webView.stopLoading(); } catch (Throwable ignored) {}
        try { tab.webView.loadUrl("about:blank"); } catch (Throwable ignored) {}
        try { tab.webView.removeJavascriptInterface("AndroidBridge"); } catch (Throwable ignored) {}
        try { tab.webView.destroy(); } catch (Throwable ignored) {}
        updateTabCount();

        if (tabs.size() == 0) {
            createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
            return;
        }

        int nextIndex = Math.min(index, tabs.size() - 1);
        switchToTab(tabs.get(nextIndex));
    }


    private void configureWebView(final TabState tab) {
        WebSettings settings = tab.webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(true);
        settings.setSupportZoom(true);
        try { settings.setDisplayZoomControls(false); } catch (Throwable ignored) {}
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        try { settings.setGeolocationEnabled(true); } catch (Throwable ignored) {}
        applyDesktopMode(settings);

        tab.webView.setBackgroundColor(Color.WHITE);
        tab.webView.addJavascriptInterface(new AndroidBridge(tab), "AndroidBridge");

        tab.webView.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                                  String mimeType, long contentLength) {
                startIceDownload(url, userAgent, contentDisposition, mimeType, contentLength);
            }
        });

        tab.webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url == null || url.length() == 0) return false;
                loadUrlRouted(tab, url);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                tab.currentUrl = url;
                tab.loadToken++;
                updateTabTitle(tab, shortUrl(url));
                if (tab == currentTab) {
                    updateBrowserUi(tab);
                    setPageProgress(5, true);
                    setStatus("Membuka " + shortUrl(url) + "…");
                }
                scheduleBridgeInjection(tab, tab.loadToken);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                tab.currentUrl = url;
                updateTabTitle(tab, shortUrl(url));
                if (tab == currentTab) {
                    updateBrowserUi(tab);
                    setPageProgress(100, false);
                    setStatus("Halaman siap");
                }
                applyDesktopViewport(view);
                injectBridge(tab);
                scheduleBridgeInjection(tab, tab.loadToken);
            }

            @Override
            public void onLoadResource(WebView view, String url) {
                if (url != null && (url.contains("html5-qrcode") || url.contains("scanner") || url.contains("qrcode"))) {
                    scheduleBridgeInjection(tab, tab.loadToken);
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (tab == currentTab) {
                    setPageProgress(100, false);
                    setStatus("Gagal membuka web: " + description);
                }
            }
        });

        tab.webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (hasCameraPermission()) {
                            request.grant(request.getResources());
                        } else {
                            pendingPermissionRequest = request;
                            requestCameraPermissionIfNeeded();
                        }
                    }
                });
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin,
                                                           final GeolocationPermissions.Callback callback) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (hasLocationPermission()) {
                            callback.invoke(origin, true, false);
                            setStatus("Izin lokasi diberikan.");
                        } else {
                            pendingGeolocationOrigin = origin;
                            pendingGeolocationCallback = callback;
                            requestLocationPermissionIfNeeded();
                        }
                    }
                });
            }

            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (tab == currentTab) {
                    setPageProgress(newProgress, newProgress < 100);
                    if (newProgress < 100) setStatus("Memuat halaman " + newProgress + "%");
                }
            }

            @Override
            public void onReceivedTitle(WebView view, String title) {
                if (title != null && title.trim().length() > 0) {
                    updateTabTitle(tab, title.trim());
                    if (tab == currentTab) updateBrowserUi(tab);
                }
            }
        });
    }


    private void updateTabTitle(final TabState tab, final String value) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String shortValue = value == null ? "Tab " + tab.number : value;
                if (shortValue.length() > 32) shortValue = shortValue.substring(0, 32) + "…";
                tab.title = shortValue;
                if (tab.button != null) tab.button.setText(shortValue);
                updateTabCount();
            }
        });
    }


    private void scheduleBridgeInjection(final TabState tab, final int token) {
        int[] delays = new int[] { 120, 350, 800, 1600, 3200, 6000 };
        for (final int delay : delays) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (tab == null || tab.destroyed || tab.loadToken != token) return;
                    injectBridge(tab);
                }
            }, delay);
        }
    }

    private void injectBridge(TabState tab) {
        if (tab == null || tab.destroyed || tab.webView == null || bridgeScript.length() == 0) return;
        runJavascript(tab.webView, bridgeScript);
    }

    private void sendCode(boolean clearAfter) {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        String code = codeInput == null ? "" : codeInput.getText().toString().trim();
        if (code.length() == 0) {
            Toast.makeText(this, "Isi kode terlebih dahulu", Toast.LENGTH_SHORT).show();
            if (codeInput != null) codeInput.requestFocus();
            return;
        }
        sendCodeValue(code, clearAfter);
    }

    private void sendCodeValue(String code, boolean clearInput) {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (currentTab == null || currentTab.webView == null) {
            setStatus("Tab scanner belum tersedia.");
            return;
        }
        code = code == null ? "" : code.trim();
        if (code.length() == 0) return;

        injectBridge(currentTab);
        String js = "(function(){return window.__LPWScannerBridge?window.__LPWScannerBridge.send(" +
                quoteJs(code) + "):JSON.stringify({ok:false,reason:'bridge_missing'});})();";
        runJavascript(currentTab.webView, js);

        if (codeInput != null) {
            if (clearInput) codeInput.setText("");
            else codeInput.setText(code);
        }
    }


    private void showBatchQueueDialog() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (batchDialog != null && batchDialog.isShowing()) {
            updateBatchUi();
            return;
        }

        final Dialog dialog = new Dialog(this);
        batchDialog = dialog;
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(14), dp(16), dp(16));
        body.setBackgroundColor(Color.rgb(15, 23, 42));
        scroll.addView(body, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Antrean QR massal");
        title.setTextColor(Color.WHITE);
        title.setTextSize(19);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));

        Button close = smallButton("Tutup");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        titleRow.addView(close);
        body.addView(titleRow);

        TextView help = new TextView(this);
        help.setText("Tempel atau scan banyak kode. Satu kode per baris. Kode dikirim bertahap agar WebView tidak freeze.");
        help.setTextColor(Color.rgb(203, 213, 225));
        help.setTextSize(12);
        help.setPadding(0, 0, 0, dp(9));
        body.addView(help);

        batchPasteInput = new EditText(this);
        batchPasteInput.setHint("HU001\nHU002\nHU003");
        batchPasteInput.setTextColor(Color.WHITE);
        batchPasteInput.setHintTextColor(Color.rgb(100, 116, 139));
        batchPasteInput.setTextSize(15);
        batchPasteInput.setGravity(Gravity.TOP | Gravity.LEFT);
        batchPasteInput.setSingleLine(false);
        batchPasteInput.setMinLines(7);
        batchPasteInput.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        batchPasteInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        batchPasteInput.setBackground(makeRounded(Color.rgb(2, 6, 23), dp(10)));
        body.addView(batchPasteInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(170)));

        LinearLayout addRow = new LinearLayout(this);
        addRow.setOrientation(LinearLayout.HORIZONTAL);
        addRow.setPadding(0, dp(8), 0, 0);

        Button addButton = actionButton("Tambah ke antrean", Color.rgb(37, 99, 235));
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addBatchCodes(batchPasteInput == null ? "" : batchPasteInput.getText().toString());
            }
        });
        addRow.addView(addButton, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button pasteButton = actionButton("Tempel", Color.rgb(71, 85, 105));
        pasteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (clipboard != null && clipboard.hasPrimaryClip()) {
                        ClipData clip = clipboard.getPrimaryClip();
                        if (clip != null && clip.getItemCount() > 0) {
                            CharSequence text = clip.getItemAt(0).coerceToText(MainActivity.this);
                            batchPasteInput.setText(text == null ? "" : text.toString());
                        }
                    }
                } catch (Throwable ignored) {}
            }
        });
        LinearLayout.LayoutParams pasteParams = new LinearLayout.LayoutParams(0, dp(46), 0.55f);
        pasteParams.setMargins(dp(7), 0, 0, 0);
        addRow.addView(pasteButton, pasteParams);
        body.addView(addRow);

        batchStatsText = new TextView(this);
        batchStatsText.setTextColor(Color.WHITE);
        batchStatsText.setTextSize(14);
        batchStatsText.setGravity(Gravity.CENTER);
        batchStatsText.setPadding(dp(8), dp(12), dp(8), dp(12));
        batchStatsText.setBackground(makeRounded(Color.rgb(30, 41, 59), dp(10)));
        LinearLayout.LayoutParams statsParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        statsParams.setMargins(0, dp(10), 0, 0);
        body.addView(batchStatsText, statsParams);

        LinearLayout delayRow = new LinearLayout(this);
        delayRow.setOrientation(LinearLayout.HORIZONTAL);
        delayRow.setGravity(Gravity.CENTER_VERTICAL);
        delayRow.setPadding(0, dp(10), 0, 0);

        TextView delayLabel = new TextView(this);
        delayLabel.setText("Jeda tiap kode (ms)");
        delayLabel.setTextColor(Color.rgb(203, 213, 225));
        delayLabel.setTextSize(13);
        delayRow.addView(delayLabel, new LinearLayout.LayoutParams(0, dp(44), 1));

        batchDelayInput = new EditText(this);
        batchDelayInput.setSingleLine(true);
        batchDelayInput.setText(String.valueOf(batchDelayMs));
        batchDelayInput.setTextColor(Color.WHITE);
        batchDelayInput.setGravity(Gravity.CENTER);
        batchDelayInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        batchDelayInput.setBackground(makeRounded(Color.rgb(2, 6, 23), dp(9)));
        delayRow.addView(batchDelayInput, new LinearLayout.LayoutParams(dp(105), dp(44)));
        body.addView(delayRow);

        LinearLayout controlRow = new LinearLayout(this);
        controlRow.setOrientation(LinearLayout.HORIZONTAL);
        controlRow.setPadding(0, dp(8), 0, 0);

        batchStartButton = actionButton("Mulai", Color.rgb(22, 163, 74));
        batchStartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startOrPauseBatch();
            }
        });
        controlRow.addView(batchStartButton, new LinearLayout.LayoutParams(0, dp(48), 1));

        Button resetButton = actionButton("Hapus semua", Color.rgb(220, 38, 38));
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this, R.style.IceDialogTheme)
                        .setTitle("Hapus seluruh antrean?")
                        .setMessage("Daftar, jumlah terkirim, gagal, dan duplikat akan direset.")
                        .setNegativeButton("Batal", null)
                        .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int which) {
                                resetBatchQueue();
                            }
                        })
                        .show();
            }
        });
        LinearLayout.LayoutParams resetParams = new LinearLayout.LayoutParams(0, dp(48), 0.75f);
        resetParams.setMargins(dp(7), 0, 0, 0);
        controlRow.addView(resetButton, resetParams);
        body.addView(controlRow);

        TextView note = new TextView(this);
        note.setText("Saran: gunakan 800–1500 ms untuk 500 kode. Saat halaman reload, antrean otomatis menunggu sampai halaman siap.");
        note.setTextColor(Color.rgb(148, 163, 184));
        note.setTextSize(11);
        note.setPadding(0, dp(10), 0, 0);
        body.addView(note);

        dialog.setContentView(scroll);
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface d) {
                batchDialog = null;
                batchPasteInput = null;
                batchDelayInput = null;
                batchStatsText = null;
                batchStartButton = null;
            }
        });
        dialog.show();
        try {
            Window window = dialog.getWindow();
            if (window != null) {
                window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                window.setBackgroundDrawable(makeRounded(Color.TRANSPARENT, dp(12)));
            }
        } catch (Throwable ignored) {}
        updateBatchUi();
    }

    private void addBatchCodes(String raw) {
        if (raw == null) raw = "";
        String[] lines = raw.split("\\r?\\n");
        int added = 0;
        int duplicates = 0;
        for (String line : lines) {
            String code = line == null ? "" : line.trim();
            if (code.length() == 0) continue;
            if (batchSeen.containsKey(code)) {
                duplicates++;
                continue;
            }
            batchSeen.put(code, true);
            batchQueue.add(code);
            added++;
        }
        batchDuplicates += duplicates;
        persistBatchState();
        if (batchPasteInput != null) batchPasteInput.setText("");
        updateBatchUi();
        Toast.makeText(this,
                "Ditambah " + added + " kode" + (duplicates > 0 ? ", duplikat " + duplicates : ""),
                Toast.LENGTH_SHORT).show();
    }

    private void sendNextBatchCodeManually() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (batchQueue.size() == 0) {
            Toast.makeText(this, "Antrean masih kosong", Toast.LENGTH_SHORT).show();
            updateBatchUi();
            return;
        }
        if (batchManualSingleMode || batchAwaitingResult) {
            Toast.makeText(this, "Satu QR masih sedang dikirim", Toast.LENGTH_SHORT).show();
            return;
        }
        if (batchRunning && !batchPaused) {
            Toast.makeText(this, "Jeda antrean otomatis terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        // Jika antrean otomatis sedang dijeda, setelah satu kiriman manual selesai
        // status jeda dipulihkan dan kode berikutnya tidak ikut terkirim otomatis.
        batchRestorePausedAfterManual = batchRunning && batchPaused;
        batchManualSingleMode = true;
        batchRunning = true;
        batchPaused = false;
        batchRetryCount = 0;
        persistBatchState();
        updateBatchUi();
        setStatus("Mengirim 1 QR dari antrean… sisa " + batchQueue.size() + ".");
        handler.removeCallbacks(batchRunnable);
        handler.postDelayed(batchRunnable, 60);
    }

    private void finishManualBatchAttempt(boolean success, String code, String reason) {
        boolean restorePaused = batchRestorePausedAfterManual && batchQueue.size() > 0;
        batchManualSingleMode = false;
        batchRestorePausedAfterManual = false;
        batchRunning = restorePaused;
        batchPaused = restorePaused;
        batchAwaitingResult = false;
        batchRetryCount = 0;
        handler.removeCallbacks(batchRunnable);
        persistBatchState();
        updateBatchUi();

        if (success) {
            setStatus("1 QR terkirim manual. Sisa " + batchQueue.size() + ".");
            Toast.makeText(this, "1 QR terkirim", Toast.LENGTH_SHORT).show();
        } else {
            String detail = reason == null || reason.length() == 0 ? "gagal diproses" : reason;
            setStatus("Kirim manual gagal (" + detail + "). Kode tetap di antrean.");
            Toast.makeText(this, "Gagal dikirim, kode tetap di antrean", Toast.LENGTH_SHORT).show();
        }
    }

    private void cancelManualBatchSend(String message) {
        if (!batchManualSingleMode) return;
        batchSendToken++;
        batchManualSingleMode = false;
        batchRestorePausedAfterManual = false;
        batchRunning = false;
        batchPaused = false;
        batchAwaitingResult = false;
        batchRetryCount = 0;
        handler.removeCallbacks(batchRunnable);
        persistBatchState();
        updateBatchUi();
        if (message != null && message.length() > 0) setStatus(message);
    }

    private void startOrPauseBatch() {
        if (batchManualSingleMode) {
            Toast.makeText(this, "Tunggu kirim manual selesai", Toast.LENGTH_SHORT).show();
            return;
        }
        if (batchRunning && !batchPaused) {
            batchPaused = true;
            handler.removeCallbacks(batchRunnable);
            updateBatchUi();
            setStatus("Antrean QR dijeda. Sisa " + batchQueue.size() + ".");
            return;
        }
        if (batchQueue.size() == 0) {
            Toast.makeText(this, "Antrean masih kosong", Toast.LENGTH_SHORT).show();
            return;
        }
        if (batchDelayInput != null) {
            try {
                batchDelayMs = Integer.parseInt(batchDelayInput.getText().toString().trim());
            } catch (Throwable ignored) {
                batchDelayMs = 800;
            }
        }
        batchDelayMs = Math.max(250, Math.min(10000, batchDelayMs));
        if (batchDelayInput != null) batchDelayInput.setText(String.valueOf(batchDelayMs));
        batchRunning = true;
        batchPaused = false;
        batchRetryCount = 0;
        persistBatchState();
        updateBatchUi();
        setStatus("Antrean QR berjalan. Sisa " + batchQueue.size() + ".");
        handler.removeCallbacks(batchRunnable);
        handler.postDelayed(batchRunnable, 80);
    }

    private void processNextBatchCode() {
        if (!batchRunning || batchPaused || batchAwaitingResult) return;
        if (batchQueue.size() == 0) {
            finishBatchQueue();
            return;
        }
        if (currentTab == null || currentTab.destroyed || currentTab.webView == null) {
            setStatus("Menunggu tab web aktif…");
            handler.postDelayed(batchRunnable, 700);
            return;
        }
        if (pageLoading) {
            setStatus("Antrean menunggu halaman selesai dimuat…");
            handler.postDelayed(batchRunnable, 500);
            return;
        }

        final String code = batchQueue.get(0);
        final int token = ++batchSendToken;
        batchAwaitingResult = true;
        injectBridge(currentTab);

        final String requestId = "batch:" + token;
        final String js = "(function(){try{" +
                "if(!window.__LPWScannerBridge)return {ok:false,reason:'bridge_missing'};" +
                "var r=window.__LPWScannerBridge.send(" + quoteJs(code) + "," + quoteJs(requestId) + ");" +
                "return typeof r==='string'?JSON.parse(r):r;" +
                "}catch(e){return {ok:false,reason:'js_error'};}})();";

        try {
            currentTab.webView.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    handleBatchEnqueueResult(token, code, value);
                }
            });
        } catch (Throwable error) {
            batchAwaitingResult = false;
            handleBatchFailure(token, code, "evaluate_error");
            return;
        }

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (batchAwaitingResult && token == batchSendToken) {
                    batchAwaitingResult = false;
                    handleBatchFailure(token, code, "delivery_timeout");
                }
            }
        }, 5000);
    }

    private void handleBatchEnqueueResult(int token, String code, String value) {
        if (token != batchSendToken || !batchAwaitingResult) return;
        boolean accepted = false;
        String reason = "unknown";
        try {
            JSONObject result = new JSONObject(value == null ? "{}" : value);
            accepted = result.optBoolean("ok", false);
            reason = result.optString("reason", reason);
        } catch (Throwable ignored) {}
        if (!accepted) {
            batchAwaitingResult = false;
            handleBatchFailure(token, code, reason);
        }
        // Jika diterima bridge, tunggu laporan proses asli dari AndroidBridge.onSendReport().
    }

    private void handleBatchDeliveryReport(int token, String code, boolean ok, String reason) {
        if (token != batchSendToken || !batchAwaitingResult) return;
        batchAwaitingResult = false;
        if (!ok) {
            handleBatchFailure(token, code, reason == null ? "delivery_failed" : reason);
            return;
        }
        if (batchQueue.size() > 0 && code.equals(batchQueue.get(0))) batchQueue.remove(0);
        else batchQueue.remove(code);
        batchSent++;
        batchRetryCount = 0;

        if (batchManualSingleMode) {
            finishManualBatchAttempt(true, code, "");
            return;
        }

        persistBatchState();
        updateBatchUi();
        setStatus("QR terkirim " + batchSent + ". Sisa " + batchQueue.size() + ".");
        if (batchQueue.size() == 0) {
            finishBatchQueue();
        } else if (batchRunning && !batchPaused) {
            handler.postDelayed(batchRunnable, batchDelayMs);
        }
    }

    private void handleBatchFailure(int token, String code, String reason) {
        if (token != batchSendToken) return;
        if (batchManualSingleMode) {
            batchFailed++;
            finishManualBatchAttempt(false, code, reason);
            return;
        }
        if (batchPaused || !batchRunning) {
            batchAwaitingResult = false;
            batchRetryCount = 0;
            persistBatchState();
            updateBatchUi();
            setStatus("Antrean QR dijeda. Kode akan dicoba lagi saat dilanjutkan.");
            return;
        }
        batchRetryCount++;
        boolean retryable = "bridge_missing".equals(reason)
                || "queue_full".equals(reason)
                || "duplicate".equals(reason)
                || "timeout".equals(reason)
                || "delivery_timeout".equals(reason)
                || "delivery_failed".equals(reason)
                || "scanner_not_ready".equals(reason)
                || "evaluate_error".equals(reason)
                || "unknown".equals(reason);

        if (retryable && batchRetryCount <= 8 && batchRunning && !batchPaused) {
            if (currentTab != null) injectBridge(currentTab);
            setStatus("Menunggu scanner siap… percobaan " + batchRetryCount + "/8");
            long retryDelay = "queue_full".equals(reason) ? 450
                    : ("duplicate".equals(reason) ? 1250 : 800);
            handler.postDelayed(batchRunnable, retryDelay);
            return;
        }

        if (batchQueue.size() > 0 && code.equals(batchQueue.get(0))) batchQueue.remove(0);
        else batchQueue.remove(code);
        batchFailed++;
        batchRetryCount = 0;
        persistBatchState();
        updateBatchUi();
        setStatus("Satu kode gagal dilewati. Gagal " + batchFailed + ", sisa " + batchQueue.size() + ".");
        if (batchQueue.size() == 0) finishBatchQueue();
        else if (batchRunning && !batchPaused) handler.postDelayed(batchRunnable, batchDelayMs);
    }

    private void finishBatchQueue() {
        batchRunning = false;
        batchPaused = false;
        batchAwaitingResult = false;
        batchManualSingleMode = false;
        batchRestorePausedAfterManual = false;
        batchRetryCount = 0;
        handler.removeCallbacks(batchRunnable);
        persistBatchState();
        updateBatchUi();
        setStatus("Antrean QR selesai. Terkirim " + batchSent + ", gagal " + batchFailed + ".");
        Toast.makeText(this,
                "Antrean selesai: " + batchSent + " terkirim, " + batchFailed + " gagal",
                Toast.LENGTH_LONG).show();
    }

    private void resetBatchQueue() {
        batchRunning = false;
        batchPaused = false;
        batchAwaitingResult = false;
        batchManualSingleMode = false;
        batchRestorePausedAfterManual = false;
        batchRetryCount = 0;
        batchSendToken++;
        handler.removeCallbacks(batchRunnable);
        batchQueue.clear();
        batchSeen.clear();
        batchSent = 0;
        batchFailed = 0;
        batchDuplicates = 0;
        persistBatchState();
        updateBatchUi();
        setStatus("Antrean QR sudah dihapus.");
    }

    private void loadBatchState() {
        batchQueue.clear();
        batchSeen.clear();
        batchSent = preferences.getInt(PREF_BATCH_SENT, 0);
        batchFailed = preferences.getInt(PREF_BATCH_FAILED, 0);
        batchDuplicates = preferences.getInt(PREF_BATCH_DUPLICATES, 0);
        batchDelayMs = Math.max(250, preferences.getInt(PREF_BATCH_DELAY, 800));
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_BATCH_QUEUE, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String code = array.optString(i, "").trim();
                if (code.length() > 0) batchQueue.add(code);
            }
        } catch (Throwable ignored) {}
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_BATCH_SEEN, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String code = array.optString(i, "").trim();
                if (code.length() > 0) batchSeen.put(code, true);
            }
        } catch (Throwable ignored) {}
        for (String code : batchQueue) batchSeen.put(code, true);
    }

    private void persistBatchState() {
        JSONArray queueJson = new JSONArray();
        for (String code : batchQueue) queueJson.put(code);
        JSONArray seenJson = new JSONArray();
        for (String code : batchSeen.keySet()) seenJson.put(code);
        preferences.edit()
                .putString(PREF_BATCH_QUEUE, queueJson.toString())
                .putString(PREF_BATCH_SEEN, seenJson.toString())
                .putInt(PREF_BATCH_SENT, batchSent)
                .putInt(PREF_BATCH_FAILED, batchFailed)
                .putInt(PREF_BATCH_DUPLICATES, batchDuplicates)
                .putInt(PREF_BATCH_DELAY, batchDelayMs)
                .apply();
    }

    private void updateBatchUi() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (batchManualSendButton != null) {
                    boolean autoBusy = batchRunning && !batchPaused && !batchManualSingleMode;
                    boolean canSendOne = batchQueue.size() > 0
                            && !batchManualSingleMode
                            && !batchAwaitingResult
                            && !autoBusy;
                    if (batchManualSingleMode || batchAwaitingResult) {
                        batchManualSendButton.setText("Mengirim 1 QR…");
                    } else if (batchQueue.size() > 0) {
                        batchManualSendButton.setText("Kirim 1 dari antrean • sisa " + batchQueue.size());
                    } else {
                        batchManualSendButton.setText("Kirim 1 • antrean kosong");
                    }
                    batchManualSendButton.setEnabled(canSendOne);
                    batchManualSendButton.setAlpha(canSendOne ? 1.0f : 0.55f);
                }
                if (batchQueueButton != null) {
                    batchQueueButton.setText(batchQueue.size() > 0
                            ? "Antrean QR • sisa " + batchQueue.size()
                            : "Antrean QR");
                }
                if (batchStatsText != null) {
                    batchStatsText.setText("Sisa: " + batchQueue.size()
                            + "   •   Terkirim: " + batchSent
                            + "\nGagal: " + batchFailed
                            + "   •   Duplikat: " + batchDuplicates);
                }
                if (batchStartButton != null) {
                    if (batchRunning && !batchPaused) batchStartButton.setText("Jeda");
                    else if (batchRunning && batchPaused) batchStartButton.setText("Lanjutkan");
                    else batchStartButton.setText("Mulai");
                }
            }
        });
    }

    private void checkScanner() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (currentTab == null) return;

        injectBridge(currentTab);
        runJavascript(currentTab.webView,
                "(function(){return window.__LPWScannerBridge?window.__LPWScannerBridge.status():JSON.stringify({bridge:false});})();");
        setStatus("Memeriksa scanner pada tab ini…");
    }

    private void runJavascript(WebView view, String script) {
        if (view == null) return;
        try {
            Method method = WebView.class.getMethod(
                    "evaluateJavascript",
                    String.class,
                    Class.forName("android.webkit.ValueCallback"));
            method.invoke(view, script, null);
        } catch (Throwable ignored) {
            view.loadUrl("javascript:" + script);
        }
    }

    private void hideTools() {
        toolsVisible = false;
        if (toolsPanel != null) toolsPanel.setVisibility(View.GONE);
        if (showToolsBar != null) showToolsBar.setVisibility(View.GONE);
        if (scanToggleButton != null) {
            scanToggleButton.setText("⌨");
            scanToggleButton.setTextColor(Color.WHITE);
        }
    }


    private void showTools() {
        toolsVisible = true;
        if (toolsPanel != null) toolsPanel.setVisibility(View.VISIBLE);
        if (showToolsBar != null) showToolsBar.setVisibility(View.GONE);
        if (scanToggleButton != null) {
            scanToggleButton.setText("⌨");
            scanToggleButton.setTextColor(Color.rgb(138, 180, 248));
        }
        if (codeInput != null) codeInput.requestFocus();
    }


    private void showUrlDialog() {
        showHomeUrlDialog();
    }



    private Button toolbarButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.rgb(232, 234, 237));
        button.setTextSize(18);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(0, 0, 0, 0);
        button.setBackground(resolveSelectableBackground(true));
        button.setStateListAnimator(null);
        applyPressFeedback(button);
        return button;
    }

    private Button bottomButton(String text, String description) {
        Button button = toolbarButton(text);
        button.setTextSize(24);
        button.setContentDescription(description);
        return button;
    }

    private android.graphics.drawable.Drawable resolveSelectableBackground(boolean borderless) {
        try {
            android.util.TypedValue value = new android.util.TypedValue();
            int attr = borderless ? android.R.attr.selectableItemBackgroundBorderless : android.R.attr.selectableItemBackground;
            getTheme().resolveAttribute(attr, value, true);
            return getResources().getDrawable(value.resourceId);
        } catch (Throwable ignored) {
            return makeRounded(Color.TRANSPARENT, dp(18));
        }
    }

    private GradientDrawable makeRoundedStroke(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = makeRounded(color, radius);
        drawable.setStroke(strokeWidth, strokeColor);
        return drawable;
    }

    private void navigateAddressBar() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (currentTab == null || addressInput == null) return;

        String value = addressInput.getText().toString().trim();
        if (value.length() == 0) return;

        String url;
        if (value.indexOf(' ') >= 0 && value.indexOf('.') < 0) {
            try {
                url = "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8");
            } catch (Throwable ignored) {
                url = normalizeUrl(value);
            }
        } else {
            url = normalizeUrl(value);
        }

        addressInput.clearFocus();
        loadUrlRouted(currentTab, url);
    }

    private void goHome() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        String home = preferences.getString(PREF_URL, DEFAULT_URL);
        if (currentTab == null) createNewTab(home, true);
        else loadUrlRouted(currentTab, home);
    }

    private void updateBrowserUi(final TabState tab) {
        if (tab == null) return;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String url = tab.currentUrl == null ? "" : tab.currentUrl;
                if (addressInput != null && !addressInput.hasFocus()) addressInput.setText(url);
                if (securityIcon != null) {
                    if (url.startsWith("https://")) {
                        securityIcon.setText("●");
                        securityIcon.setTextColor(Color.rgb(129, 201, 149));
                    } else {
                        securityIcon.setText("!");
                        securityIcon.setTextColor(Color.rgb(242, 139, 130));
                    }
                }
                if (bookmarkButton != null) {
                    bookmarkButton.setText(isBookmarked(url) ? "★" : "☆");
                    bookmarkButton.setTextColor(isBookmarked(url)
                            ? Color.rgb(251, 188, 4)
                            : Color.rgb(232, 234, 237));
                }
                updateTabCount();
            }
        });
    }

    private void setPageProgress(final int progress, final boolean loading) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                pageLoading = loading;
                if (pageProgress != null) {
                    pageProgress.setProgress(Math.max(0, Math.min(100, progress)));
                    pageProgress.setVisibility(loading ? View.VISIBLE : View.GONE);
                }
                if (reloadButton != null) reloadButton.setText(loading ? "×" : "↻");
            }
        });
    }

    private void updateTabCount() {
        if (tabsButton != null) tabsButton.setText(String.valueOf(Math.max(1, tabs.size())));
    }

    private List<BookmarkItem> loadBookmarks() {
        List<BookmarkItem> list = new ArrayList<BookmarkItem>();
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_BOOKMARKS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String name = item.optString("name", "Bookmark").trim();
                String url = normalizeUrl(item.optString("url", ""));
                if (url.length() == 0) continue;
                if (name.length() == 0) name = shortUrl(url);
                // Hindari bookmark ganda akibat garis miring atau fragment URL.
                boolean duplicate = false;
                for (BookmarkItem saved : list) {
                    if (bookmarkKey(saved.url).equals(bookmarkKey(url))) {
                        duplicate = true;
                        break;
                    }
                }
                if (!duplicate) list.add(new BookmarkItem(name, url));
            }
        } catch (Throwable ignored) {}
        return list;
    }

    private void saveBookmarks(List<BookmarkItem> list) {
        JSONArray array = new JSONArray();
        try {
            for (BookmarkItem item : list) {
                JSONObject object = new JSONObject();
                object.put("name", item.name == null ? "Bookmark" : item.name.trim());
                object.put("url", normalizeUrl(item.url));
                array.put(object);
            }
        } catch (Throwable ignored) {}
        preferences.edit().putString(PREF_BOOKMARKS, array.toString()).apply();
    }

    private String bookmarkKey(String url) {
        if (url == null) return "";
        String value = normalizeUrl(url).trim();
        int hash = value.indexOf('#');
        if (hash >= 0) value = value.substring(0, hash);
        while (value.endsWith("/") && value.length() > 9) {
            value = value.substring(0, value.length() - 1);
        }
        return value.toLowerCase(Locale.US);
    }

    private int bookmarkIndex(String url) {
        String key = bookmarkKey(url);
        List<BookmarkItem> list = loadBookmarks();
        for (int i = 0; i < list.size(); i++) {
            if (key.equals(bookmarkKey(list.get(i).url))) return i;
        }
        return -1;
    }

    private boolean isBookmarked(String url) {
        return bookmarkIndex(url) >= 0;
    }

    private void toggleCurrentBookmark() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        List<BookmarkItem> list = loadBookmarks();
        String key = bookmarkKey(currentTab.currentUrl);
        int index = -1;
        for (int i = 0; i < list.size(); i++) {
            if (key.equals(bookmarkKey(list.get(i).url))) {
                index = i;
                break;
            }
        }

        if (index >= 0) {
            list.remove(index);
            saveBookmarks(list);
            Toast.makeText(this, "Bookmark dihapus", Toast.LENGTH_SHORT).show();
        } else {
            String name = currentTab.title == null || currentTab.title.trim().length() == 0
                    ? shortUrl(currentTab.currentUrl)
                    : currentTab.title.trim();
            list.add(new BookmarkItem(name, normalizeUrl(currentTab.currentUrl)));
            saveBookmarks(list);
            Toast.makeText(this, "Bookmark disimpan", Toast.LENGTH_SHORT).show();
        }
        updateBrowserUi(currentTab);
    }

    private void showBookmarksDialog() {
        final List<BookmarkItem> bookmarks = loadBookmarks();
        final LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(8), dp(12), dp(12));

        final AlertDialog[] dialogRef = new AlertDialog[1];

        Button addCurrent = actionButton("＋ Simpan halaman aktif", Color.rgb(37, 99, 235));
        addCurrent.setEnabled(currentTab != null && currentTab.currentUrl != null);
        addCurrent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentTab != null) toggleCurrentBookmark();
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                handler.postDelayed(new Runnable() {
                    @Override public void run() { showBookmarksDialog(); }
                }, 80);
            }
        });
        content.addView(addCurrent, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        if (bookmarks.size() == 0) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada bookmark. Tekan tombol di atas untuk menyimpan halaman aktif.");
            empty.setTextColor(Color.rgb(71, 85, 105));
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(28), dp(12), dp(28));
            content.addView(empty);
        } else {
            for (int i = 0; i < bookmarks.size(); i++) {
                final int index = i;
                final BookmarkItem item = bookmarks.get(i);

                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(12), dp(10), dp(12), dp(10));
                card.setBackground(makeRounded(Color.rgb(241, 245, 249), dp(12)));
                LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                cardParams.setMargins(0, dp(10), 0, 0);

                TextView name = new TextView(this);
                name.setText(item.name);
                name.setTextColor(Color.rgb(15, 23, 42));
                name.setTextSize(15);
                name.setSingleLine(true);
                name.setPadding(dp(2), 0, dp(2), 0);
                card.addView(name, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(28)));

                TextView url = new TextView(this);
                url.setText(shortUrl(item.url));
                url.setTextColor(Color.rgb(100, 116, 139));
                url.setTextSize(12);
                url.setSingleLine(true);
                url.setPadding(dp(2), 0, dp(2), dp(6));
                card.addView(url, new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, dp(30)));

                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.HORIZONTAL);

                Button open = actionButton("Buka", Color.rgb(37, 99, 235));
                open.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                        if (currentTab == null) createNewTab(item.url, true);
                        else loadUrlRouted(currentTab, item.url);
                    }
                });
                actions.addView(open, new LinearLayout.LayoutParams(0, dp(46), 1));

                Button newTab = actionButton("Tab baru", Color.rgb(13, 148, 136));
                newTab.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                        createNewTab(item.url, true);
                    }
                });
                LinearLayout.LayoutParams actionParams = new LinearLayout.LayoutParams(0, dp(46), 1);
                actionParams.setMargins(dp(6), 0, 0, 0);
                actions.addView(newTab, actionParams);

                Button edit = actionButton("Edit", Color.rgb(71, 85, 105));
                edit.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                        showBookmarkEditor(index);
                    }
                });
                LinearLayout.LayoutParams editParams = new LinearLayout.LayoutParams(0, dp(46), .78f);
                editParams.setMargins(dp(6), 0, 0, 0);
                actions.addView(edit, editParams);

            Button delete = actionButton("Hapus", Color.rgb(185, 28, 28));
                delete.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        List<BookmarkItem> latest = loadBookmarks();
                        if (index >= 0 && index < latest.size()) {
                            latest.remove(index);
                            saveBookmarks(latest);
                        }
                        if (dialogRef[0] != null) dialogRef[0].dismiss();
                        updateBrowserUi(currentTab);
                        handler.postDelayed(new Runnable() {
                            @Override public void run() { showBookmarksDialog(); }
                        }, 80);
                    }
                });
                LinearLayout.LayoutParams deleteParams = new LinearLayout.LayoutParams(0, dp(46), .9f);
                deleteParams.setMargins(dp(6), 0, 0, 0);
                actions.addView(delete, deleteParams);

                card.addView(actions);
                content.addView(card, cardParams);
            }
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);

        AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Bookmark (" + bookmarks.size() + ")")
                .setView(scroll)
                .setNegativeButton("Tutup", null)
                .create();
        dialogRef[0] = dialog;
        dialog.show();
    }

    private void showBookmarkEditor(final int index) {
        final List<BookmarkItem> bookmarks = loadBookmarks();
        if (index < 0 || index >= bookmarks.size()) return;
        final BookmarkItem item = bookmarks.get(index);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(6), dp(20), 0);

        final EditText name = new EditText(this);
        name.setHint("Nama bookmark");
        name.setSingleLine(true);
        name.setText(item.name);
        layout.addView(name);

        final EditText url = new EditText(this);
        url.setHint("URL");
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(item.url);
        layout.addView(url);

        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Edit bookmark")
                .setView(layout)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newUrl = normalizeUrl(url.getText().toString());
                        String newName = name.getText().toString().trim();
                        if (newName.length() == 0) newName = shortUrl(newUrl);
                        item.name = newName;
                        item.url = newUrl;
                        bookmarks.set(index, item);
                        saveBookmarks(bookmarks);
                        updateBrowserUi(currentTab);
                        handler.postDelayed(new Runnable() {
                            @Override public void run() { showBookmarksDialog(); }
                        }, 80);
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void showTabsDialog() {
        final LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(8), dp(12), dp(12));
        final AlertDialog[] dialogRef = new AlertDialog[1];

        Button add = actionButton("＋ Tab baru", Color.rgb(37, 99, 235));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true);
            }
        });
        content.addView(add, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(50)));

        for (final TabState tab : new ArrayList<TabState>(tabs)) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(10), dp(8), dp(8), dp(8));
            card.setBackground(makeRounded(
                    tab == currentTab ? Color.rgb(219, 234, 254) : Color.rgb(241, 245, 249),
                    dp(12)));
            LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(78));
            cardParams.setMargins(0, dp(9), 0, 0);

            LinearLayout textArea = new LinearLayout(this);
            textArea.setOrientation(LinearLayout.VERTICAL);
            textArea.setGravity(Gravity.CENTER_VERTICAL);
            textArea.setPadding(dp(4), 0, dp(8), 0);

            TextView title = new TextView(this);
            title.setText((tab == currentTab ? "● " : "") + tab.title);
            title.setTextColor(Color.rgb(15, 23, 42));
            title.setTextSize(15);
            title.setSingleLine(true);
            textArea.addView(title, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(30)));

            TextView url = new TextView(this);
            url.setText(shortUrl(tab.currentUrl));
            url.setTextColor(Color.rgb(100, 116, 139));
            url.setTextSize(12);
            url.setSingleLine(true);
            textArea.addView(url, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(28)));

            textArea.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    switchToTab(tab);
                }
            });
            card.addView(textArea, new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.MATCH_PARENT, 1));

            Button close = actionButton("×", Color.rgb(185, 28, 28));
            close.setTextSize(22);
            close.setEnabled(tabs.size() > 1);
            close.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (tabs.size() <= 1) return;
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    closeTab(tab);
                }
            });
            LinearLayout.LayoutParams closeParams = new LinearLayout.LayoutParams(dp(58), dp(58));
            closeParams.setMargins(dp(6), 0, 0, 0);
            card.addView(close, closeParams);
            content.addView(card, cardParams);
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);

        AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Tab terbuka: " + tabs.size())
                .setView(scroll)
                .setNegativeButton("Tutup", null)
                .create();
        dialogRef[0] = dialog;
        dialog.show();
    }

    private void createFloatingHuBubble() {
        nativeCopyHuButton = new ImageButton(this);
        nativeCopyHuButton.setImageResource(R.drawable.icon_bubble);
        nativeCopyHuButton.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        if (Build.VERSION.SDK_INT >= 21) nativeCopyHuButton.setClipToOutline(true);
        nativeCopyHuButton.setPadding(0, 0, 0, 0);
        nativeCopyHuButton.setBackground(makeRounded(Color.rgb(11, 18, 30), dp(29)));
        nativeCopyHuButton.setElevation(dp(12));
        nativeCopyHuButton.setContentDescription("Gelembung menu ICE. Tekan lama untuk membuka menu dan geser untuk memindahkan.");

        final int bubbleSize = dp(58);
        final int touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        final float[] downRaw = new float[2];
        final float[] startPos = new float[2];
        final boolean[] moved = new boolean[1];
        final boolean[] menuOpened = new boolean[1];
        final Runnable[] longPress = new Runnable[1];

        nativeCopyHuButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(final View view, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRaw[0] = event.getRawX();
                        downRaw[1] = event.getRawY();
                        startPos[0] = view.getX();
                        startPos[1] = view.getY();
                        moved[0] = false;
                        menuOpened[0] = false;
                        view.setPressed(true);
                        longPress[0] = new Runnable() {
                            @Override public void run() {
                                if (!moved[0] && view.isPressed()) {
                                    menuOpened[0] = true;
                                    view.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS);
                                    showFloatingHuMenu();
                                }
                            }
                        };
                        handler.postDelayed(longPress[0], ViewConfiguration.getLongPressTimeout());
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRaw[0];
                        float dy = event.getRawY() - downRaw[1];
                        if (!moved[0] && (Math.abs(dx) > touchSlop || Math.abs(dy) > touchSlop)) {
                            moved[0] = true;
                            if (longPress[0] != null) handler.removeCallbacks(longPress[0]);
                        }
                        if (moved[0]) {
                            float maxX = Math.max(0, webContainer.getWidth() - view.getWidth());
                            float maxY = Math.max(0, webContainer.getHeight() - view.getHeight());
                            view.setX(Math.max(0, Math.min(startPos[0] + dx, maxX)));
                            view.setY(Math.max(0, Math.min(startPos[1] + dy, maxY)));
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        view.setPressed(false);
                        if (longPress[0] != null) handler.removeCallbacks(longPress[0]);
                        if (moved[0]) {
                            preferences.edit()
                                    .putFloat(PREF_HU_BUBBLE_X, view.getX())
                                    .putFloat(PREF_HU_BUBBLE_Y, view.getY())
                                    .apply();
                        } else if (!menuOpened[0] && event.getActionMasked() == MotionEvent.ACTION_UP) {
                        }
                        return true;
                }
                return false;
            }
        });

        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(bubbleSize, bubbleSize);
        params.gravity = Gravity.TOP | Gravity.START;
        webContainer.addView(nativeCopyHuButton, params);

        webContainer.post(new Runnable() {
            @Override public void run() {
                float savedX = preferences.getFloat(PREF_HU_BUBBLE_X, -1f);
                float savedY = preferences.getFloat(PREF_HU_BUBBLE_Y, -1f);
                float defaultX = Math.max(0, webContainer.getWidth() - nativeCopyHuButton.getWidth() - dp(14));
                float defaultY = Math.max(0, (webContainer.getHeight() - nativeCopyHuButton.getHeight()) * 0.55f);
                float maxX = Math.max(0, webContainer.getWidth() - nativeCopyHuButton.getWidth());
                float maxY = Math.max(0, webContainer.getHeight() - nativeCopyHuButton.getHeight());
                nativeCopyHuButton.setX(Math.max(0, Math.min(savedX >= 0 ? savedX : defaultX, maxX)));
                nativeCopyHuButton.setY(Math.max(0, Math.min(savedY >= 0 ? savedY : defaultY, maxY)));
                applyHuBubbleVisibility();
                nativeCopyHuButton.bringToFront();
            }
        });
    }

    private void showFloatingHuMenu() {
        final String[] items = new String[] { "Cari di halaman", "COPY HU" };
        showModernMenu("Menu ICE", items, Gravity.CENTER, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                if (which == 0) showFindInPageBar();
                else if (which == 1) copyHandoverHuFromCurrentPage();
            }
        });
    }

    private void showFindInPageDialog() {
        showFindInPageBar();
    }

    private void showFindInPageBar() {
        if (currentTab == null || currentTab.webView == null) {
            Toast.makeText(this, "Halaman belum tersedia", Toast.LENGTH_SHORT).show();
            return;
        }
        findInPageWebView = currentTab.webView;
        if (findInPageBar == null) createFindInPageBar();
        findInPageWebView.setFindListener(new WebView.FindListener() {
            @Override public void onFindResultReceived(int active, int total, boolean done) {
                if (!done || findInPageCount == null) return;
                findInPageCount.setText(total <= 0 ? "0 / 0" : ((active + 1) + " / " + total));
            }
        });
        findInPageBar.setVisibility(View.VISIBLE);
        findInPageBar.bringToFront();
        findInPageInput.requestFocus();
        findInPageInput.postDelayed(new Runnable() {
            @Override public void run() {
                ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                        .showSoftInput(findInPageInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
            }
        }, 120);
    }

    private void createFindInPageBar() {
        findInPageBar = new LinearLayout(this);
        findInPageBar.setOrientation(LinearLayout.HORIZONTAL);
        findInPageBar.setGravity(Gravity.CENTER_VERTICAL);
        findInPageBar.setPadding(dp(10), dp(5), dp(8), dp(5));
        findInPageBar.setBackground(makeRounded(Color.rgb(20, 27, 38), dp(18)));
        findInPageBar.setElevation(dp(14));

        findInPageInput = new EditText(this);
        findInPageInput.setSingleLine(true);
        findInPageInput.setHint("Cari di halaman");
        findInPageInput.setHintTextColor(Color.rgb(148, 163, 184));
        findInPageInput.setTextColor(Color.WHITE);
        findInPageInput.setTextSize(16);
        findInPageInput.setPadding(dp(12), 0, dp(8), 0);
        findInPageInput.setBackgroundColor(Color.TRANSPARENT);
        findInPageInput.setSelectAllOnFocus(false);
        findInPageBar.addView(findInPageInput, new LinearLayout.LayoutParams(0, dp(44), 1));

        findInPageCount = new TextView(this);
        findInPageCount.setText("0 / 0");
        findInPageCount.setTextColor(Color.rgb(226, 232, 240));
        findInPageCount.setTextSize(12);
        findInPageCount.setGravity(Gravity.CENTER);
        findInPageBar.addView(findInPageCount, new LinearLayout.LayoutParams(dp(58), dp(44)));

        ImageButton prev = compactFindIconButton(android.R.drawable.arrow_up_float, "Hasil sebelumnya");
        ImageButton next = compactFindIconButton(android.R.drawable.arrow_down_float, "Hasil berikutnya");
        ImageButton close = compactFindIconButton(android.R.drawable.ic_menu_close_clear_cancel, "Tutup pencarian");
        findInPageBar.addView(prev, new LinearLayout.LayoutParams(dp(44), dp(44)));
        findInPageBar.addView(next, new LinearLayout.LayoutParams(dp(44), dp(44)));
        findInPageBar.addView(close, new LinearLayout.LayoutParams(dp(44), dp(44)));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(56));
        lp.gravity = Gravity.TOP;
        lp.setMargins(dp(12), dp(10), dp(12), 0);
        webContainer.addView(findInPageBar, lp);

        findInPageInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence text, int st, int before, int count) {
                findInPageQuery = text == null ? "" : text.toString().trim();
                if (findInPageWebView == null) return;
                if (findInPageQuery.length() == 0) {
                    findInPageWebView.clearMatches();
                    findInPageCount.setText("0 / 0");
                } else findInPageWebView.findAllAsync(findInPageQuery);
            }
            @Override public void afterTextChanged(android.text.Editable e) {}
        });
        prev.setOnClickListener(new View.OnClickListener(){ @Override public void onClick(View v){ if(findInPageWebView!=null && findInPageQuery.length()>0) findInPageWebView.findNext(false); }});
        next.setOnClickListener(new View.OnClickListener(){ @Override public void onClick(View v){ if(findInPageWebView!=null && findInPageQuery.length()>0) findInPageWebView.findNext(true); }});
        close.setOnClickListener(new View.OnClickListener(){ @Override public void onClick(View v){ hideFindInPageBar(); }});
    }

    private ImageButton compactFindIconButton(int iconRes, String description) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(iconRes);
        b.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
        b.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        b.setPadding(dp(11), dp(11), dp(11), dp(11));
        b.setBackground(makeRounded(Color.TRANSPARENT, dp(22)));
        b.setContentDescription(description);
        return b;
    }

    private void hideFindInPageBar() {
        if (findInPageWebView != null) findInPageWebView.clearMatches();
        if (findInPageBar != null) findInPageBar.setVisibility(View.GONE);
        if (findInPageInput != null) findInPageInput.clearFocus();
        ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(webContainer.getWindowToken(), 0);
    }

    private void applyHuBubbleVisibility() {
        if (nativeCopyHuButton == null) return;
        boolean hidden = preferences.getBoolean(PREF_HU_BUBBLE_HIDDEN, false);
        nativeCopyHuButton.setVisibility(hidden ? View.GONE : View.VISIBLE);
        if (!hidden) nativeCopyHuButton.bringToFront();
    }

    private void toggleHuBubbleVisibility() {
        boolean willHide = !preferences.getBoolean(PREF_HU_BUBBLE_HIDDEN, false);
        preferences.edit().putBoolean(PREF_HU_BUBBLE_HIDDEN, willHide).apply();
        applyHuBubbleVisibility();
        Toast.makeText(this, willHide ? "Gelembung HU disembunyikan" : "Gelembung HU ditampilkan", Toast.LENGTH_SHORT).show();
    }

    private void startIceDownload(String url, String userAgent, String contentDisposition,
                                  String mimeType, long contentLength) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            Toast.makeText(this, "Tautan unduhan ini belum didukung", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
            fileName = sanitizeDownloadFileName(fileName);
            if (mimeType == null || mimeType.trim().length() == 0) {
                String extension = MimeTypeMap.getFileExtensionFromUrl(url);
                mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            }
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(fileName);
            request.setDescription("Mengunduh ke Download/" + DOWNLOAD_FOLDER);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(true);
            if (mimeType != null && mimeType.length() > 0) request.setMimeType(mimeType);
            if (userAgent != null && userAgent.length() > 0) request.addRequestHeader("User-Agent", userAgent);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null && cookies.length() > 0) request.addRequestHeader("Cookie", cookies);
            String referer = currentTab == null ? null : currentTab.currentUrl;
            if (referer != null && referer.length() > 0) request.addRequestHeader("Referer", referer);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    DOWNLOAD_FOLDER + "/" + fileName);
            DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            long id = manager.enqueue(request);
            preferences.edit().putLong("last_download_id", id).apply();
            Toast.makeText(this, "Download dimulai\nDownload/" + DOWNLOAD_FOLDER + "/" + fileName,
                    Toast.LENGTH_LONG).show();
        } catch (Throwable error) {
            Toast.makeText(this, "Download gagal dimulai: " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String sanitizeDownloadFileName(String name) {
        if (name == null || name.trim().length() == 0) name = "file_" + System.currentTimeMillis();
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        if (name.length() > 120) name = name.substring(0, 120);
        return name;
    }

    private void showDownloadsDialog() {
        final DownloadManager manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(10), dp(6), dp(10), dp(12));

        final ScrollView scroll = new ScrollView(this);
        scroll.addView(list);
        final AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Unduhan ICE")
                .setView(scroll)
                .setPositiveButton("Tutup", null)
                .create();

        final Handler liveHandler = new Handler(Looper.getMainLooper());
        final Runnable[] updater = new Runnable[1];
        updater[0] = new Runnable() {
            @Override public void run() {
                if (!dialog.isShowing()) return;
                renderDownloadsList(list, manager, dialog);
                liveHandler.postDelayed(this, 500L);
            }
        };

        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface d) {
                if (dialog.getWindow() != null) dialog.getWindow().setLayout(dp(350), dp(600));
                renderDownloadsList(list, manager, dialog);
                liveHandler.postDelayed(updater[0], 500L);
            }
        });
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) {
                liveHandler.removeCallbacks(updater[0]);
            }
        });
        dialog.show();
    }

    private void renderDownloadsList(LinearLayout list, final DownloadManager manager, final AlertDialog parentDialog) {
        list.removeAllViews();
        Cursor cursor = null;
        int shown = 0;
        String lastGroup = null;
        try {
            DownloadManager.Query query = new DownloadManager.Query();
            query.setFilterByStatus(DownloadManager.STATUS_PENDING | DownloadManager.STATUS_RUNNING |
                    DownloadManager.STATUS_PAUSED | DownloadManager.STATUS_SUCCESSFUL | DownloadManager.STATUS_FAILED);
            cursor = manager.query(query);
            if (cursor != null && cursor.moveToLast()) {
                do {
                    final long id = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
                    String originalTitle = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE));
                    final int status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                    final long done = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                    final long total = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                    final String localUri = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
                    long modified = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP));
                    final String savedPath = preferences.getString("download_path_" + id, null);
                    final String title = preferences.getString("download_name_" + id,
                            originalTitle == null ? "File unduhan" : originalTitle);

                    String group = downloadDateGroup(modified);
                    if (!group.equals(lastGroup)) {
                        TextView header = new TextView(this);
                        header.setText(group);
                        header.setTextColor(Color.rgb(203, 213, 225));
                        header.setTextSize(13);
                        header.setTypeface(null, android.graphics.Typeface.BOLD);
                        header.setPadding(dp(4), dp(12), dp(4), dp(6));
                        list.addView(header, new LinearLayout.LayoutParams(-1, -2));
                        lastGroup = group;
                    }

                    LinearLayout card = new LinearLayout(this);
                    card.setOrientation(LinearLayout.VERTICAL);
                    card.setPadding(dp(14), dp(11), dp(14), dp(11));
                    card.setBackground(makeRounded(Color.rgb(31, 41, 55), dp(16)));

                    LinearLayout top = new LinearLayout(this);
                    top.setOrientation(LinearLayout.HORIZONTAL);
                    top.setGravity(Gravity.CENTER_VERTICAL);
                    TextView name = new TextView(this);
                    name.setText(title);
                    name.setTextColor(Color.WHITE);
                    name.setTextSize(15);
                    name.setSingleLine(true);
                    name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                    name.setTypeface(null, android.graphics.Typeface.BOLD);
                    top.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));

                    TextView more = new TextView(this);
                    more.setText("⋮");
                    more.setTextColor(Color.rgb(203, 213, 225));
                    more.setTextSize(25);
                    more.setGravity(Gravity.CENTER);
                    more.setPadding(dp(10), 0, dp(2), 0);
                    top.addView(more, new LinearLayout.LayoutParams(dp(42), dp(38)));
                    card.addView(top, new LinearLayout.LayoutParams(-1, -2));

                    final int percent = total > 0 ? (int)Math.max(0, Math.min(100, (done * 100L) / total)) : 0;
                    if (status == DownloadManager.STATUS_RUNNING || status == DownloadManager.STATUS_PENDING ||
                            status == DownloadManager.STATUS_PAUSED) {
                        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
                        progress.setMax(100);
                        progress.setProgress(percent);
                        progress.setIndeterminate(total <= 0 && status != DownloadManager.STATUS_PAUSED);
                        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(5));
                        pp.setMargins(0, dp(7), 0, dp(4));
                        card.addView(progress, pp);
                    }

                    TextView info = new TextView(this);
                    info.setText(downloadStatusText(status, done, total) + "  •  " + downloadRelativeTime(modified));
                    info.setTextColor(status == DownloadManager.STATUS_FAILED
                            ? Color.rgb(248, 113, 113) : Color.rgb(148, 163, 184));
                    info.setTextSize(12);
                    info.setPadding(0, dp(3), 0, 0);
                    card.addView(info, new LinearLayout.LayoutParams(-1, -2));

                    View.OnClickListener actions = new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            showDownloadActions(manager, id, title, status, localUri, savedPath, parentDialog);
                        }
                    };
                    more.setOnClickListener(actions);
                    card.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override public boolean onLongClick(View v) {
                            showDownloadActions(manager, id, title, status, localUri, savedPath, parentDialog);
                            return true;
                        }
                    });
                    if (status == DownloadManager.STATUS_SUCCESSFUL) {
                        card.setOnClickListener(new View.OnClickListener() {
                            @Override public void onClick(View v) {
                                openDownloadedFile(manager, id, localUri, savedPath);
                            }
                        });
                    }

                    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
                    cp.setMargins(0, dp(3), 0, dp(7));
                    list.addView(card, cp);
                    shown++;
                    if (shown >= 50) break;
                } while (cursor.moveToPrevious());
            }
        } catch (Throwable error) {
            TextView msg = new TextView(this);
            msg.setText("Gagal membaca daftar unduhan: " + error.getMessage());
            msg.setTextColor(Color.WHITE);
            msg.setPadding(dp(12), dp(12), dp(12), dp(12));
            list.addView(msg);
        } finally {
            if (cursor != null) cursor.close();
        }

        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada unduhan.\nFile akan disimpan otomatis ke Download/" + DOWNLOAD_FOLDER);
            empty.setTextColor(Color.rgb(203, 213, 225));
            empty.setTextSize(14);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(18), dp(38), dp(18), dp(38));
            list.addView(empty);
        }
    }

    private void showDownloadActions(final DownloadManager manager, final long id, final String title,
                                     final int status, final String localUri, final String savedPath,
                                     final AlertDialog parentDialog) {
        ArrayList<String> options = new ArrayList<String>();
        if (status == DownloadManager.STATUS_SUCCESSFUL) options.add("Buka");
        if (status == DownloadManager.STATUS_SUCCESSFUL) options.add("Ganti nama");
        options.add("Hapus");
        final String[] items = options.toArray(new String[options.size()]);
        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle(title)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        String action = items[which];
                        if ("Buka".equals(action)) {
                            openDownloadedFile(manager, id, localUri, savedPath);
                        } else if ("Ganti nama".equals(action)) {
                            showRenameDownloadDialog(id, title, localUri, savedPath);
                        } else if ("Hapus".equals(action)) {
                            confirmDeleteDownload(manager, id, title, localUri, savedPath);
                        }
                    }
                }).show();
    }

    private void showRenameDownloadDialog(final long id, final String oldName,
                                          final String localUri, final String savedPath) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(oldName);
        input.setSelection(0, oldName.lastIndexOf('.') > 0 ? oldName.lastIndexOf('.') : oldName.length());
        int pad = dp(20);
        FrameLayout box = new FrameLayout(this);
        box.setPadding(pad, dp(4), pad, 0);
        box.addView(input, new FrameLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Ganti nama file")
                .setView(box)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        renameDownloadedFile(id, oldName, input.getText().toString(), localUri, savedPath);
                    }
                }).show();
    }

    private void renameDownloadedFile(long id, String oldName, String requestedName,
                                      String localUri, String savedPath) {
        try {
            String newName = sanitizeDownloadFileName(requestedName);
            if (newName.length() == 0) throw new IllegalArgumentException("Nama tidak boleh kosong");
            if (!newName.contains(".") && oldName.lastIndexOf('.') > 0) {
                newName += oldName.substring(oldName.lastIndexOf('.'));
            }
            File oldFile = resolveDownloadedFile(localUri, savedPath);
            if (oldFile == null || !oldFile.exists()) throw new IllegalStateException("File tidak ditemukan");
            File newFile = new File(oldFile.getParentFile(), newName);
            if (newFile.exists()) throw new IllegalStateException("Nama file sudah digunakan");
            if (!oldFile.renameTo(newFile)) throw new IllegalStateException("File gagal diganti nama");
            preferences.edit()
                    .putString("download_name_" + id, newName)
                    .putString("download_path_" + id, newFile.getAbsolutePath())
                    .apply();
            Toast.makeText(this, "Nama file berhasil diubah", Toast.LENGTH_SHORT).show();
        } catch (Throwable error) {
            Toast.makeText(this, "Gagal mengganti nama: " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void confirmDeleteDownload(final DownloadManager manager, final long id, final String title,
                                       final String localUri, final String savedPath) {
        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Hapus unduhan?")
                .setMessage(title + " akan dihapus dari daftar dan penyimpanan.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        try {
                            File file = resolveDownloadedFile(localUri, savedPath);
                            if (file != null && file.exists()) file.delete();
                            manager.remove(id);
                            preferences.edit().remove("download_name_" + id)
                                    .remove("download_path_" + id).apply();
                            Toast.makeText(MainActivity.this, "Unduhan dihapus", Toast.LENGTH_SHORT).show();
                        } catch (Throwable error) {
                            Toast.makeText(MainActivity.this, "Gagal menghapus: " + error.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                }).show();
    }

    private File resolveDownloadedFile(String localUri, String savedPath) {
        if (savedPath != null && savedPath.length() > 0) return new File(savedPath);
        if (localUri != null) {
            Uri uri = Uri.parse(localUri);
            if ("file".equalsIgnoreCase(uri.getScheme())) return new File(uri.getPath());
        }
        return null;
    }

    private String downloadStatusText(int status, long done, long total) {
        if (status == DownloadManager.STATUS_SUCCESSFUL) return "Selesai";
        if (status == DownloadManager.STATUS_FAILED) return "Gagal";
        if (status == DownloadManager.STATUS_PAUSED) {
            if (total > 0) return "Dijeda • " + Math.max(0, (done * 100L) / total) + "%";
            return "Dijeda";
        }
        if (status == DownloadManager.STATUS_PENDING) return "Menunggu";
        if (total > 0) return "Mengunduh • " + Math.max(0, (done * 100L) / total) + "%";
        return "Mengunduh";
    }

    private String downloadDateGroup(long time) {
        if (time <= 0) return "Tanggal tidak diketahui";
        java.util.Calendar now = java.util.Calendar.getInstance();
        java.util.Calendar value = java.util.Calendar.getInstance();
        value.setTimeInMillis(time);
        if (sameCalendarDay(now, value)) return "Hari ini";
        now.add(java.util.Calendar.DAY_OF_YEAR, -1);
        if (sameCalendarDay(now, value)) return "Kemarin";
        return new SimpleDateFormat("dd MMMM yyyy", new Locale("id", "ID")).format(new Date(time));
    }

    private boolean sameCalendarDay(java.util.Calendar a, java.util.Calendar b) {
        return a.get(java.util.Calendar.ERA) == b.get(java.util.Calendar.ERA)
                && a.get(java.util.Calendar.YEAR) == b.get(java.util.Calendar.YEAR)
                && a.get(java.util.Calendar.DAY_OF_YEAR) == b.get(java.util.Calendar.DAY_OF_YEAR);
    }

    private String downloadRelativeTime(long time) {
        if (time <= 0) return "waktu tidak diketahui";
        long diff = Math.max(0L, System.currentTimeMillis() - time);
        if (diff < 60_000L) return "baru saja";
        if (diff < 3_600_000L) return (diff / 60_000L) + " menit lalu";
        java.util.Calendar now = java.util.Calendar.getInstance();
        java.util.Calendar value = java.util.Calendar.getInstance();
        value.setTimeInMillis(time);
        if (sameCalendarDay(now, value)) {
            return "hari ini, " + new SimpleDateFormat("HH:mm", new Locale("id", "ID")).format(new Date(time));
        }
        return new SimpleDateFormat("dd MMM yyyy, HH:mm", new Locale("id", "ID")).format(new Date(time));
    }

    private void openDownloadedFile(DownloadManager manager, long id, String localUri, String savedPath) {
        try {
            Uri uri;
            File overrideFile = resolveDownloadedFile(localUri, savedPath);
            if (savedPath != null && overrideFile != null && overrideFile.exists()) {
                uri = QrPhotoProvider.getDownloadUriForFile(this, overrideFile);
            } else {
                uri = manager.getUriForDownloadedFile(id);
                if (uri == null && localUri != null) uri = Uri.parse(localUri);
            }
            if (uri == null) throw new IllegalStateException("Lokasi file tidak tersedia");
            String mime = manager.getMimeTypeForDownloadedFile(id);
            if ((mime == null || mime.length() == 0) && overrideFile != null) {
                String extension = MimeTypeMap.getFileExtensionFromUrl(overrideFile.getName());
                mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
            }
            Intent open = new Intent(Intent.ACTION_VIEW);
            open.setDataAndType(uri, mime == null ? "*/*" : mime);
            open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(open, "Buka file dengan"));
        } catch (Throwable error) {
            Toast.makeText(this, "Tidak ada aplikasi yang dapat membuka file ini", Toast.LENGTH_LONG).show();
        }
    }

    private void showBrowserMenu() {
        final String bookmarkAction = currentTab != null && isBookmarked(currentTab.currentUrl)
                ? "★   Hapus bookmark" : "☆   Bookmark halaman";
        final String desktopAction = isDesktopModeEnabled() ? "▣   Mode desktop: ON" : "▣   Mode desktop: OFF";
        final String[] items = new String[] {
                "＋   Tab baru", "▦   Daftar tab", "★   Bookmark", bookmarkAction,
                "▤   Akun QR tersimpan", "⌂   Beranda", "↻   Muat ulang", "↓   Unduhan",
                "▣   Salin URL", "⌯   Bagikan halaman", desktopAction, "⌂   Atur URL beranda",
                ADMIN_BUILD ? "⚙   Panel KEY admin" : "ⓘ   Info lisensi",
                "🦊   Buka dengan mesin Firefox",
                preferences.getBoolean(PREF_HU_BUBBLE_HIDDEN, false)
                        ? "◉   Tampilkan gelembung" : "⊘   Sembunyikan gelembung"
        };
        showModernMenu("Menu ICE", items, Gravity.TOP | Gravity.END, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: createNewTab(preferences.getString(PREF_URL, DEFAULT_URL), true); break;
                    case 1: showTabsDialog(); break;
                    case 2: showBookmarksDialog(); break;
                    case 3: toggleCurrentBookmark(); break;
                    case 4: showQrAccountsDialog(); break;
                    case 5: goHome(); break;
                    case 6: if (currentTab != null) reloadCurrentTabRouted(); break;
                    case 7: showDownloadsDialog(); break;
                    case 8: copyCurrentUrl(); break;
                    case 9: shareCurrentPage(); break;
                    case 10: toggleDesktopMode(); break;
                    case 11: showHomeUrlDialog(); break;
                    case 12: if (ADMIN_BUILD) openAdminPanel(); else showLicenseInfoDialog(); break;
                    case 13: openCurrentPageInGecko(); break;
                    case 14: toggleHuBubbleVisibility(); break;
                }
            }
        });
    }

    private void openCurrentPageInGecko() {
        try {
            String url = currentTab != null && currentTab.currentUrl != null
                    ? currentTab.currentUrl : preferences.getString(PREF_URL, DEFAULT_URL);
            Intent intent = new Intent(this, GeckoBrowserActivity.class);
            intent.putExtra("initial_url", url);
            startActivity(intent);
        } catch (Throwable error) {
            Toast.makeText(this, "Mesin Firefox gagal dibuka: " + error.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void showModernMenu(String title, final String[] items, int gravity,
                                final DialogInterface.OnClickListener listener) {
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(8), dp(10), dp(10));
        panel.setBackground(makeRoundedStroke(Color.rgb(15, 23, 42), dp(22), Color.rgb(51, 65, 85), dp(1)));

        TextView heading = new TextView(this);
        heading.setText(title);
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(18);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setPadding(dp(10), dp(5), dp(10), dp(7));
        panel.addView(heading, new LinearLayout.LayoutParams(-1, dp(46)));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);

        for (int i = 0; i < items.length; i++) {
            final int index = i;
            final String label = cleanMenuLabel(items[i]);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), 0, dp(8), 0);
            row.setBackground(makeRounded(Color.TRANSPARENT, dp(12)));

            FrameLayout iconBox = new FrameLayout(this);
            iconBox.setBackground(makeRounded(Color.rgb(30, 41, 59), dp(10)));
            ImageView icon = new ImageView(this);
            icon.setImageResource(menuIconFor(label));
            int iconColor = label.contains("Unduhan") ? Color.rgb(59, 130, 246) : Color.rgb(226, 232, 240);
            icon.setColorFilter(iconColor);
            icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
            iconBox.addView(icon, new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
            row.addView(iconBox, new LinearLayout.LayoutParams(dp(38), dp(38)));

            TextView text = new TextView(this);
            text.setText(label);
            text.setTextColor(label.contains("Unduhan") ? Color.rgb(96, 165, 250) : Color.rgb(241, 245, 249));
            text.setTextSize(15);
            text.setGravity(Gravity.CENTER_VERTICAL);
            text.setPadding(dp(12), 0, 0, 0);
            row.addView(text, new LinearLayout.LayoutParams(0, dp(44), 1));

            applyPressFeedback(row);

            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    dialog.dismiss();
                    listener.onClick(null, index);
                }
            });
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(48));
            rp.setMargins(0, dp(1), 0, dp(1));
            rows.addView(row, rp);
        }

        scroll.addView(rows);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        dialog.setContentView(panel);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawableResource(android.R.color.transparent);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams a = w.getAttributes();
            a.dimAmount = 0.25f;
            a.gravity = gravity;
            a.width = Math.min(dp(330), getResources().getDisplayMetrics().widthPixels - dp(36));
            a.height = gravity == Gravity.CENTER ? WindowManager.LayoutParams.WRAP_CONTENT :
                    Math.min(dp(610), getResources().getDisplayMetrics().heightPixels - dp(120));
            if ((gravity & Gravity.TOP) != 0) a.y = dp(58);
            if ((gravity & Gravity.END) != 0) a.x = dp(12);
            w.setAttributes(a);
        }
        dialog.show();
        if (w != null) w.setAttributes(w.getAttributes());
    }

    private String cleanMenuLabel(String raw) {
        if (raw == null) return "";
        return raw.replaceFirst("^[^\\p{L}\\p{N}]+\\s*", "").trim();
    }

    private int menuIconFor(String label) {
        String value = label == null ? "" : label.toLowerCase(new Locale("id", "ID"));
        if (value.contains("tab baru")) return android.R.drawable.ic_input_add;
        if (value.contains("daftar tab")) return android.R.drawable.ic_menu_agenda;
        if (value.contains("bookmark")) return android.R.drawable.btn_star_big_off;
        if (value.contains("akun qr")) return android.R.drawable.ic_menu_myplaces;
        if (value.contains("beranda") && value.contains("atur")) return android.R.drawable.ic_menu_manage;
        if (value.equals("beranda")) return android.R.drawable.ic_menu_view;
        if (value.contains("muat ulang")) return android.R.drawable.ic_popup_sync;
        if (value.contains("unduhan")) return android.R.drawable.stat_sys_download_done;
        if (value.contains("salin url")) return android.R.drawable.ic_menu_set_as;
        if (value.contains("bagikan")) return android.R.drawable.ic_menu_share;
        if (value.contains("desktop")) return android.R.drawable.ic_menu_manage;
        if (value.contains("lisensi")) return android.R.drawable.ic_menu_info_details;
        if (value.contains("panel key")) return android.R.drawable.ic_menu_manage;
        if (value.contains("mesin firefox")) return android.R.drawable.ic_menu_compass;
        if (value.contains("gelembung")) return android.R.drawable.ic_menu_close_clear_cancel;
        return android.R.drawable.ic_menu_more;
    }


    private List<QrAccount> loadQrAccounts() {
        List<QrAccount> result = new ArrayList<QrAccount>();
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_QR_ACCOUNTS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                String name = item.optString("name", "").trim();
                String qr = item.optString("qr", "").trim();
                String folder = item.optString("folder", "Akun Utama").trim();
                if (qr.length() == 0) continue;
                if (name.length() == 0) name = "Akun " + (result.size() + 1);
                if (folder.length() == 0) folder = "Akun Utama";
                result.add(new QrAccount(name, qr, folder));
            }
        } catch (Throwable ignored) {}
        return result;
    }

    private void saveQrAccounts(List<QrAccount> accounts) {
        JSONArray array = new JSONArray();
        try {
            for (QrAccount account : accounts) {
                JSONObject item = new JSONObject();
                item.put("name", account.name == null ? "" : account.name);
                item.put("qr", account.qr == null ? "" : account.qr);
                item.put("folder", account.folder == null ? "Akun Utama" : account.folder);
                array.put(item);
            }
        } catch (Throwable ignored) {}
        preferences.edit().putString(PREF_QR_ACCOUNTS, array.toString()).apply();
    }

    private List<String> loadQrFolders() {
        List<String> folders = new ArrayList<String>();
        folders.add("Akun Utama");
        try {
            JSONArray array = new JSONArray(preferences.getString(PREF_QR_FOLDERS, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String folder = array.optString(i, "").trim();
                if (folder.length() > 0 && !folders.contains(folder)) folders.add(folder);
            }
        } catch (Throwable ignored) {}
        for (QrAccount account : loadQrAccounts()) {
            if (!folders.contains(account.folder)) folders.add(account.folder);
        }
        return folders;
    }

    private void saveQrFolders(List<String> folders) {
        JSONArray array = new JSONArray();
        for (String folder : folders) {
            if (folder == null) continue;
            folder = folder.trim();
            if (folder.length() == 0 || "Akun Utama".equals(folder)) continue;
            array.put(folder);
        }
        preferences.edit().putString(PREF_QR_FOLDERS, array.toString()).apply();
    }

    private int countAccountsInFolder(String folder) {
        int count = 0;
        for (QrAccount account : loadQrAccounts()) if (folder.equals(account.folder)) count++;
        return count;
    }

    private void showQrAccountsDialog() {
        final List<String> folders = loadQrFolders();
        final AlertDialog[] dialogRef = new AlertDialog[1];
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(8), dp(14), dp(14));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        Button addFolder = actionButton("＋ Folder", Color.rgb(37, 99, 235));
        addFolder.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                showQrFolderEditor();
            }
        });
        top.addView(addFolder, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button addAccount = actionButton("＋ Akun", Color.rgb(22, 163, 74));
        addAccount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                showQrAccountEditor(null, "Akun Utama");
            }
        });
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(48), 1);
        ap.setMargins(dp(8), 0, 0, 0);
        top.addView(addAccount, ap);
        body.addView(top);

        LinearLayout transfer = new LinearLayout(this);
        transfer.setOrientation(LinearLayout.HORIZONTAL);
        Button exportAccounts = actionButton("⇧ Export", Color.rgb(14, 116, 144));
        exportAccounts.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                exportQrAccounts();
            }
        });
        transfer.addView(exportAccounts, new LinearLayout.LayoutParams(0, dp(46), 1));
        Button importAccounts = actionButton("⇩ Import", Color.rgb(124, 58, 237));
        importAccounts.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                importQrAccounts();
            }
        });
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(0, dp(46), 1);
        ip.setMargins(dp(8), 0, 0, 0);
        transfer.addView(importAccounts, ip);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(46));
        tp.setMargins(0, dp(8), 0, 0);
        body.addView(transfer, tp);

        for (final String folder : folders) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(14), dp(10), dp(10), dp(10));
            card.setBackground(makeRounded(Color.rgb(241, 245, 249), dp(12)));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(68));
            cp.setMargins(0, dp(9), 0, 0);

            TextView title = new TextView(this);
            title.setText("📁  " + folder + "\n" + countAccountsInFolder(folder) + " akun");
            title.setTextColor(Color.rgb(15, 23, 42));
            title.setTextSize(15);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    showQrFolderAccountsDialog(folder);
                }
            });
            card.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1));

            Button open = actionButton("Buka", Color.rgb(71, 85, 105));
            open.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    showQrFolderAccountsDialog(folder);
                }
            });
            card.addView(open, new LinearLayout.LayoutParams(dp(72), dp(46)));

            Button manage = actionButton("⋮", Color.rgb(100, 116, 139));
            manage.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    showQrFolderManageDialog(folder);
                }
            });
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(52), dp(46));
            mp.setMargins(dp(7), 0, 0, 0);
            card.addView(manage, mp);
            body.addView(card, cp);
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(body);
        AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Folder akun QR")
                .setView(scroll)
                .setNegativeButton("Tutup", null)
                .create();
        dialogRef[0] = dialog;
        dialog.show();
    }

    private void exportQrAccounts() {
        try {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(new Date());
            intent.putExtra(Intent.EXTRA_TITLE, "ICE_QR_Accounts_" + stamp + ".json");
            startActivityForResult(intent, QR_EXPORT_REQUEST);
        } catch (Throwable error) {
            Toast.makeText(this, "Tidak dapat membuka penyimpanan", Toast.LENGTH_LONG).show();
        }
    }

    private void importQrAccounts() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/json");
            startActivityForResult(intent, QR_IMPORT_REQUEST);
        } catch (Throwable error) {
            Toast.makeText(this, "Tidak dapat membuka file", Toast.LENGTH_LONG).show();
        }
    }

    private JSONObject buildQrAccountsBackup() throws Exception {
        JSONObject root = new JSONObject();
        root.put("format", "ICE_QR_ACCOUNTS");
        root.put("version", 1);
        root.put("exportedAt", System.currentTimeMillis());
        JSONArray folders = new JSONArray();
        for (String folder : loadQrFolders()) folders.put(folder);
        root.put("folders", folders);
        JSONArray accounts = new JSONArray();
        for (QrAccount account : loadQrAccounts()) {
            JSONObject item = new JSONObject();
            item.put("name", account.name);
            item.put("qr", account.qr);
            item.put("folder", account.folder);
            accounts.put(item);
        }
        root.put("accounts", accounts);
        return root;
    }

    private void writeQrBackup(Uri uri) {
        if (uri == null) return;
        OutputStreamWriter writer = null;
        try {
            writer = new OutputStreamWriter(getContentResolver().openOutputStream(uri, "w"), "UTF-8");
            writer.write(buildQrAccountsBackup().toString(2));
            writer.flush();
            Toast.makeText(this, "Akun QR berhasil diexport", Toast.LENGTH_LONG).show();
        } catch (Throwable error) {
            Toast.makeText(this, "Export gagal: " + safeError(error), Toast.LENGTH_LONG).show();
        } finally {
            if (writer != null) try { writer.close(); } catch (Throwable ignored) {}
        }
    }

    private void readQrBackup(final Uri uri) {
        if (uri == null) return;
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri), "UTF-8"));
            StringBuilder text = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) text.append(line).append('\n');
            final JSONObject root = new JSONObject(text.toString());
            if (!"ICE_QR_ACCOUNTS".equals(root.optString("format"))) {
                throw new Exception("File bukan backup akun QR ICE");
            }
            final JSONArray importedAccounts = root.optJSONArray("accounts");
            final JSONArray importedFolders = root.optJSONArray("folders");
            if (importedAccounts == null) throw new Exception("Data akun tidak ditemukan");
            new AlertDialog.Builder(this, R.style.IceDialogTheme)
                    .setTitle("Import akun QR")
                    .setMessage(importedAccounts.length() + " akun ditemukan. Pilih cara import.")
                    .setPositiveButton("Gabungkan", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) {
                            applyQrImport(importedFolders, importedAccounts, false);
                        }
                    })
                    .setNeutralButton("Ganti semua", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int which) {
                            applyQrImport(importedFolders, importedAccounts, true);
                        }
                    })
                    .setNegativeButton("Batal", null)
                    .show();
        } catch (Throwable error) {
            Toast.makeText(this, "Import gagal: " + safeError(error), Toast.LENGTH_LONG).show();
        } finally {
            if (reader != null) try { reader.close(); } catch (Throwable ignored) {}
        }
    }

    private void applyQrImport(JSONArray folderArray, JSONArray accountArray, boolean replaceAll) {
        try {
            List<String> folders = replaceAll ? new ArrayList<String>() : loadQrFolders();
            if (!folders.contains("Akun Utama")) folders.add("Akun Utama");
            if (folderArray != null) {
                for (int i = 0; i < folderArray.length(); i++) {
                    String folder = folderArray.optString(i, "").trim();
                    if (folder.length() > 0 && !folders.contains(folder)) folders.add(folder);
                }
            }
            List<QrAccount> accounts = replaceAll ? new ArrayList<QrAccount>() : loadQrAccounts();
            int added = 0;
            for (int i = 0; i < accountArray.length(); i++) {
                JSONObject item = accountArray.optJSONObject(i);
                if (item == null) continue;
                String name = item.optString("name", "").trim();
                String qr = item.optString("qr", "").trim();
                String folder = item.optString("folder", "Akun Utama").trim();
                if (name.length() == 0 || qr.length() == 0) continue;
                if (folder.length() == 0) folder = "Akun Utama";
                if (!folders.contains(folder)) folders.add(folder);
                boolean duplicate = false;
                if (!replaceAll) {
                    for (QrAccount existing : accounts) {
                        if (existing.name.equals(name) && existing.qr.equals(qr) && existing.folder.equals(folder)) {
                            duplicate = true; break;
                        }
                    }
                }
                if (!duplicate) { accounts.add(new QrAccount(name, qr, folder)); added++; }
            }
            saveQrFolders(folders);
            saveQrAccounts(accounts);
            Toast.makeText(this, replaceAll ? "Semua akun QR berhasil dipulihkan" : added + " akun QR ditambahkan", Toast.LENGTH_LONG).show();
            showQrAccountsDialog();
        } catch (Throwable error) {
            Toast.makeText(this, "Import gagal: " + safeError(error), Toast.LENGTH_LONG).show();
        }
    }

    private void showQrFolderAccountsDialog(final String folder) {
        final List<QrAccount> accounts = loadQrAccounts();
        final AlertDialog[] dialogRef = new AlertDialog[1];
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(8), dp(14), dp(14));

        Button add = actionButton("＋ Tambah akun ke " + folder, Color.rgb(37, 99, 235));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (dialogRef[0] != null) dialogRef[0].dismiss();
                showQrAccountEditor(null, folder);
            }
        });
        body.addView(add, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)));

        int shown = 0;
        for (final QrAccount account : accounts) {
            if (!folder.equals(account.folder)) continue;
            shown++;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(12), dp(12), dp(12));
            card.setBackground(makeRoundedStroke(Color.rgb(30, 41, 59), dp(18), Color.rgb(51, 65, 85), dp(1)));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            cp.setMargins(0, dp(10), 0, 0);

            LinearLayout identity = new LinearLayout(this);
            identity.setOrientation(LinearLayout.HORIZONTAL);
            identity.setGravity(Gravity.CENTER_VERTICAL);

            TextView avatar = new TextView(this);
            avatar.setText(accountInitials(account.name));
            avatar.setTextColor(Color.WHITE);
            avatar.setTextSize(14);
            avatar.setTypeface(null, android.graphics.Typeface.BOLD);
            avatar.setGravity(Gravity.CENTER);
            avatar.setBackground(makeRounded(Color.rgb(37, 99, 235), dp(24)));
            identity.addView(avatar, new LinearLayout.LayoutParams(dp(46), dp(46)));

            TextView name = new TextView(this);
            name.setText(account.name);
            name.setTextColor(Color.rgb(248, 250, 252));
            name.setTextSize(17);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            name.setTypeface(null, android.graphics.Typeface.BOLD);
            name.setPadding(dp(12), 0, dp(4), 0);
            identity.addView(name, new LinearLayout.LayoutParams(0, dp(46), 1));
            card.addView(identity);

            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1, dp(64));
            actionsLp.setMargins(0, dp(10), 0, 0);

            Button login = qrActionButton("↪\nLOGIN", Color.rgb(22, 163, 74));
            login.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    loginWithSavedQr(account);
                }
            });
            actions.addView(login, new LinearLayout.LayoutParams(0, dp(62), 1));

            Button edit = qrActionButton("✎\nEDIT", Color.rgb(51, 65, 85));
            edit.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    showQrAccountEditor(account, folder);
                }
            });
            LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(0, dp(62), 1);
            ep.setMargins(dp(8), 0, 0, 0);
            actions.addView(edit, ep);

            Button moveCopy = qrActionButton("▣\nPINDAH", Color.rgb(109, 40, 217));
            moveCopy.setContentDescription("Pindah atau salin akun");
            moveCopy.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                    showQrAccountMoveCopyDialog(account, folder);
                }
            });
            LinearLayout.LayoutParams mcp = new LinearLayout.LayoutParams(0, dp(62), 1);
            mcp.setMargins(dp(8), 0, 0, 0);
            actions.addView(moveCopy, mcp);

            Button delete = qrActionButton("⌫\nHAPUS", Color.rgb(220, 38, 38));
            delete.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    new AlertDialog.Builder(MainActivity.this, R.style.IceDialogTheme)
                            .setTitle("Hapus akun?")
                            .setMessage("Akun " + account.name + " akan dihapus dari HP ini.")
                            .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                                @Override public void onClick(DialogInterface d, int which) {
                                    List<QrAccount> latest = loadQrAccounts();
                                    int idx = findQrAccountIndex(latest, account);
                                    if (idx >= 0) latest.remove(idx);
                                    saveQrAccounts(latest);
                                    if (dialogRef[0] != null) dialogRef[0].dismiss();
                                    handler.postDelayed(new Runnable() { @Override public void run() { showQrFolderAccountsDialog(folder); } }, 80);
                                }
                            }).setNegativeButton("Batal", null).show();
                }
            });
            LinearLayout.LayoutParams dpv = new LinearLayout.LayoutParams(0, dp(62), 1);
            dpv.setMargins(dp(8), 0, 0, 0);
            actions.addView(delete, dpv);

            card.addView(actions, actionsLp);
            body.addView(card, cp);
        }
        if (shown == 0) {
            TextView empty = new TextView(this);
            empty.setText("Folder ini belum memiliki akun.");
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(12), dp(28), dp(12), dp(28));
            body.addView(empty);
        }

        ScrollView scroll = new ScrollView(this); scroll.addView(body);
        AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("📁 " + folder + " (" + shown + ")")
                .setView(scroll)
                .setPositiveButton("Kembali", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { handler.postDelayed(new Runnable() { @Override public void run() { showQrAccountsDialog(); } }, 80); }
                })
                .setNegativeButton("Tutup", null).create();
        dialogRef[0] = dialog; dialog.show();
    }

    private int findQrAccountIndex(List<QrAccount> list, QrAccount wanted) {
        for (int i = 0; i < list.size(); i++) {
            QrAccount a = list.get(i);
            if (a.name.equals(wanted.name) && a.qr.equals(wanted.qr) && a.folder.equals(wanted.folder)) return i;
        }
        return -1;
    }

    private void showQrFolderManageDialog(final String folder) {
        final boolean isMain = "Akun Utama".equals(folder);
        final ArrayList<String> actions = new ArrayList<String>();
        if (!isMain) actions.add("Ubah nama folder");
        actions.add("Pin folder ke paling atas");
        if (!isMain) actions.add("Hapus folder");
        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Kelola folder: " + folder)
                .setItems(actions.toArray(new String[actions.size()]), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        String action = actions.get(which);
                        if ("Ubah nama folder".equals(action)) showQrFolderRenameDialog(folder);
                        else if ("Pin folder ke paling atas".equals(action)) pinQrFolder(folder);
                        else if ("Hapus folder".equals(action)) showQrFolderDeleteDialog(folder);
                    }
                })
                .setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showQrAccountsDialog(); }
                }).show();
    }

    private void showQrFolderRenameDialog(final String oldName) {
        final EditText input = new EditText(this);
        input.setText(oldName); input.setSingleLine(true); input.setSelectAllOnFocus(true);
        final AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Ubah nama folder")
                .setView(input)
                .setPositiveButton("Simpan", null)
                .setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showQrAccountsDialog(); }
                }).create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface d) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        String newName = input.getText().toString().trim();
                        if (newName.length() == 0) { input.setError("Nama folder wajib diisi"); return; }
                        if ("Akun Utama".equals(newName)) { input.setError("Nama ini sudah dipakai"); return; }
                        List<String> folders = loadQrFolders();
                        if (!oldName.equals(newName) && folders.contains(newName)) { input.setError("Folder sudah ada"); return; }
                        for (int i = 0; i < folders.size(); i++) if (oldName.equals(folders.get(i))) folders.set(i, newName);
                        List<QrAccount> accounts = loadQrAccounts();
                        for (QrAccount a : accounts) if (oldName.equals(a.folder)) a.folder = newName;
                        saveQrFolders(folders); saveQrAccounts(accounts); dialog.dismiss();
                        Toast.makeText(MainActivity.this, "Folder berhasil diubah", Toast.LENGTH_SHORT).show();
                        showQrAccountsDialog();
                    }
                });
            }
        });
        dialog.show();
    }

    private void pinQrFolder(String folder) {
        List<String> folders = loadQrFolders();
        folders.remove(folder);
        if ("Akun Utama".equals(folder)) folders.add(0, folder);
        else {
            int index = folders.indexOf("Akun Utama");
            folders.add(index >= 0 ? index + 1 : 0, folder);
        }
        saveQrFolders(folders);
        Toast.makeText(this, "Folder dipindahkan ke atas", Toast.LENGTH_SHORT).show();
        showQrAccountsDialog();
    }

    private void showQrFolderDeleteDialog(final String folder) {
        final int count = countAccountsInFolder(folder);
        if (count == 0) {
            new AlertDialog.Builder(this, R.style.IceDialogTheme).setTitle("Hapus folder?")
                    .setMessage("Folder " + folder + " akan dihapus.")
                    .setPositiveButton("Hapus", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { deleteQrFolder(folder, false); }
                    }).setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) { showQrAccountsDialog(); }
                    }).show();
            return;
        }
        new AlertDialog.Builder(this, R.style.IceDialogTheme).setTitle("Folder berisi " + count + " akun")
                .setMessage("Pilih apa yang dilakukan pada akun di dalam folder.")
                .setPositiveButton("Pindahkan ke Akun Utama", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { deleteQrFolder(folder, false); }
                })
                .setNeutralButton("Hapus semua", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { deleteQrFolder(folder, true); }
                })
                .setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showQrAccountsDialog(); }
                }).show();
    }

    private void deleteQrFolder(String folder, boolean deleteAccounts) {
        List<QrAccount> accounts = loadQrAccounts();
        for (int i = accounts.size() - 1; i >= 0; i--) {
            QrAccount a = accounts.get(i);
            if (!folder.equals(a.folder)) continue;
            if (deleteAccounts) accounts.remove(i); else a.folder = "Akun Utama";
        }
        List<String> folders = loadQrFolders(); folders.remove(folder);
        saveQrAccounts(accounts); saveQrFolders(folders);
        Toast.makeText(this, deleteAccounts ? "Folder dan akun dihapus" : "Akun dipindahkan ke Akun Utama", Toast.LENGTH_SHORT).show();
        showQrAccountsDialog();
    }

    private void showQrAccountMoveCopyDialog(final QrAccount account, final String sourceFolder) {
        final List<String> folders = loadQrFolders();
        final ArrayList<String> targets = new ArrayList<String>();
        for (String f : folders) if (!sourceFolder.equals(f)) targets.add(f);
        if (targets.size() == 0) {
            Toast.makeText(this, "Buat folder lain terlebih dahulu", Toast.LENGTH_SHORT).show();
            showQrFolderAccountsDialog(sourceFolder); return;
        }
        final android.widget.Spinner spinner = new android.widget.Spinner(this);
        spinner.setAdapter(new android.widget.ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, targets));
        new AlertDialog.Builder(this, R.style.IceDialogTheme).setTitle("Pindah / salin akun")
                .setMessage("Pilih folder tujuan untuk " + account.name)
                .setView(spinner)
                .setPositiveButton("Pindahkan", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String target = String.valueOf(spinner.getSelectedItem());
                        List<QrAccount> latest = loadQrAccounts(); int idx = findQrAccountIndex(latest, account);
                        if (idx >= 0) latest.get(idx).folder = target;
                        saveQrAccounts(latest); Toast.makeText(MainActivity.this, "Akun dipindahkan", Toast.LENGTH_SHORT).show();
                        showQrFolderAccountsDialog(target);
                    }
                })
                .setNeutralButton("Salin", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String target = String.valueOf(spinner.getSelectedItem());
                        List<QrAccount> latest = loadQrAccounts(); latest.add(new QrAccount(account.name, account.qr, target));
                        saveQrAccounts(latest); Toast.makeText(MainActivity.this, "Akun disalin", Toast.LENGTH_SHORT).show();
                        showQrFolderAccountsDialog(target);
                    }
                })
                .setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) { showQrFolderAccountsDialog(sourceFolder); }
                }).show();
    }

    private void showQrFolderEditor() {
        final EditText input = new EditText(this);
        input.setHint("Contoh: Operator Bagian Lain");
        input.setSingleLine(true);
        input.setPadding(dp(20), dp(8), dp(20), dp(8));
        final AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Buat folder akun")
                .setView(input)
                .setPositiveButton("Simpan", null)
                .setNegativeButton("Batal", null).create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface d) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        String name = input.getText().toString().trim();
                        if (name.length() == 0) { input.setError("Nama folder wajib diisi"); return; }
                        List<String> folders = loadQrFolders();
                        if (folders.contains(name)) { input.setError("Folder sudah ada"); return; }
                        folders.add(name); saveQrFolders(folders); dialog.dismiss();
                        handler.postDelayed(new Runnable() { @Override public void run() { showQrAccountsDialog(); } }, 80);
                    }
                });
            }
        });
        dialog.show();
    }

    private void showQrAccountEditor(final QrAccount current, final String defaultFolder) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText nameInput = new EditText(this);
        nameInput.setHint("Nama operator / akun"); nameInput.setSingleLine(true);
        if (current != null) nameInput.setText(current.name); layout.addView(nameInput);
        final EditText qrInput = new EditText(this);
        qrInput.setHint("Tempel seluruh isi QR user"); qrInput.setSingleLine(false); qrInput.setMinLines(3);
        qrInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        if (current != null) qrInput.setText(current.qr); layout.addView(qrInput);
        final List<String> folders = loadQrFolders();
        final android.widget.Spinner folderSpinner = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> adapter = new android.widget.ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, folders);
        folderSpinner.setAdapter(adapter);
        String chosen = current != null ? current.folder : defaultFolder;
        int chosenIndex = folders.indexOf(chosen); if (chosenIndex >= 0) folderSpinner.setSelection(chosenIndex);
        layout.addView(folderSpinner);

        final AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle(current == null ? "Tambah akun QR" : "Edit akun QR")
                .setMessage("Pilih folder tempat akun disimpan.")
                .setView(layout).setPositiveButton("Simpan", null).setNegativeButton("Batal", null).create();
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface unused) {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        String name = nameInput.getText().toString().trim();
                        String qr = qrInput.getText().toString().trim();
                        String folder = String.valueOf(folderSpinner.getSelectedItem());
                        if (name.length() == 0) { nameInput.setError("Nama wajib diisi"); return; }
                        if (qr.length() == 0) { qrInput.setError("Isi QR wajib diisi"); return; }
                        List<QrAccount> latest = loadQrAccounts();
                        QrAccount saved = new QrAccount(name, qr, folder);
                        if (current != null) {
                            int idx = findQrAccountIndex(latest, current);
                            if (idx >= 0) latest.set(idx, saved); else latest.add(saved);
                        } else latest.add(saved);
                        saveQrAccounts(latest); dialog.dismiss();
                        Toast.makeText(MainActivity.this, "Akun QR disimpan di " + folder, Toast.LENGTH_SHORT).show();
                        final String targetFolder = folder;
                        handler.postDelayed(new Runnable() { @Override public void run() { showQrFolderAccountsDialog(targetFolder); } }, 80);
                    }
                });
            }
        });
        dialog.show();
    }

    private void loginWithSavedQr(final QrAccount account) {
        if (account == null || account.qr == null || account.qr.trim().length() == 0) {
            Toast.makeText(this, "Isi QR akun kosong", Toast.LENGTH_SHORT).show();
            return;
        }
        if (currentTab == null || currentTab.webView == null) {
            Toast.makeText(this, "Buka halaman scanner/login terlebih dahulu", Toast.LENGTH_SHORT).show();
            return;
        }

        // Kirim melalui jalur scanner yang sama dengan tombol Input Keyboard Manual.
        // Tidak mencari atau mengisi elemen HTML halaman, sehingga bekerja seperti hasil scan QR.
        setStatus("Mengirim QR akun " + account.name + " ke scanner…");
        sendCodeValue(account.qr, true);
        Toast.makeText(this, "QR " + account.name + " dikirim ke scanner", Toast.LENGTH_SHORT).show();
    }

    private String escapeJs(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ");
    }

    private boolean isDesktopModeEnabled() {
        return preferences.getBoolean(PREF_DESKTOP_MODE, false);
    }

    private String getMobileUserAgent() {
        try {
            String ua = WebSettings.getDefaultUserAgent(this);
            if (ua != null && ua.trim().length() > 0) return ua;
        } catch (Throwable ignored) {}
        return "Mozilla/5.0 (Linux; Android 15; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36";
    }

    private String getDesktopUserAgent() {
        return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                + "AppleWebKit/537.36 (KHTML, like Gecko) "
                + "Chrome/126.0.0.0 Safari/537.36";
    }

    private void applyDesktopMode(WebSettings settings) {
        if (settings == null) return;
        boolean desktop = isDesktopModeEnabled();
        settings.setUserAgentString(desktop ? getDesktopUserAgent() : getMobileUserAgent());
        settings.setUseWideViewPort(desktop);
        settings.setLoadWithOverviewMode(desktop);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        try { settings.setDisplayZoomControls(false); } catch (Throwable ignored) {}
        try { settings.setTextZoom(100); } catch (Throwable ignored) {}
        try { settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL); } catch (Throwable ignored) {}
    }

    private void applyDesktopViewport(WebView view) {
        if (view == null || !isDesktopModeEnabled()) return;
        String javascript = "(function(){try{"+
                "var m=document.querySelector('meta[name=viewport]');"+
                "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}"+
                "m.setAttribute('content','width=1280, initial-scale=0.30, minimum-scale=0.10, maximum-scale=5.0, user-scalable=yes');"+
                "document.documentElement.style.overflowX='auto';"+
                "}catch(e){}})();";
        try { view.evaluateJavascript(javascript, null); } catch (Throwable ignored) {}
    }

    private void toggleDesktopMode() {
        boolean next = !isDesktopModeEnabled();
        preferences.edit().putBoolean(PREF_DESKTOP_MODE, next).apply();
        for (TabState item : tabs) {
            if (item == null || item.destroyed || item.webView == null) continue;
            applyDesktopMode(item.webView.getSettings());
            try {
                item.webView.clearCache(false);
                item.webView.stopLoading();
            } catch (Throwable ignored) {}
        }
        if (currentTab != null && currentTab.webView != null) {
            String url = currentTab.currentUrl;
            if (url == null || url.trim().length() == 0) url = preferences.getString(PREF_URL, DEFAULT_URL);
            try {
                currentTab.webView.loadUrl(url, java.util.Collections.singletonMap("Cache-Control", "no-cache"));
            } catch (Throwable error) {
                loadUrlRouted(currentTab, url);
            }
        }
        Toast.makeText(this,
                next ? "Mode desktop aktif — halaman dimuat ulang" : "Mode desktop nonaktif — halaman dimuat ulang",
                Toast.LENGTH_SHORT).show();
    }

    private void showHomeUrlDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(preferences.getString(PREF_URL, DEFAULT_URL));
        input.setSelection(input.getText().length());
        input.setPadding(dp(14), dp(8), dp(14), dp(8));

        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("URL beranda")
                .setMessage("URL ini dibuka saat aplikasi atau tab baru dibuat.")
                .setView(input)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String url = normalizeUrl(input.getText().toString());
                        preferences.edit().putString(PREF_URL, url).apply();
                        Toast.makeText(MainActivity.this, "URL beranda disimpan", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNeutralButton("Pakai halaman ini", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (currentTab != null) {
                            preferences.edit().putString(PREF_URL, currentTab.currentUrl).apply();
                            Toast.makeText(MainActivity.this, "Halaman aktif dijadikan beranda", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }


    private void copyHandoverHuFromCurrentPage() {
        if (currentTab == null || currentTab.webView == null) {
            Toast.makeText(this, "Halaman belum tersedia", Toast.LENGTH_SHORT).show();
            return;
        }
        if (nativeCopyHuButton != null) {
            nativeCopyHuButton.setEnabled(false);
            nativeCopyHuButton.setAlpha(0.55f);
        }
        final String js = "(function(){try{" +
                "var out=[],seen={};" +
                "function add(v){v=String(v||'').trim();var m=v.match(/^\\d{8,14}$/);if(m&&!seen[v]){seen[v]=1;out.push(v);}}" +
                "function scan(d){if(!d)return;var tables=d.querySelectorAll('table');for(var ti=0;ti<tables.length;ti++){var t=tables[ti],heads=t.querySelectorAll('thead th,thead td,tr:first-child th,tr:first-child td'),idx=-1;for(var h=0;h<heads.length;h++){if(/barcode|kode\\s*hu|\\bhu\\b/i.test((heads[h].innerText||heads[h].textContent||'').trim())){idx=h;break;}}var rows=t.querySelectorAll('tbody tr,tr');for(var r=0;r<rows.length;r++){var cells=rows[r].querySelectorAll('td');if(!cells.length)continue;if(idx>=0&&cells[idx])add(cells[idx].innerText||cells[idx].textContent);else{for(var c=0;c<cells.length;c++){var x=(cells[c].innerText||cells[c].textContent||'').trim();if(/^\\d{8,14}$/.test(x)){add(x);break;}}}}}var fs=d.querySelectorAll('iframe,frame');for(var i=0;i<fs.length;i++){try{scan(fs[i].contentDocument);}catch(e){}}}" +
                "scan(document);" +
                "if(!out.length){var els=document.querySelectorAll('td,[data-field*=barcode i],[class*=barcode i]');for(var j=0;j<els.length;j++)add(els[j].innerText||els[j].textContent);}" +
                "if(!out.length){AndroidBridge.onStatus('Kode HU belum tampil. Tunggu tabel selesai dimuat lalu tekan COPY HU lagi.');return 'empty';}" +
                "AndroidBridge.copyHandoverCodes(out.join('\\n'),out.length);return String(out.length);" +
                "}catch(e){AndroidBridge.onStatus('Gagal membaca HU: '+String(e));return 'error';}})();";
        try {
            currentTab.webView.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    handler.postDelayed(new Runnable() {
                        @Override public void run() {
                            if (nativeCopyHuButton != null) {
                                nativeCopyHuButton.setEnabled(true);
                                nativeCopyHuButton.setAlpha(1f);
                                nativeCopyHuButton.bringToFront();
                            }
                        }
                    }, 700L);
                }
            });
        } catch (Throwable error) {
            if (nativeCopyHuButton != null) {
                nativeCopyHuButton.setEnabled(true);
                nativeCopyHuButton.setAlpha(1f);
            }
            Toast.makeText(this, "Gagal membaca halaman HU", Toast.LENGTH_SHORT).show();
        }
    }

    private void copyCurrentUrl() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("URL", currentTab.currentUrl));
            Toast.makeText(this, "URL disalin", Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {}
    }

    private void shareCurrentPage() {
        if (currentTab == null || currentTab.currentUrl == null) return;
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, currentTab.currentUrl);
            startActivity(Intent.createChooser(intent, "Bagikan halaman"));
        } catch (Throwable ignored) {
            copyCurrentUrl();
        }
    }

    private void showPageInfo() {
        String url = currentTab == null ? "" : currentTab.currentUrl;
        String message = url.startsWith("https://")
                ? "Sambungan HTTPS.\n\n" + url
                : "Sambungan tidak menggunakan HTTPS.\n\n" + url;
        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Info halaman")
                .setMessage(message)
                .setPositiveButton("Salin URL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        copyCurrentUrl();
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void showLicenseServerDialog(final boolean openAdminAfter) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://domain.com/ice-license");
        input.setText(preferences.getString(PREF_LICENSE_SERVER, ""));
        input.setSelection(input.getText().length());
        input.setPadding(dp(14), dp(8), dp(14), dp(8));

        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Server lisensi ICE")
                .setMessage("Masukkan folder tempat paket server lisensi di-upload.")
                .setView(input)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String server = normalizeServerUrl(input.getText().toString());
                        preferences.edit().putString(PREF_LICENSE_SERVER, server).apply();
                        if (openAdminAfter) openAdminPanel();
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }

    private void openAdminPanel() {
        String server = normalizeServerUrl(preferences.getString(PREF_LICENSE_SERVER, ""));
        if (server.length() == 0) {
            showLicenseServerDialog(true);
            return;
        }
        createNewTab(server + "/admin.php", true);
    }

    private void showActivationDialog(final boolean required) {
        if (ADMIN_BUILD) return;

        final LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText serverInput = new EditText(this);
        serverInput.setHint("https://domain.com/ice-login");
        serverInput.setSingleLine(true);
        serverInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        serverInput.setText(preferences.getString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER));
        layout.addView(serverInput, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        final EditText userInput = new EditText(this);
        userInput.setHint("Username");
        userInput.setSingleLine(true);
        userInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_NORMAL);
        userInput.setText(preferences.getString(PREF_LICENSE_KEY, ""));
        userInput.setPadding(dp(14), dp(8), dp(14), dp(8));
        LinearLayout.LayoutParams userParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        userParams.setMargins(0, dp(10), 0, 0);
        layout.addView(userInput, userParams);

        final EditText passInput = new EditText(this);
        passInput.setHint("Password");
        passInput.setSingleLine(true);
        passInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        passInput.setPadding(dp(14), dp(8), dp(14), dp(8));
        LinearLayout.LayoutParams passParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        passParams.setMargins(0, dp(10), 0, 0);
        layout.addView(passInput, passParams);

        final TextView message = new TextView(this);
        message.setText("Login wajib pakai internet/data. Setelah berhasil masuk, aplikasi bisa dipakai di WiFi perusahaan tanpa internet selama APK masih terbuka. Jika APK ditutup, harus login ulang.");
        message.setTextColor(Color.rgb(71, 85, 105));
        message.setTextSize(12);
        message.setPadding(0, dp(12), 0, 0);
        layout.addView(message);

        final AlertDialog dialog = new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Login ICE Inject")
                .setView(layout)
                .setCancelable(!required)
                .setPositiveButton("Login", null)
                .setNegativeButton(required ? "Keluar" : "Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        if (required) finish();
                    }
                })
                .create();

        dialog.setCanceledOnTouchOutside(!required);
        dialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialogInterface) {
                final Button login = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        final String server = normalizeServerUrl(serverInput.getText().toString());
                        final String username = normalizeUsernameLocal(userInput.getText().toString());
                        final String password = passInput.getText().toString();
                        if (server.length() == 0) {
                            message.setText("URL server harus diisi dengan benar.");
                            message.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }
                        if (username.length() < 3 || password.length() == 0) {
                            message.setText("Username/password belum diisi.");
                            message.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }

                        preferences.edit().putString(PREF_LICENSE_SERVER, server).putString(PREF_LICENSE_KEY, username).apply();
                        login.setEnabled(false);
                        message.setText("Login ke server…");
                        message.setTextColor(Color.rgb(71, 85, 105));

                        loginAccount(server, username, password, new ApiCallback() {
                            @Override
                            public void onResult(boolean success, JSONObject data, String error) {
                                if (success) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            licenseUnlocked = true;
                                            updateLicenseBadgeFromCache();
                                            try { dialog.dismiss(); } catch (Throwable ignored) {}
                                            startBrowserIfNeeded();
                                            Toast.makeText(MainActivity.this, "Login berhasil", Toast.LENGTH_LONG).show();
                                        }
                                    });
                                    return;
                                }
                                final String msg = error == null || error.length() == 0 ? "Login gagal. Cek username/password/server." : error;
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        login.setEnabled(true);
                                        message.setText(msg);
                                        message.setTextColor(Color.rgb(185, 28, 28));
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });

        dialog.show();
    }

    private void openBrowserActivation(final String server, final boolean required) {
        final Dialog browserDialog = new Dialog(this);
        browserDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        browserDialog.setCancelable(!required);
        browserDialog.setCanceledOnTouchOutside(false);

        LinearLayout container = new LinearLayout(this);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setBackgroundColor(Color.rgb(245, 247, 250));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(10), dp(8), dp(10), dp(8));
        bar.setBackgroundColor(Color.rgb(15, 45, 64));

        TextView title = new TextView(this);
        title.setText("Aktivasi Browser");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(44), 1));

        final TextView status = new TextView(this);
        status.setText("Memuat halaman aktivasi…");
        status.setTextColor(Color.rgb(71, 85, 105));
        status.setTextSize(12);
        status.setPadding(dp(12), dp(8), dp(12), dp(8));

        Button close = smallButton(required ? "Keluar" : "Tutup");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                status.setText("Mengecek hasil aktivasi…");
                verifyActivationFromBrowser(server, browserDialog, status, required);
            }
        });
        bar.addView(close);
        container.addView(bar);
        container.addView(status);

        final WebView activationWeb = new WebView(this);
        WebSettings settings = activationWeb.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 21) {
            try {
                Method method = android.webkit.CookieManager.class.getMethod(
                        "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                method.invoke(cookieManager, activationWeb, true);
            } catch (Exception ignored) {
            }
        }

        ActivationBridge activationBridge = new ActivationBridge(server, browserDialog, status);
        try {
            activationWeb.addJavascriptInterface(activationBridge, "Android");
            activationWeb.addJavascriptInterface(activationBridge, "IceApp");
        } catch (Throwable ignored) {}

        activationWeb.setWebChromeClient(new WebChromeClient());
        activationWeb.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (handleActivationCallback(url, server, browserDialog, status)) {
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (!url.startsWith("iceinject://")) {
                    status.setText("Membuka halaman aktivasi…");
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (!url.startsWith("iceinject://")) {
                    status.setText("Masukkan key pada halaman di bawah.");
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            verifyActivationFromBrowser(server, browserDialog, status, false);
                        }
                    }, 900L);
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                status.setText("Gagal memuat halaman: " + description + ". Pastikan internet aktif dan URL server benar.");
                status.setTextColor(Color.rgb(185, 28, 28));
            }
        });

        container.addView(activationWeb, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));

        browserDialog.setContentView(container);
        browserDialog.show();
        Window window = browserDialog.getWindow();
        if (window != null) {
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }

        try {
            String url = server + "/activate.php"
                    + "?device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                    + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                    + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8");
            activationWeb.loadUrl(url);
        } catch (Exception error) {
            status.setText("Tidak dapat membuat URL aktivasi: " + error.getMessage());
            status.setTextColor(Color.rgb(185, 28, 28));
        }
    }

    private boolean handleActivationCallback(String url, String server, Dialog dialog, TextView status) {
        if (url == null || !url.startsWith("iceinject://activated")) return false;

        try {
            Uri uri = Uri.parse(url);
            String ok = uri.getQueryParameter("ok");
            String message = uri.getQueryParameter("message");

            if (!"1".equals(ok)) {
                status.setText(message == null ? "Aktivasi gagal." : message);
                status.setTextColor(Color.rgb(185, 28, 28));
                return true;
            }

            String key = normalizeKey(uri.getQueryParameter("key"));
            String token = uri.getQueryParameter("token");
            long expiryMillis = parseServerMillis(uri.getQueryParameter("expires_at"));
            long serverMillis = parseServerMillis(uri.getQueryParameter("server_time"));
            long createdMillis = parseServerMillis(uri.getQueryParameter("created_at"));
            String durationLabel = uri.getQueryParameter("duration_label");

            if (key.length() < 8 || expiryMillis <= 0) {
                status.setText("Data aktivasi dari server tidak lengkap.");
                status.setTextColor(Color.rgb(185, 28, 28));
                return true;
            }

            if (serverMillis <= 0) serverMillis = System.currentTimeMillis();

            preferences.edit()
                    .putString(PREF_LICENSE_SERVER, server)
                    .putString(PREF_LICENSE_KEY, key)
                    .putString(PREF_LICENSE_TOKEN, token == null ? "" : token)
                    .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                    .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : serverMillis)
                    .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? "" : durationLabel)
                    .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                    .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                    .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                    .apply();

            dialog.dismiss();
            licenseUnlocked = true;
            updateLicenseBadgeFromCache();
            startBrowserIfNeeded();
            Toast.makeText(MainActivity.this,
                    message == null ? "Aktivasi berhasil" : message,
                    Toast.LENGTH_LONG).show();
            return true;
        } catch (Exception error) {
            status.setText("Gagal membaca hasil aktivasi: " + error.getMessage());
            status.setTextColor(Color.rgb(185, 28, 28));
            return true;
        }
    }

    private long parseLongSafe(String value) {
        try {
            return Long.parseLong(value == null ? "0" : value);
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private long parseServerMillis(String value) {
        if (value == null) return 0L;
        String v = value.trim();
        if (v.length() == 0) return 0L;
        try {
            if (v.matches("^[0-9]+$")) {
                long n = Long.parseLong(v);
                return n < 100000000000L ? n * 1000L : n;
            }
        } catch (Exception ignored) {}
        try {
            v = v.replace('T', ' ');
            if (v.endsWith("Z")) v = v.substring(0, v.length() - 1);
            int plus = v.indexOf('+', 10);
            if (plus > 0) v = v.substring(0, plus).trim();
            int dot = v.indexOf('.');
            if (dot > 0) v = v.substring(0, dot);
            if (v.length() >= 19) v = v.substring(0, 19);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            format.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));
            Date parsed = format.parse(v);
            return parsed == null ? 0L : parsed.getTime();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private void showLicenseInfoDialog() {
        if (ADMIN_BUILD) return;

        String key = preferences.getString(PREF_LICENSE_KEY, "-");
        long created = preferences.getLong(PREF_LICENSE_CREATED, 0L);
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        String duration = preferences.getString(PREF_LICENSE_DURATION_LABEL, "");
        String server = preferences.getString(PREF_LICENSE_SERVER, "-");
        long remaining = Math.max(0L, expiry - trustedNowMillis());

        StringBuilder message = new StringBuilder();
        message.append("Key: ").append(maskKey(key));
        if (duration != null && duration.length() > 0) {
            message.append("\nDurasi key: ").append(duration);
        }
        if (created > 0) message.append("\nDibuat: ").append(formatDate(created));
        message.append("\nBerakhir: ").append(expiry > 0 ? formatDate(expiry) : "belum aktif");
        if (expiry > 0) message.append("\nSisa waktu: ").append(longRemaining(remaining));
        message.append("\nServer: ").append(server);
        message.append("\n\nSemua waktu ditampilkan dalam WIB dan mengikuti waktu server lisensi.");

        new AlertDialog.Builder(this, R.style.IceDialogTheme)
                .setTitle("Lisensi ICE Inject")
                .setMessage(message.toString())
                .setPositiveButton("Ganti / Aktivasi", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        showActivationDialog(false);
                    }
                })
                .setNeutralButton("Cek Sekarang", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        validateLicenseAsync(true);
                    }
                })
                .setNegativeButton("Tutup", null)
                .show();
    }

    private void loginAccount(final String server, final String username, final String password, final ApiCallback callback) {
        final ApiCallback routedCallback = beginInternetRouteForCallback(callback);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView loginWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = loginWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, loginWeb, true);
                        } catch (Exception ignored) {}
                    }

                    loginWeb.setAlpha(0.01f);
                    loginWeb.setWebChromeClient(new WebChromeClient());
                    loginWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readLoginResultFromWebView(view, server, username, routedCallback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            removeCheckWebView(loginWeb);
                            routedCallback.onResult(false, null, "Gagal membuka server: " + description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(loginWeb, params);
                    } else {
                        root.addView(loginWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    String url = server + "/login-app.php"
                            + "?username=" + URLEncoder.encode(username, "UTF-8")
                            + "&password=" + URLEncoder.encode(password, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8")
                            + "&api=1&format=json";
                    loginWeb.loadUrl(url);
                } catch (Throwable error) {
                    try { removeCheckWebView(loginWeb); } catch (Throwable ignored) {}
                    routedCallback.onResult(false, null, error.getMessage() == null ? "Gagal login" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(loginWeb);
                            routedCallback.onResult(false, null, "Timeout login. Cek koneksi internet/server.");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readLoginResultFromWebView(final WebView view, final String server, final String username,
                                            final ApiCallback callback, final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleLoginWebText(view, server, username, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                finished[0] = true;
                removeCheckWebView(view);
                callback.onResult(false, null, "Android terlalu lama untuk baca hasil login.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            removeCheckWebView(view);
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleLoginWebText(WebView view, String server, String username,
                                    ApiCallback callback, boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        removeCheckWebView(view);

        try {
            JSONObject data = jsonFromText(text);
            if (data == null) {
                String small = text == null ? "" : text.trim();
                if (small.length() > 140) small = small.substring(0, 140);
                callback.onResult(false, null, "Server membalas HTML, bukan JSON. " + small);
                return;
            }
            if (!jsonSaysActive(data)) {
                callback.onResult(false, data, data.optString("message", "Login ditolak."));
                return;
            }
            if (data.optString("username", "").length() == 0) {
                try { data.put("username", username); } catch (Throwable ignored) {}
            }
            boolean saved = saveLoginSessionFromJson(server, data);
            if (!saved) {
                callback.onResult(false, data, "Respons server tidak lengkap: expired/token kosong.");
                return;
            }
            callback.onResult(true, data, null);
        } catch (Throwable error) {
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca JSON server" : error.getMessage());
        }
    }

    private void activateLicense(final String server, final String key, final ApiCallback callback) {
        // v2.7.6: free hosting sering membalas HttpURLConnection dengan HTML/JS,
        // sehingga JSONObject gagal. Aktivasi sekarang memakai WebView mini supaya
        // cookie/JS hosting tetap jalan, lalu body JSON dibaca dari halaman.
        activateLicenseViaWebView(server, key, callback);
    }

    private void activateLicenseViaWebView(final String server, final String key, final ApiCallback callback) {
        final ApiCallback routedCallback = beginInternetRouteForCallback(callback);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView activationWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = activationWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, activationWeb, true);
                        } catch (Exception ignored) {}
                    }

                    activationWeb.setAlpha(0.01f);
                    activationWeb.setWebChromeClient(new WebChromeClient());
                    activationWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readActivationResultFromWebView(view, server, key, routedCallback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            removeCheckWebView(activationWeb);
                            routedCallback.onResult(false, null, "Gagal membuka server: " + description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(activationWeb, params);
                    } else {
                        root.addView(activationWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    String url = server + "/activate.php"
                            + "?key=" + URLEncoder.encode(key, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8")
                            + "&api=1&format=json";
                    activationWeb.loadUrl(url);
                } catch (Throwable error) {
                    try { removeCheckWebView(activationWeb); } catch (Throwable ignored) {}
                    routedCallback.onResult(false, null, error.getMessage() == null ? "Gagal aktivasi" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(activationWeb);
                            routedCallback.onResult(false, null, "Timeout aktivasi. Coba tombol Buka Web.");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readActivationResultFromWebView(final WebView view, final String server, final String key,
                                                 final ApiCallback callback, final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleActivationWebText(view, server, key, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                // Semua perangkat target Android 15, tapi ini fallback aman.
                finished[0] = true;
                removeCheckWebView(view);
                callback.onResult(false, null, "Android terlalu lama untuk baca hasil aktivasi.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            removeCheckWebView(view);
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleActivationWebText(WebView view, String server, String key,
                                         ApiCallback callback, boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        removeCheckWebView(view);

        try {
            JSONObject data = jsonFromText(text);
            if (data == null) {
                String small = text == null ? "" : text.trim();
                if (small.length() > 140) small = small.substring(0, 140);
                callback.onResult(false, null, "Server membalas HTML, bukan JSON. Pakai tombol Buka Web. " + small);
                return;
            }

            if (!jsonSaysActive(data)) {
                callback.onResult(false, data, data.optString("message", "Key tidak valid."));
                return;
            }

            if (data.optString("key", "").length() == 0) {
                try { data.put("key", key); } catch (Throwable ignored) {}
            }
            boolean saved = saveLicenseFromJson(server, data);
            if (!saved) {
                callback.onResult(false, data, "Respons server tidak lengkap: expired kosong.");
                return;
            }
            callback.onResult(true, data, null);
        } catch (Throwable error) {
            callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca JSON server" : error.getMessage());
        }
    }

    private JSONObject jsonFromText(String text) {
        if (text == null) return null;
        String t = text.trim();
        if (t.startsWith("\uFEFF")) t = t.substring(1).trim();
        int first = t.indexOf('{');
        int last = t.lastIndexOf('}');
        if (first < 0 || last <= first) return null;
        try {
            return new JSONObject(t.substring(first, last + 1));
        } catch (Throwable ignored) {
            return null;
        }
    }

    private String decodeJsString(String value) {
        if (value == null) return "";
        try {
            JSONArray arr = new JSONArray("[" + value + "]");
            return arr.optString(0, value);
        } catch (Throwable ignored) {
            return value;
        }
    }

    private class ActivationBridge {
        private final String server;
        private final Dialog dialog;
        private final TextView status;

        ActivationBridge(String server, Dialog dialog, TextView status) {
            this.server = server;
            this.dialog = dialog;
            this.status = status;
        }

        @JavascriptInterface
        public String getDeviceId() {
            return getInstallDeviceId();
        }

        @JavascriptInterface
        public String getAndroidId() {
            return getInstallDeviceId();
        }

        @JavascriptInterface
        public String getDeviceName() {
            return Build.MANUFACTURER + " " + Build.MODEL;
        }

        @JavascriptInterface
        public void onLicenseActivated(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void licenseActivated(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void activationSuccess(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void onActivationSuccess(String payload) {
            handleBridgePayload(payload);
        }

        @JavascriptInterface
        public void saveLicense(String key, String token, String expiresAt, String deviceId) {
            try {
                JSONObject data = new JSONObject();
                data.put("ok", 1);
                data.put("status", "active");
                data.put("key", key == null ? "" : key);
                data.put("token", token == null ? "" : token);
                data.put("expires_at", expiresAt == null ? "" : expiresAt);
                data.put("device_id", deviceId == null ? getInstallDeviceId() : deviceId);
                data.put("server_time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
                handleBridgePayload(data.toString());
            } catch (Throwable ignored) {}
        }

        @JavascriptInterface
        public void setLicense(String key, String token, String expiresAt, String deviceId) {
            saveLicense(key, token, expiresAt, deviceId);
        }

        @JavascriptInterface
        public void setActivated(boolean active) {
            if (active) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        status.setText("Aktivasi diterima. Tekan Tutup/Keluar jika belum terbuka otomatis.");
                        status.setTextColor(Color.rgb(22, 101, 52));
                    }
                });
            }
        }

        private void handleBridgePayload(final String payload) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject data = jsonFromText(payload);
                        if (data == null || !jsonSaysActive(data)) {
                            status.setText("Data aktivasi tidak lengkap.");
                            status.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }
                        boolean saved = saveLicenseFromJson(server, data);
                        if (!saved) {
                            status.setText("Aktivasi berhasil tapi expired tidak terbaca.");
                            status.setTextColor(Color.rgb(185, 28, 28));
                            return;
                        }
                        licenseUnlocked = true;
                        updateLicenseBadgeFromCache();
                        try { dialog.dismiss(); } catch (Throwable ignored) {}
                        startBrowserIfNeeded();
                        Toast.makeText(MainActivity.this, "Aktivasi berhasil", Toast.LENGTH_LONG).show();
                    } catch (Throwable error) {
                        status.setText("Gagal menyimpan aktivasi: " + error.getMessage());
                        status.setTextColor(Color.rgb(185, 28, 28));
                    }
                }
            });
        }
    }

    private void startLicenseWatchdog() {
        if (ADMIN_BUILD) return;
        handler.removeCallbacks(licenseWatchdog);
        handler.postDelayed(licenseWatchdog, LICENSE_CHECK_INTERVAL_MS);
    }

    private void validateLicenseAsync(final boolean showToast) {
        if (ADMIN_BUILD) return;

        final String server = normalizeServerUrl(preferences.getString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER));
        if (server.length() == 0) {
            lockLicense("URL server lisensi belum diisi.");
            return;
        }
        if (!server.equals(preferences.getString(PREF_LICENSE_SERVER, ""))) {
            preferences.edit().putString(PREF_LICENSE_SERVER, server).apply();
        }

        long lastCheck = preferences.getLong(PREF_LAST_CHECK, 0L);
        if (licenseUnlocked && !showToast && System.currentTimeMillis() - lastCheck < LICENSE_CHECK_INTERVAL_MS) return;
        if (licenseCheckInProgress) return;

        checkLicenseDirect(server, showToast, true, null);
    }

    private void verifyActivationFromBrowser(final String server, final Dialog dialog,
                                             final TextView status, final boolean closeIfFail) {
        checkLicenseDirect(server, false, false, new ApiCallback() {
            @Override
            public void onResult(boolean success, JSONObject data, String error) {
                if (success) {
                    status.setText("Aktivasi berhasil. Aplikasi dibuka…");
                    status.setTextColor(Color.rgb(22, 101, 52));
                    try { dialog.dismiss(); } catch (Throwable ignored) {}
                    startBrowserIfNeeded();
                    return;
                }
                if (closeIfFail) {
                    try { dialog.dismiss(); } catch (Throwable ignored) {}
                    finish();
                } else if (error != null && error.length() > 0) {
                    status.setText("Masukkan key pada halaman di bawah. " + error);
                    status.setTextColor(Color.rgb(71, 85, 105));
                }
            }
        });
    }

    private void checkLicenseDirect(final String server, final boolean showToast,
                                    final boolean lockOnFail, final ApiCallback callback) {
        if (licenseCheckInProgress) return;
        licenseCheckInProgress = true;

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView checkWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                try {
                    WebSettings settings = checkWeb.getSettings();
                    settings.setJavaScriptEnabled(true);
                    settings.setDomStorageEnabled(true);
                    settings.setDatabaseEnabled(true);
                    settings.setLoadWithOverviewMode(true);
                    settings.setUseWideViewPort(true);

                    android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                    cookieManager.setAcceptCookie(true);
                    if (Build.VERSION.SDK_INT >= 21) {
                        try {
                            Method method = android.webkit.CookieManager.class.getMethod(
                                    "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                            method.invoke(cookieManager, checkWeb, true);
                        } catch (Exception ignored) {}
                    }

                    checkWeb.setAlpha(0.01f);
                    checkWeb.setWebChromeClient(new WebChromeClient());
                    checkWeb.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(final WebView view, String url) {
                            if (finished[0]) return;
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    readLicenseCheckFromWebView(view, server, showToast, lockOnFail, callback, finished);
                                }
                            }, 500L);
                        }

                        @Override
                        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                            if (finished[0]) return;
                            finished[0] = true;
                            finishLicenseCheckRoute();
                            removeCheckWebView(checkWeb);
                            if (lockOnFail) handleLicenseServerUnavailable(showToast);
                            if (callback != null) callback.onResult(false, null, description == null ? "Server tidak tersambung" : description);
                        }
                    });

                    if (webContainer != null) {
                        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                        params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                        webContainer.addView(checkWeb, params);
                    } else {
                        root.addView(checkWeb, new LinearLayout.LayoutParams(dp(2), dp(2)));
                    }

                    if (runtimeUsername.length() == 0 || runtimeSessionToken.length() == 0) {
                        finished[0] = true;
                        finishLicenseCheckRoute();
                        removeCheckWebView(checkWeb);
                        if (lockOnFail) lockLicense("Sesi login hilang. Login ulang pakai internet.");
                        if (callback != null) callback.onResult(false, null, "Sesi login hilang");
                        return;
                    }
                    StringBuilder url = new StringBuilder(server).append("/check-session.php")
                            .append("?username=").append(URLEncoder.encode(runtimeUsername, "UTF-8"))
                            .append("&session_token=").append(URLEncoder.encode(runtimeSessionToken, "UTF-8"))
                            .append("&device_id=").append(URLEncoder.encode(getInstallDeviceId(), "UTF-8"))
                            .append("&device_name=").append(URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8"))
                            .append("&app_version=").append(URLEncoder.encode(APP_VERSION, "UTF-8"))
                            .append("&api=1&format=json&_t=").append(System.currentTimeMillis());
                    checkWeb.loadUrl(url.toString());
                } catch (Throwable error) {
                    finished[0] = true;
                    finishLicenseCheckRoute();
                    try { removeCheckWebView(checkWeb); } catch (Throwable ignored) {}
                    if (lockOnFail) handleLicenseServerUnavailable(showToast);
                    if (callback != null) callback.onResult(false, null, error.getMessage() == null ? "Gagal cek lisensi" : error.getMessage());
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            finishLicenseCheckRoute();
                            removeCheckWebView(checkWeb);
                            if (lockOnFail) handleLicenseServerUnavailable(showToast);
                            if (callback != null) callback.onResult(false, null, "Timeout cek lisensi");
                        }
                    }
                }, 25000L);
            }
        });
    }

    private void readLicenseCheckFromWebView(final WebView view, final String server, final boolean showToast,
                                             final boolean lockOnFail, final ApiCallback callback,
                                             final boolean[] finished) {
        if (finished[0]) return;
        try {
            if (Build.VERSION.SDK_INT >= 19) {
                view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                handleLicenseCheckText(view, server, showToast, lockOnFail, callback, finished, decodeJsString(value));
                            }
                        });
            } else {
                finished[0] = true;
                finishLicenseCheckRoute();
                removeCheckWebView(view);
                if (lockOnFail) handleLicenseServerUnavailable(showToast);
                if (callback != null) callback.onResult(false, null, "Android terlalu lama untuk cek lisensi.");
            }
        } catch (Throwable error) {
            finished[0] = true;
            finishLicenseCheckRoute();
            removeCheckWebView(view);
            if (lockOnFail) handleLicenseServerUnavailable(showToast);
            if (callback != null) callback.onResult(false, null, error.getMessage() == null ? "Gagal membaca hasil server" : error.getMessage());
        }
    }

    private void handleLicenseCheckText(WebView view, String server, boolean showToast,
                                        boolean lockOnFail, ApiCallback callback,
                                        boolean[] finished, String text) {
        if (finished[0]) return;
        finished[0] = true;
        finishLicenseCheckRoute();
        removeCheckWebView(view);

        JSONObject data = jsonFromText(text);
        if (data != null && jsonSaysActive(data)) {
            boolean saved = saveLoginSessionFromJson(server, data);
            if (saved) {
                licenseUnlocked = true;
                updateLicenseBadgeFromCache();
                startBrowserIfNeeded();
                if (showToast) Toast.makeText(MainActivity.this,
                        data.optString("message", "Lisensi aktif"),
                        Toast.LENGTH_SHORT).show();
                if (callback != null) callback.onResult(true, data, null);
                return;
            }
        }

        String message = data != null ? data.optString("message", "Lisensi belum aktif.") : "Server tidak memberi JSON valid.";
        if (message == null || message.length() == 0) message = "Lisensi belum aktif.";

        if (data == null) {
            if (lockOnFail) handleLicenseServerUnavailable(showToast);
        } else if (lockOnFail) {
            lockLicense(message);
        }
        if (callback != null) callback.onResult(false, data, message);
    }

    private boolean jsonSaysActive(JSONObject data) {
        if (data == null) return false;
        if (data.optBoolean("ok", false) || data.optInt("ok", 0) == 1) return true;
        if (data.optBoolean("success", false) || data.optInt("success", 0) == 1) return true;
        if (data.optBoolean("valid", false) || data.optInt("valid", 0) == 1) return true;
        if (data.optBoolean("active", false) || data.optInt("active", 0) == 1) return true;
        if (data.optBoolean("is_valid", false) || data.optInt("is_valid", 0) == 1) return true;
        if (data.optBoolean("license_valid", false) || data.optInt("license_valid", 0) == 1) return true;
        return "active".equalsIgnoreCase(data.optString("status", ""));
    }

    private boolean saveLoginSessionFromJson(String server, JSONObject data) {
        long expiryMillis = extractExpiryMillis(data);
        if (expiryMillis <= 0) return false;
        String username = normalizeUsernameLocal(data.optString("username", runtimeUsername.length() > 0 ? runtimeUsername : preferences.getString(PREF_LICENSE_KEY, "")));
        String token = data.optString("session_token", data.optString("token", runtimeSessionToken));
        if (username.length() < 3 || token.length() == 0) return false;
        long serverMillis = extractServerMillis(data);
        if (serverMillis <= 0) serverMillis = System.currentTimeMillis();

        runtimeUsername = username;
        runtimeSessionToken = token;
        runtimeSessionExpiry = expiryMillis;
        preferences.edit()
                .putString(PREF_LICENSE_SERVER, server)
                .putString(PREF_LICENSE_KEY, username)
                .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                .putLong(PREF_LICENSE_CREATED, serverMillis)
                .putString(PREF_LICENSE_DURATION_LABEL, "Login user")
                .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                .remove(PREF_LICENSE_TOKEN)
                .apply();
        return true;
    }

    private boolean saveLicenseFromJson(String server, JSONObject data) {
        long expiryMillis = extractExpiryMillis(data);
        if (expiryMillis <= 0) return false;
        long serverMillis = extractServerMillis(data);
        if (serverMillis <= 0) serverMillis = System.currentTimeMillis();
        long createdMillis = extractCreatedMillis(data);
        String oldKey = preferences.getString(PREF_LICENSE_KEY, "");
        String oldToken = preferences.getString(PREF_LICENSE_TOKEN, "");
        String key = normalizeKey(data.optString("key", oldKey));
        String token = data.optString("token", oldToken);
        String durationLabel = data.optString("duration_label", preferences.getString(PREF_LICENSE_DURATION_LABEL, ""));

        SharedPreferences.Editor editor = preferences.edit()
                .putString(PREF_LICENSE_SERVER, server)
                .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : serverMillis)
                .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? "" : durationLabel)
                .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                .putLong(PREF_LAST_CHECK, System.currentTimeMillis());
        if (key.length() > 0) editor.putString(PREF_LICENSE_KEY, key);
        if (token != null) editor.putString(PREF_LICENSE_TOKEN, token);
        editor.apply();
        return true;
    }

    private long extractExpiryMillis(JSONObject data) {
        if (data == null) return 0L;
        String[] keys = new String[]{"expires_at", "expires", "expiry", "expire_at", "expire_date", "expired_at"};
        for (String k : keys) {
            long v = parseServerMillis(data.optString(k, ""));
            if (v > 0) return v;
        }
        return 0L;
    }

    private long extractServerMillis(JSONObject data) {
        if (data == null) return 0L;
        long v = parseServerMillis(data.optString("server_time", ""));
        if (v > 0) return v;
        return parseServerMillis(data.optString("server_timestamp", ""));
    }

    private long extractCreatedMillis(JSONObject data) {
        if (data == null) return 0L;
        long v = parseServerMillis(data.optString("created_at", ""));
        if (v > 0) return v;
        return parseServerMillis(data.optString("activated_at", ""));
    }

    private void checkLicenseThroughBrowser(final String server, final String key,
                                            final String token, final boolean showToast) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final WebView checkWeb = new WebView(MainActivity.this);
                final boolean[] finished = new boolean[]{false};

                WebSettings settings = checkWeb.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setDomStorageEnabled(true);
                settings.setDatabaseEnabled(true);

                android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
                cookieManager.setAcceptCookie(true);
                if (Build.VERSION.SDK_INT >= 21) {
                    try {
                        Method method = android.webkit.CookieManager.class.getMethod(
                                "setAcceptThirdPartyCookies", WebView.class, boolean.class);
                        method.invoke(cookieManager, checkWeb, true);
                    } catch (Exception ignored) {
                    }
                }

                checkWeb.setAlpha(0.01f);
                checkWeb.setWebChromeClient(new WebChromeClient());
                checkWeb.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView view, String url) {
                        if (url != null && url.startsWith("iceinject://checked")) {
                            if (!finished[0]) {
                                finished[0] = true;
                                handleBrowserLicenseCheck(url, checkWeb, showToast);
                            }
                            return true;
                        }
                        return false;
                    }

                    @Override
                    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(checkWeb);
                            handleLicenseServerUnavailable(showToast);
                        }
                    }
                });

                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(dp(2), dp(2));
                params.gravity = Gravity.BOTTOM | Gravity.RIGHT;
                webContainer.addView(checkWeb, params);

                try {
                    String url = server + "/check-app.php"
                            + "?key=" + URLEncoder.encode(key, "UTF-8")
                            + "&token=" + URLEncoder.encode(token, "UTF-8")
                            + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                            + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8");
                    checkWeb.loadUrl(url);
                } catch (Exception error) {
                    finished[0] = true;
                    removeCheckWebView(checkWeb);
                    handleLicenseServerUnavailable(showToast);
                    return;
                }

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!finished[0]) {
                            finished[0] = true;
                            removeCheckWebView(checkWeb);
                            handleLicenseServerUnavailable(showToast);
                        }
                    }
                }, 20000L);
            }
        });
    }

    private void handleBrowserLicenseCheck(String url, WebView checkWeb, boolean showToast) {
        removeCheckWebView(checkWeb);
        try {
            Uri uri = Uri.parse(url);
            String ok = uri.getQueryParameter("ok");
            String code = uri.getQueryParameter("code");
            String message = uri.getQueryParameter("message");
            long expiryMillis = parseServerMillis(uri.getQueryParameter("expires_at"));
            long serverMillis = parseServerMillis(uri.getQueryParameter("server_time"));
            long createdMillis = parseServerMillis(uri.getQueryParameter("created_at"));
            String durationLabel = uri.getQueryParameter("duration_label");

            if ("1".equals(ok) && expiryMillis > 0) {
                if (serverMillis <= 0) serverMillis = System.currentTimeMillis();
                preferences.edit()
                        .putLong(PREF_LICENSE_EXPIRY, expiryMillis)
                        .putLong(PREF_LICENSE_CREATED, createdMillis > 0 ? createdMillis : preferences.getLong(PREF_LICENSE_CREATED, 0L))
                        .putString(PREF_LICENSE_DURATION_LABEL, durationLabel == null ? preferences.getString(PREF_LICENSE_DURATION_LABEL, "") : durationLabel)
                        .putLong(PREF_LAST_SERVER_TIME, serverMillis)
                        .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                        .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                        .apply();
                licenseUnlocked = true;
                updateLicenseBadgeFromCache();
                if (showToast) Toast.makeText(MainActivity.this,
                        message == null ? "Lisensi masih aktif" : message,
                        Toast.LENGTH_SHORT).show();
                return;
            }

            if ("revoked".equals(code) || "expired".equals(code)
                    || "invalid".equals(code) || "not_found".equals(code)) {
                lockLicense(message == null ? "Lisensi tidak aktif." : message);
                return;
            }

            handleLicenseServerUnavailable(showToast);
        } catch (Exception error) {
            handleLicenseServerUnavailable(showToast);
        }
    }

    private void removeCheckWebView(final WebView view) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (view.getParent() instanceof ViewGroup) {
                        ((ViewGroup)view.getParent()).removeView(view);
                    }
                    view.stopLoading();
                    view.destroy();
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void handleLicenseServerUnavailable(boolean showToast) {
        // Mode kerja untuk WiFi perusahaan: kalau server tidak bisa dicek karena tidak ada internet,
        // APK tetap boleh masuk hanya jika lisensi pernah valid online, belum expired, dan masih dalam batas toleransi.
        if (canUseOfflineWorkMode()) {
            licenseUnlocked = true;
            setLicenseBadge("OFFLINE", Color.rgb(202, 138, 4));
            setStatus("Mode kerja offline aktif. Server lisensi tidak terjangkau, tapi key masih dalam batas toleransi dan belum expired.");
            startBrowserIfNeeded();
            if (showToast) {
                Toast.makeText(MainActivity.this,
                        "Mode kerja offline aktif. Nanti saat internet tersedia lisensi dicek ulang.",
                        Toast.LENGTH_LONG).show();
            }
            return;
        }

        lockLicense("Server lisensi tidak bisa dicek dan batas mode kerja offline habis / key belum aktif / sudah expired.");
        if (showToast) {
            Toast.makeText(MainActivity.this,
                    "Hubungkan internet untuk cek lisensi ulang.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void lockLicense(final String reason) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                licenseUnlocked = false;
                runtimeSessionToken = "";
                runtimeUsername = "";
                runtimeSessionExpiry = 0L;
                setLicenseBadge("TERKUNCI", Color.rgb(185, 28, 28));
                setStatus(reason);
                showActivationDialog(true);
            }
        });
    }

    private boolean canUseOfflineWorkMode() {
        if (ADMIN_BUILD) return true;
        if (!licenseUnlocked) return false;
        if (runtimeUsername.length() == 0 || runtimeSessionToken.length() == 0) return false;
        if (!isCachedLicenseValid()) return false;
        long elapsedAtLastSuccess = preferences.getLong(PREF_LAST_SERVER_ELAPSED, 0L);
        if (elapsedAtLastSuccess > 0) {
            long delta = SystemClock.elapsedRealtime() - elapsedAtLastSuccess;
            return delta >= 0 && delta <= OFFLINE_WORK_GRACE_MS;
        }
        long lastCheck = preferences.getLong(PREF_LAST_CHECK, 0L);
        return lastCheck > 0 && System.currentTimeMillis() - lastCheck <= OFFLINE_WORK_GRACE_MS;
    }

    private boolean isCachedLicenseValid() {
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        if (expiry <= 0) return false;
        return trustedNowMillis() < expiry;
    }

    private long trustedNowMillis() {
        long wall = System.currentTimeMillis();
        long server = preferences.getLong(PREF_LAST_SERVER_TIME, 0L);
        long elapsedAtServer = preferences.getLong(PREF_LAST_SERVER_ELAPSED, 0L);

        if (server > 0 && elapsedAtServer > 0) {
            long delta = SystemClock.elapsedRealtime() - elapsedAtServer;
            if (delta >= 0) {
                // Gunakan waktu server yang berjalan dengan elapsedRealtime, bukan jam HP.
                return server + delta;
            }
        }
        return wall;
    }

    private void updateLicenseBadgeFromCache() {
        if (ADMIN_BUILD) {
            setLicenseBadge("ADMIN", Color.rgb(147, 51, 234));
            return;
        }
        long expiry = preferences.getLong(PREF_LICENSE_EXPIRY, 0L);
        if (expiry > trustedNowMillis()) {
            long remaining = expiry - trustedNowMillis();
            setLicenseBadge(shortRemaining(remaining), Color.rgb(22, 163, 74));
        } else {
            setLicenseBadge("HABIS", Color.rgb(185, 28, 28));
        }
    }

    private void setLicenseBadge(final String text, final int color) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (licenseBadge != null) {
                    licenseBadge.setText(text);
                    licenseBadge.setBackground(makeRounded(color, dp(14)));
                }
            }
        });
    }

    private String shortRemaining(long millis) {
        long minutes = Math.max(0, millis / 60000L);
        if (minutes < 60) return minutes + "m";
        long hours = minutes / 60;
        if (hours < 24) return hours + "j";
        long days = hours / 24;
        if (days < 365) return days + "h";
        return (days / 365) + "th";
    }

    private String longRemaining(long millis) {
        long totalMinutes = Math.max(0L, millis / 60000L);
        long days = totalMinutes / 1440L;
        long hours = (totalMinutes % 1440L) / 60L;
        long minutes = totalMinutes % 60L;
        StringBuilder out = new StringBuilder();
        if (days > 0) out.append(days).append(" hari ");
        if (hours > 0 || days > 0) out.append(hours).append(" jam ");
        out.append(minutes).append(" menit");
        return out.toString().trim();
    }

    private String formatDate(long millis) {
        SimpleDateFormat format = new SimpleDateFormat("dd MMM yyyy HH:mm", new Locale("id", "ID"));
        format.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));
        return format.format(new Date(millis));
    }

    private void postApi(final String endpoint, final Map<String, String> params, final ApiCallback callback) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                JSONObject data = null;
                String error = null;
                boolean success = false;

                try {
                    StringBuilder body = new StringBuilder();
                    for (Map.Entry<String, String> entry : params.entrySet()) {
                        if (body.length() > 0) body.append('&');
                        body.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                        body.append('=');
                        body.append(URLEncoder.encode(entry.getValue() == null ? "" : entry.getValue(), "UTF-8"));
                    }

                    URL targetUrl = new URL(endpoint);
                    connection = (HttpURLConnection) targetUrl.openConnection();
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(12000);
                    connection.setRequestMethod("POST");
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
                    connection.setRequestProperty("Accept", "application/json");
                    connection.setRequestProperty("User-Agent", "ICE-Inject/2.3 Android");

                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream(), "UTF-8");
                    writer.write(body.toString());
                    writer.flush();
                    writer.close();

                    int code = connection.getResponseCode();
                    InputStream stream = code >= 200 && code < 400
                            ? connection.getInputStream()
                            : connection.getErrorStream();
                    String response = readStream(stream);
                    if (response.length() > 0) data = jsonFromText(response);
                    success = code >= 200 && code < 300 && data != null;
                    if (data == null && response != null && response.trim().startsWith("<")) {
                        error = "Server membalas HTML, bukan JSON. Gunakan metode WebView/Buka Web.";
                    } else if (data == null) {
                        error = "Respons server kosong atau bukan JSON.";
                    } else if (!success) {
                        error = data.optString("message", "HTTP " + code);
                    }
                } catch (Throwable throwable) {
                    error = throwable.getMessage();
                    if (error == null || error.length() == 0) error = throwable.getClass().getSimpleName();
                } finally {
                    if (connection != null) connection.disconnect();
                }

                final boolean finalSuccess = success;
                final JSONObject finalData = data;
                final String finalError = error;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.onResult(finalSuccess, finalData, finalError);
                    }
                });
            }
        }).start();
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) output.append(line);
        reader.close();
        return output.toString();
    }

    private String getInstallDeviceId() {
        String id = null;
        try {
            id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Throwable ignored) {}

        if (id == null || id.length() < 6) {
            id = preferences.getString(PREF_DEVICE_ID, "");
            if (id.length() < 6) {
                id = "ICE-" + Long.toHexString(System.currentTimeMillis()) + "-" + Integer.toHexString((int) (Math.random() * Integer.MAX_VALUE));
                preferences.edit().putString(PREF_DEVICE_ID, id).apply();
            }
        }
        return id;
    }

    private String normalizeKey(String value) {
        return value == null ? "" : value.trim().toUpperCase(Locale.US).replace(' ', '-');
    }

    private String normalizeUsernameLocal(String value) {
        if (value == null) return "";
        String v = value.trim().toLowerCase(Locale.US);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-') {
                out.append(c);
            }
        }
        return out.toString();
    }

    private String normalizeServerUrl(String value) {
        String url = value == null ? "" : value.trim();
        if (url.length() == 0) return "";
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    private String normalizeUrl(String value) {
        String url = value == null ? "" : value.trim();
        if (url.length() == 0) return DEFAULT_URL;
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        return url;
    }

    private String shortUrl(String url) {
        if (url == null) return "website";
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            return host == null ? url : host;
        } catch (Throwable ignored) {
            return url;
        }
    }

    private String maskKey(String key) {
        if (key == null || key.length() < 8) return "-";
        return key.substring(0, Math.min(7, key.length())) + "••••" + key.substring(Math.max(0, key.length() - 4));
    }

    private String quoteJs(String value) {
        if (value == null) return "\"\"";
        StringBuilder out = new StringBuilder(value.length() + 16);
        out.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '\\': out.append("\\\\"); break;
                case '"': out.append("\\\""); break;
                case '\n': out.append("\\n"); break;
                case '\r': out.append("\\r"); break;
                case '\t': out.append("\\t"); break;
                case '\b': out.append("\\b"); break;
                case '\f': out.append("\\f"); break;
                default:
                    if (c < 32 || c > 126) {
                        String hex = Integer.toHexString(c);
                        out.append("\\u");
                        for (int j = hex.length(); j < 4; j++) out.append('0');
                        out.append(hex);
                    } else {
                        out.append(c);
                    }
            }
        }
        out.append('"');
        return out.toString();
    }

    private String readAsset(String name) {
        StringBuilder output = new StringBuilder();
        try {
            InputStream stream = getAssets().open(name);
            BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
            String line;
            while ((line = reader.readLine()) != null) output.append(line).append('\n');
            reader.close();
        } catch (Throwable ignored) {
            return "";
        }
        return output.toString();
    }

    private void setStatus(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (statusText != null) statusText.setText(message == null ? "" : message);
            }
        });
    }

    private void updateCallbackBadge(final int count) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (callbackBadge != null) {
                    callbackBadge.setText("CB: " + count);
                    callbackBadge.setBackground(makeRounded(
                            count > 0 ? Color.rgb(22, 163, 74) : Color.rgb(71, 85, 105),
                            dp(14)));
                }
            }
        });
    }

    private void startQrPhotoCapture() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        multiPhotoCaptureMode = false;
        if (!hasCameraPermission()) {
            pendingPhotoCaptureAfterPermission = true;
            requestPermissionsCompat(
                    new String[] { "android.permission.CAMERA" },
                    CAMERA_PERMISSION_REQUEST,
                    "Berikan izin kamera untuk Foto QR.");
            return;
        }
        launchSinglePhotoCamera();
    }

    private void startMultiQrPhotoCapture() {
        if (!licenseUnlocked) {
            showActivationDialog(true);
            return;
        }
        if (batchManualSingleMode || batchAwaitingResult) {
            Toast.makeText(this, "Tunggu kirim manual selesai", Toast.LENGTH_SHORT).show();
            return;
        }

        // Foto banyak dimaksudkan untuk mengumpulkan kode terlebih dahulu,
        // jadi antrean aktif dijeda agar tidak ikut terkirim saat kamera terbuka.
        if (batchRunning && !batchPaused) {
            batchPaused = true;
            handler.removeCallbacks(batchRunnable);
            updateBatchUi();
        }

        multiPhotoCaptureMode = true;
        multiPhotoAdded = 0;
        multiPhotoDuplicates = 0;
        multiPhotoFailed = 0;

        if (!hasCameraPermission()) {
            pendingPhotoCaptureAfterPermission = true;
            requestPermissionsCompat(
                    new String[] { "android.permission.CAMERA" },
                    CAMERA_PERMISSION_REQUEST,
                    "Berikan izin kamera untuk mode Foto Banyak.");
            return;
        }
        launchMultiPhotoCamera();
    }

    private void launchMultiPhotoCamera() {
        try {
            Intent intent = new Intent(this, MultiPhotoCameraActivity.class);
            intent.putExtra(MultiPhotoCameraActivity.EXTRA_MODE, MultiPhotoCameraActivity.MODE_QUEUE);
            startActivityForResult(intent, MULTI_PHOTO_QR_REQUEST);
            setStatus("Mode foto banyak aktif. Hasil langsung masuk antrean tanpa mengisi kolom.");
        } catch (Throwable error) {
            multiPhotoFailed++;
            finishMultiPhotoCapture();
            setStatus("Kamera foto banyak gagal dibuka: " + safeError(error));
            Toast.makeText(this, "Kamera foto banyak gagal dibuka", Toast.LENGTH_LONG).show();
        }
    }

    private void launchSinglePhotoCamera() {
        try {
            Intent intent = new Intent(this, MultiPhotoCameraActivity.class);
            intent.putExtra(MultiPhotoCameraActivity.EXTRA_MODE, MultiPhotoCameraActivity.MODE_SINGLE);
            startActivityForResult(intent, IN_APP_PHOTO_QR_REQUEST);
            setStatus("Kamera QR dalam aplikasi dibuka. Jepret satu QR.");
        } catch (Throwable error) {
            setStatus("Kamera QR gagal dibuka: " + safeError(error));
            Toast.makeText(this, "Kamera QR gagal dibuka", Toast.LENGTH_LONG).show();
        }
    }

    private void launchQrCamera() {
        cleanupPendingQrPhoto();
        try {
            File photoDir = new File(getCacheDir(), "qr_photos");
            if (!photoDir.exists() && !photoDir.mkdirs()) {
                throw new IllegalStateException("Folder cache kamera tidak dapat dibuat");
            }
            pendingQrPhotoFile = File.createTempFile("qr_", ".jpg", photoDir);
            pendingQrPhotoUri = QrPhotoProvider.getUriForFile(this, pendingQrPhotoFile);

            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, pendingQrPhotoUri);
            cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= 16) {
                cameraIntent.setClipData(ClipData.newRawUri("Foto QR", pendingQrPhotoUri));
            }
            startActivityForResult(cameraIntent, PHOTO_QR_REQUEST);
            if (multiPhotoCaptureMode) {
                setStatus("Mode foto banyak: jepret QR. Kamera terbuka lagi otomatis; tekan Kembali jika selesai.");
            } else {
                setStatus("Arahkan kamera ke QR lalu jepret.");
            }
        } catch (Throwable error) {
            cleanupPendingQrPhoto();
            if (multiPhotoCaptureMode) {
                multiPhotoFailed++;
                finishMultiPhotoCapture();
            }
            setStatus("Kamera tidak dapat dibuka: " + safeError(error));
            Toast.makeText(this, "Kamera tidak dapat dibuka", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == QR_EXPORT_REQUEST) {
            if (resultCode == RESULT_OK && data != null) writeQrBackup(data.getData());
            return;
        }
        if (requestCode == QR_IMPORT_REQUEST) {
            if (resultCode == RESULT_OK && data != null) readQrBackup(data.getData());
            return;
        }
        if (requestCode == IN_APP_PHOTO_QR_REQUEST) {
            if (resultCode != RESULT_OK || data == null) {
                setStatus("Foto QR dibatalkan.");
                return;
            }
            String result = data.getStringExtra(MultiPhotoCameraActivity.EXTRA_CODE);
            result = result == null ? "" : result.trim();
            if (result.length() == 0) {
                setStatus("Hasil foto QR kosong.");
                Toast.makeText(this, "QR tidak terbaca", Toast.LENGTH_SHORT).show();
                return;
            }
            if (codeInput != null) codeInput.setText(result);
            setStatus("Hasil foto: " + result + " • mengirim ke scanner…");
            Toast.makeText(this, "Terbaca: " + result, Toast.LENGTH_LONG).show();
            sendCodeValue(result, true);
            return;
        }
        if (requestCode == MULTI_PHOTO_QR_REQUEST) {
            // Cadangan jika broadcast sempat terlewat: pastikan seluruh kode hasil sesi
            // tetap masuk ke antrean, tanpa pernah mengisi kolom ketik.
            if (data != null) {
                ArrayList<String> codes = data.getStringArrayListExtra("codes");
                if (codes != null) {
                    for (String raw : codes) {
                        String code = raw == null ? "" : raw.trim();
                        if (code.length() == 0 || batchSeen.containsKey(code)) continue;
                        if (addPhotoCodeToBatch(code)) multiPhotoAdded++;
                    }
                }
                multiPhotoFailed = Math.max(multiPhotoFailed, data.getIntExtra("failed", 0));
            }
            finishMultiPhotoCapture();
            return;
        }
        if (requestCode != PHOTO_QR_REQUEST) return;

        if (resultCode != RESULT_OK) {
            cleanupPendingQrPhoto();
            if (multiPhotoCaptureMode) {
                finishMultiPhotoCapture();
            } else {
                setStatus("Foto QR dibatalkan.");
            }
            return;
        }

        final boolean batchPhoto = multiPhotoCaptureMode;
        final File photoFile = pendingQrPhotoFile;
        final Bitmap fallbackBitmap = extractCameraThumbnail(data);
        pendingQrPhotoFile = null;
        pendingQrPhotoUri = null;
        setStatus(batchPhoto ? "Membaca foto lalu menambahkannya ke antrean…" : "Membaca QR dari foto…");

        new Thread(new Runnable() {
            @Override
            public void run() {
                String decoded = "";
                String errorText = "QR tidak ditemukan. Jepret lebih dekat dan pastikan tidak buram.";
                Bitmap bitmap = null;
                try {
                    if (photoFile != null && photoFile.exists() && photoFile.length() > 0) {
                        bitmap = decodeScaledBitmap(photoFile, 2600);
                    }
                    if (bitmap == null) bitmap = fallbackBitmap;
                    if (bitmap == null) {
                        errorText = "Hasil foto kamera kosong.";
                    } else {
                        decoded = decodeBarcodeFromBitmap(bitmap);
                    }
                } catch (NotFoundException ignored) {
                    // Gunakan pesan panduan default agar pengguna dapat langsung mencoba ulang.
                } catch (Throwable error) {
                    errorText = "Gagal membaca foto: " + safeError(error);
                } finally {
                    if (bitmap != null && !bitmap.isRecycled()) {
                        try { bitmap.recycle(); } catch (Throwable ignored) {}
                    }
                    if (fallbackBitmap != null && fallbackBitmap != bitmap && !fallbackBitmap.isRecycled()) {
                        try { fallbackBitmap.recycle(); } catch (Throwable ignored) {}
                    }
                    if (photoFile != null) {
                        try { photoFile.delete(); } catch (Throwable ignored) {}
                    }
                }

                final String result = decoded == null ? "" : decoded.trim();
                final String finalError = errorText;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!batchPhoto) {
                            if (result.length() == 0) {
                                setStatus(finalError);
                                Toast.makeText(MainActivity.this, finalError, Toast.LENGTH_LONG).show();
                                return;
                            }
                            if (codeInput != null) codeInput.setText(result);
                            setStatus("QR foto terbaca. Mengirim ke scanner…");
                            sendCodeValue(result, true);
                            Toast.makeText(MainActivity.this,
                                    "QR terbaca dan langsung dikirim",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }

                        if (!multiPhotoCaptureMode) return;

                        if (result.length() == 0) {
                            multiPhotoFailed++;
                            setStatus(finalError + " Gagal: " + multiPhotoFailed
                                    + ". Kamera dibuka lagi; tekan Kembali jika selesai.");
                            Toast.makeText(MainActivity.this,
                                    "QR tidak terbaca, silakan jepret ulang",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            boolean added = addPhotoCodeToBatch(result);
                            if (added) {
                                multiPhotoAdded++;
                                setStatus("Masuk antrean: " + result + " • sesi " + multiPhotoAdded
                                        + " • total antrean " + batchQueue.size());
                            } else {
                                multiPhotoDuplicates++;
                                setStatus("Duplikat dilewati: " + result + " • duplikat sesi "
                                        + multiPhotoDuplicates);
                            }
                        }

                        // Foto telah diubah menjadi teks dan file cache telah dihapus.
                        // Buka kamera lagi agar pengguna bisa terus menjepret tanpa batas tetap.
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                if (multiPhotoCaptureMode && !isFinishing()
                                        && (Build.VERSION.SDK_INT < 17 || !isDestroyed())) {
                                    launchQrCamera();
                                }
                            }
                        }, 350L);
                    }
                });
            }
        }, batchPhoto ? "ice-photo-queue" : "ice-photo-qr").start();
    }

    private boolean addPhotoCodeToBatch(String rawCode) {
        String code = rawCode == null ? "" : rawCode.trim();
        if (code.length() == 0) return false;
        if (batchSeen.containsKey(code)) {
            batchDuplicates++;
            persistBatchState();
            updateBatchUi();
            return false;
        }
        batchSeen.put(code, true);
        batchQueue.add(code);
        persistBatchState();
        updateBatchUi();
        return true;
    }

    private void finishMultiPhotoCapture() {
        if (!multiPhotoCaptureMode) return;
        multiPhotoCaptureMode = false;
        cleanupPendingQrPhoto();

        final String summary = "Foto banyak selesai: " + multiPhotoAdded + " masuk antrean"
                + (multiPhotoDuplicates > 0 ? ", " + multiPhotoDuplicates + " duplikat" : "")
                + (multiPhotoFailed > 0 ? ", " + multiPhotoFailed + " gagal dibaca" : "")
                + ". Total antrean " + batchQueue.size() + ".";
        setStatus(summary);
        Toast.makeText(this, summary, Toast.LENGTH_LONG).show();

        // Tidak membuka kolom atau dialog secara paksa. Kode sudah langsung berada
        // di Antrean QR dan pengguna dapat menekan tombol antrean saat siap mengirim.
        updateBatchUi();
    }

    private Bitmap extractCameraThumbnail(Intent data) {
        if (data == null || data.getExtras() == null) return null;
        try {
            Object value = data.getExtras().get("data");
            return value instanceof Bitmap ? (Bitmap) value : null;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private Bitmap decodeScaledBitmap(File file, int maxSide) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        int sample = 1;
        while ((bounds.outWidth / sample) > maxSide || (bounds.outHeight / sample) > maxSide) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = Math.max(1, sample);
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeFile(file.getAbsolutePath(), options);
    }

    private String decodeBarcodeFromBitmap(Bitmap bitmap) throws Exception {
        int[] rotations = new int[] { 0, 90, 180, 270 };
        Exception lastError = null;
        for (int degrees : rotations) {
            Bitmap candidate = degrees == 0 ? bitmap : rotateBitmap(bitmap, degrees);
            try {
                String value = decodeBarcodeCandidate(candidate);
                if (value != null && value.trim().length() > 0) return value.trim();
            } catch (Exception error) {
                lastError = error;
            } finally {
                if (candidate != bitmap && candidate != null && !candidate.isRecycled()) {
                    candidate.recycle();
                }
            }
        }
        if (lastError != null) throw lastError;
        throw NotFoundException.getNotFoundInstance();
    }

    private Bitmap rotateBitmap(Bitmap source, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(source, 0, 0,
                source.getWidth(), source.getHeight(), matrix, true);
    }

    private String decodeBarcodeCandidate(Bitmap bitmap) throws Exception {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        LuminanceSource source = new RGBLuminanceSource(width, height, pixels);

        EnumMap<DecodeHintType, Object> hints = new EnumMap<DecodeHintType, Object>(DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Arrays.asList(
                BarcodeFormat.QR_CODE,
                BarcodeFormat.DATA_MATRIX,
                BarcodeFormat.AZTEC,
                BarcodeFormat.PDF_417,
                BarcodeFormat.CODE_128,
                BarcodeFormat.CODE_39,
                BarcodeFormat.EAN_13,
                BarcodeFormat.EAN_8,
                BarcodeFormat.UPC_A,
                BarcodeFormat.UPC_E,
                BarcodeFormat.ITF,
                BarcodeFormat.CODABAR));

        MultiFormatReader reader = new MultiFormatReader();
        reader.setHints(hints);
        try {
            Result result = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(source)));
            return result == null ? "" : result.getText();
        } catch (NotFoundException first) {
            reader.reset();
            try {
                Result result = reader.decodeWithState(
                        new BinaryBitmap(new GlobalHistogramBinarizer(source)));
                return result == null ? "" : result.getText();
            } catch (NotFoundException second) {
                reader.reset();
                Result result = reader.decodeWithState(
                        new BinaryBitmap(new HybridBinarizer(source.invert())));
                return result == null ? "" : result.getText();
            }
        } finally {
            reader.reset();
        }
    }

    private void cleanupPendingQrPhoto() {
        File oldFile = pendingQrPhotoFile;
        pendingQrPhotoFile = null;
        pendingQrPhotoUri = null;
        if (oldFile != null) {
            try { oldFile.delete(); } catch (Throwable ignored) {}
        }
    }

    private String safeError(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        if (message == null || message.trim().length() == 0) {
            message = error.getClass().getSimpleName();
        }
        return message;
    }

    private void registerMultiPhotoReceiver() {
        if (multiPhotoReceiverRegistered) return;
        IntentFilter filter = new IntentFilter(MultiPhotoCameraActivity.ACTION_RESULT);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(multiPhotoResultReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(multiPhotoResultReceiver, filter);
            }
            multiPhotoReceiverRegistered = true;
        } catch (Throwable ignored) {}
    }

    private boolean hasPermission(String permission) {
        if (Build.VERSION.SDK_INT < 23) return true;
        try {
            Method method = Activity.class.getMethod("checkSelfPermission", String.class);
            Object result = method.invoke(this, permission);
            return result instanceof Integer && ((Integer) result) == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean hasCameraPermission() {
        return hasPermission("android.permission.CAMERA");
    }

    private boolean hasLocationPermission() {
        return hasPermission("android.permission.ACCESS_FINE_LOCATION")
                || hasPermission("android.permission.ACCESS_COARSE_LOCATION");
    }

    private void requestPermissionsCompat(String[] permissions, int requestCode, String errorText) {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            Method method = Activity.class.getMethod("requestPermissions", String[].class, int.class);
            method.invoke(this, new Object[] { permissions, requestCode });
        } catch (Throwable ignored) {
            setStatus(errorText);
        }
    }

    private void requestCameraPermissionIfNeeded() {
        if (hasCameraPermission() || Build.VERSION.SDK_INT < 23) return;
        requestPermissionsCompat(
                new String[] { "android.permission.CAMERA" },
                CAMERA_PERMISSION_REQUEST,
                "Berikan izin kamera dari Pengaturan aplikasi.");
    }

    private void requestLocationPermissionIfNeeded() {
        if (hasLocationPermission() || Build.VERSION.SDK_INT < 23) return;
        requestPermissionsCompat(
                new String[] {
                        "android.permission.ACCESS_FINE_LOCATION",
                        "android.permission.ACCESS_COARSE_LOCATION"
                },
                LOCATION_PERMISSION_REQUEST,
                "Berikan izin lokasi dari Pengaturan aplikasi.");
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        boolean granted = grantResults != null && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED;

        if (requestCode == CAMERA_PERMISSION_REQUEST) {
            if (granted) {
                if (pendingPermissionRequest != null) {
                    pendingPermissionRequest.grant(pendingPermissionRequest.getResources());
                    pendingPermissionRequest = null;
                }
                setStatus("Izin kamera diberikan.");
                if (pendingPhotoCaptureAfterPermission) {
                    pendingPhotoCaptureAfterPermission = false;
                    if (multiPhotoCaptureMode) launchMultiPhotoCamera();
                    else launchSinglePhotoCamera();
                }
            } else {
                pendingPhotoCaptureAfterPermission = false;
                multiPhotoCaptureMode = false;
                if (pendingPermissionRequest != null) {
                    pendingPermissionRequest.deny();
                    pendingPermissionRequest = null;
                }
                setStatus("Izin kamera ditolak. Aktifkan dari Pengaturan aplikasi.");
            }
            return;
        }

        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            if ((granted || hasLocationPermission())
                    && pendingGeolocationCallback != null && pendingGeolocationOrigin != null) {
                pendingGeolocationCallback.invoke(pendingGeolocationOrigin, true, false);
                setStatus("Izin lokasi diberikan.");
            } else if (pendingGeolocationCallback != null && pendingGeolocationOrigin != null) {
                pendingGeolocationCallback.invoke(pendingGeolocationOrigin, false, false);
                setStatus("Izin lokasi ditolak. Aktifkan dari Pengaturan aplikasi.");
            }
            pendingGeolocationCallback = null;
            pendingGeolocationOrigin = null;
        }
    }

    private Button smallButton(String text) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(makeRounded(Color.rgb(51, 65, 85), dp(9)));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(36));
        params.setMargins(dp(4), 0, 0, 0);
        button.setLayoutParams(params);
        applyPressFeedback(button);
        return button;
    }


    private String accountInitials(String name) {
        if (name == null || name.trim().length() == 0) return "QR";
        String[] parts = name.trim().split("\\s+");
        String first = parts[0].substring(0, 1);
        String second = parts.length > 1 ? parts[parts.length - 1].substring(0, 1) :
                (parts[0].length() > 1 ? parts[0].substring(1, 2) : "");
        return (first + second).toUpperCase(new Locale("id", "ID"));
    }

    private Button qrActionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(11);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(3), dp(3), dp(3), dp(3));
        button.setBackground(makeRounded(color, dp(13)));
        applyPressFeedback(button);
        return button;
    }

    private Button actionButton(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setPadding(dp(6), 0, dp(6), 0);
        button.setBackground(makeRounded(color, dp(10)));
        applyPressFeedback(button);
        return button;
    }



    /** Umpan balik sentuhan yang ringan dan aman untuk tombol. */
    private void applyPressFeedback(final View target) {
        if (target == null) return;
        target.setHapticFeedbackEnabled(true);
        target.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                int action = event.getAction();
                if (action == MotionEvent.ACTION_DOWN) {
                    view.setAlpha(0.72f);
                    view.setScaleX(0.97f);
                    view.setScaleY(0.97f);
                    view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
                } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    view.setAlpha(1.0f);
                    view.setScaleX(1.0f);
                    view.setScaleY(1.0f);
                }
                return false;
            }
        });
    }

    private GradientDrawable makeRounded(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return (int) (value * density + 0.5f);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            if (toolsVisible) hideTools(); else showTools();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_BACK && currentTab != null && currentTab.webView.canGoBack()) {
            currentTab.webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }


    @Override
    protected void onPause() {
        super.onPause();
        if (batchManualSingleMode) {
            cancelManualBatchSend("Kirim manual dibatalkan karena aplikasi tidak aktif. Kode tetap di antrean.");
        } else if (batchRunning && !batchPaused) {
            batchPaused = true;
            handler.removeCallbacks(batchRunnable);
            updateBatchUi();
            setStatus("Antrean QR dijeda karena aplikasi tidak aktif.");
        }
        for (TabState tab : tabs) {
            if (tab.destroyed) continue;
            try {
                tab.webView.onPause();
                if (tab != currentTab) tab.webView.pauseTimers();
            } catch (Throwable ignored) {}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        for (TabState tab : tabs) {
            if (tab.destroyed) continue;
            try {
                tab.webView.onResume();
                if (tab == currentTab) tab.webView.resumeTimers();
            } catch (Throwable ignored) {}
        }
        if (!ADMIN_BUILD) {
            // Jika sesi masih hidup, cek server saat kembali aktif. Jika proses APK mati, token memori hilang dan harus login ulang.
            if (licenseUnlocked && runtimeSessionToken.length() > 0) {
                preferences.edit().putLong(PREF_LAST_CHECK, 0L).apply();
                validateLicenseAsync(false);
                startLicenseWatchdog();
            }
        }
    }

    @Override
    protected void onDestroy() {
        runtimeSessionToken = "";
        runtimeUsername = "";
        runtimeSessionExpiry = 0L;
        preferences.edit().remove(PREF_LICENSE_TOKEN).remove(PREF_LICENSE_EXPIRY).apply();
        handler.removeCallbacksAndMessages(null);
        for (TabState tab : new ArrayList<TabState>(tabs)) {
            tab.destroyed = true;
            tab.webView.removeJavascriptInterface("AndroidBridge");
            tab.webView.destroy();
        }
        tabs.clear();
        if (multiPhotoReceiverRegistered) {
            try { unregisterReceiver(multiPhotoResultReceiver); } catch (Throwable ignored) {}
            multiPhotoReceiverRegistered = false;
        }
        multiPhotoCaptureMode = false;
        cleanupPendingQrPhoto();
        super.onDestroy();
    }

    public class AndroidBridge {
        private final TabState tab;

        AndroidBridge(TabState tab) {
            this.tab = tab;
        }

        @JavascriptInterface
        public void copyHandoverCodes(final String codes, final int expectedCount) {
            if (codes == null || codes.trim().length() == 0) return;
            final String clean = codes.trim();
            final String signature = Integer.toHexString(clean.hashCode()) + ":" + clean.length();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    tab.lastHandoverClipboardSignature = signature;
                    try {
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        clipboard.setPrimaryClip(ClipData.newPlainText("Kode HU Handover", clean));
                        int count = clean.split("\\r?\\n").length;
                        String detail = expectedCount > 0 ? count + " dari " + expectedCount : String.valueOf(count);
                        Toast.makeText(MainActivity.this, detail + " kode HU berhasil disalin", Toast.LENGTH_LONG).show();
                        if (tab == currentTab) setStatus(detail + " kode HU sudah ada di clipboard");
                    } catch (Throwable error) {
                        if (tab == currentTab) setStatus("Gagal menyalin kode HU: " + error.getMessage());
                    }
                }
            });
        }

        @JavascriptInterface
        public void onStatus(String message) {
            if (tab == currentTab) setStatus(message);
        }

        @JavascriptInterface
        public void onCallbackCount(final int count) {
            tab.callbackCount = count;
            if (tab == currentTab) updateCallbackBadge(count);
        }

        @JavascriptInterface
        public void onSendReport(final String report) {
            // Laporan tetap lokal di perangkat. Untuk antrean massal, ini menjadi
            // konfirmasi bahwa kode benar-benar sudah diproses bridge, bukan baru masuk antrean JS.
            try {
                final JSONObject data = new JSONObject(report == null ? "{}" : report);
                final String requestId = data.optString("requestId", "");
                if (!requestId.startsWith("batch:")) return;
                final int token = Integer.parseInt(requestId.substring(6));
                final String code = data.optString("text", "");
                final boolean ok = data.optBoolean("ok", false);
                final String reason = data.optString("reason", ok ? "" : "delivery_failed");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        handleBatchDeliveryReport(token, code, ok, reason);
                    }
                });
            } catch (Throwable ignored) {}
        }
    }
}
