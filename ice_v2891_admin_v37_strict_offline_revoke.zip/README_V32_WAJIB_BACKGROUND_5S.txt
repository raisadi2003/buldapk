ICE v2.8.9.1 v32 — WAJIB LATAR BELAKANG + CEK LISENSI 5 DETIK

Variant: ADMIN

Perubahan utama:
1. User wajib memberikan izin notifikasi pada Android 13 ke atas.
2. User wajib membebaskan ICE dari optimasi baterai pada Android 6 ke atas.
3. Jika izin wajib ditolak/dimatikan, ICE diblokir dan proses aplikasi ditutup.
4. Foreground service memeriksa status lisensi setiap 5 detik setelah pemeriksaan sebelumnya selesai.
5. Judul notifikasi foreground service: ICE INJECT.
6. Fitur Centang Hijau Semua URL tetap ada dan tidak menekan submit.

Catatan Android/OEM:
- Android tidak menyediakan satu API universal untuk mendeteksi semua menu Auto-start/background milik Tecno, Xiaomi, Oppo, dan vendor lain.
- Pemeriksaan yang diwajibkan source ini adalah izin notifikasi dan pengecualian optimasi baterai, yaitu kontrol standar Android yang dapat diverifikasi aplikasi.
