ICE v21 — Visual Touch Feedback

- Tombol menampilkan efek tekan saat disentuh atau ditahan.
- Kontrol mengecil sedikit dan berubah transparansi selama ditekan.
- Getaran ringan digunakan jika perangkat mendukung.
- Efek dilepas otomatis saat jari diangkat, dibatalkan, atau digeser keluar.
- Diterapkan pada toolbar, navigasi bawah, Menu ICE, dialog, dan tombol akun QR.
