package com.mimar.iceinject.admin;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.*;

import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String HOME = "http://lp4m-lpw.liebrapermana.com/";
    private static final int REQ_PERMS = 404;
    private GeckoRuntime runtime;
    private GeckoView geckoView;
    private EditText address;
    private ProgressBar progress;
    private LinearLayout tabStrip;
    private final List<Tab> tabs = new ArrayList<>();
    private int current = -1;
    private boolean desktopMode = false;
    private GeckoSession.PermissionDelegate.Callback pendingPermission;

    private static final class Tab {
        GeckoSession session;
        String title = "Tab Baru";
        String url = HOME;
        boolean canBack;
        boolean canForward;
        Button chip;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
        GeckoRuntimeSettings settings = new GeckoRuntimeSettings.Builder()
                .javaScriptEnabled(true)
                .aboutConfigEnabled(false)
                .allowInsecureConnections(GeckoRuntimeSettings.ALLOW_ALL)
                .trustedRecursiveResolverMode(GeckoRuntimeSettings.TRR_MODE_DISABLED)
                .consoleOutput(false)
                .build();
        runtime = GeckoRuntime.create(this, settings);
        // dohAutoselectEnabled bukan API Builder. Matikan setelah runtime dibuat.
        runtime.getSettings().setTrustedRecursiveResolverMode(GeckoRuntimeSettings.TRR_MODE_DISABLED);
        requestCorePermissions();
        newTab(HOME);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(248,250,252));
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),dp(6),dp(8),dp(6));
        Button back = button("‹"), forward = button("›"), reload = button("↻"), menu = button("⋮");
        address = new EditText(this); address.setSingleLine(true); address.setTextSize(14); address.setHint("Alamat atau pencarian");
        address.setImeOptions(EditorInfo.IME_ACTION_GO); address.setLayoutParams(new LinearLayout.LayoutParams(0,dp(44),1));
        bar.addView(back); bar.addView(forward); bar.addView(reload); bar.addView(address); bar.addView(menu);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); progress.setMax(100); progress.setVisibility(View.GONE);
        HorizontalScrollView scroll = new HorizontalScrollView(this); scroll.setHorizontalScrollBarEnabled(false);
        tabStrip = new LinearLayout(this); tabStrip.setPadding(dp(6),dp(3),dp(6),dp(3)); scroll.addView(tabStrip);
        geckoView = new GeckoView(this); geckoView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        root.addView(bar); root.addView(progress,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(3))); root.addView(scroll,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(42))); root.addView(geckoView);
        setContentView(root);
        back.setOnClickListener(v -> { Tab t=active(); if(t!=null && t.canBack)t.session.goBack(); });
        forward.setOnClickListener(v -> { Tab t=active(); if(t!=null && t.canForward)t.session.goForward(); });
        reload.setOnClickListener(v -> { Tab t=active(); if(t!=null)t.session.reload(); });
        menu.setOnClickListener(v -> showMenu());
        address.setOnEditorActionListener((v,id,e)->{ if(id==EditorInfo.IME_ACTION_GO || (e!=null&&e.getKeyCode()==KeyEvent.KEYCODE_ENTER)){ load(address.getText().toString()); return true;} return false; });
    }

    private Button button(String text) { Button b=new Button(this); b.setText(text); b.setTextSize(22); b.setAllCaps(false); b.setMinWidth(0); b.setMinimumWidth(0); b.setPadding(dp(10),0,dp(10),0); b.setLayoutParams(new LinearLayout.LayoutParams(dp(44),dp(44))); return b; }

    private void newTab(String url) {
        Tab tab = new Tab();
        GeckoSessionSettings sessionSettings = new GeckoSessionSettings.Builder().userAgentMode(desktopMode ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP : GeckoSessionSettings.USER_AGENT_MODE_MOBILE).build();
        tab.session = new GeckoSession(sessionSettings);
        attachDelegates(tab);
        tab.session.open(runtime);
        tabs.add(tab);
        Button chip = new Button(this); chip.setAllCaps(false); chip.setText("Tab " + tabs.size()); chip.setTextSize(12); chip.setSingleLine(true); chip.setOnClickListener(v -> switchTab(tabs.indexOf(tab))); chip.setOnLongClickListener(v -> { closeTab(tabs.indexOf(tab)); return true; });
        tab.chip=chip; tabStrip.addView(chip,new LinearLayout.LayoutParams(dp(125),dp(38)));
        switchTab(tabs.size()-1);
        tab.session.loadUri(normalize(url));
    }

    private void attachDelegates(final Tab tab) {
        tab.session.setProgressDelegate(new GeckoSession.ProgressDelegate() {
            @Override public void onPageStart(GeckoSession s,String url){ tab.url=url; if(s==activeSession()){address.setText(url);progress.setVisibility(View.VISIBLE);} }
            @Override public void onProgressChange(GeckoSession s,int p){ if(s==activeSession())progress.setProgress(p); }
            @Override public void onPageStop(GeckoSession s,boolean ok){ if(s==activeSession())progress.setVisibility(View.GONE); if(!ok && s==activeSession()) Toast.makeText(MainActivity.this,"Halaman gagal dimuat. Tekan muat ulang.",Toast.LENGTH_SHORT).show(); }
        });
        tab.session.setNavigationDelegate(new GeckoSession.NavigationDelegate() {
            @Override public void onLocationChange(GeckoSession s,String url,List<GeckoSession.PermissionDelegate.ContentPermission> perms,Boolean gesture){ if(url!=null){tab.url=url;if(s==activeSession())address.setText(url);} }
            @Override public void onCanGoBack(GeckoSession s,boolean value){tab.canBack=value;}
            @Override public void onCanGoForward(GeckoSession s,boolean value){tab.canForward=value;}
        });
        tab.session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override public void onTitleChange(GeckoSession s,String title){ if(title!=null&&!title.isEmpty()){tab.title=title;tab.chip.setText(title);} }
            @Override public void onExternalResponse(GeckoSession s,org.mozilla.geckoview.WebResponse response){ try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(response.uri))); }catch(Throwable e){Toast.makeText(MainActivity.this,"Unduhan tidak dapat dibuka",Toast.LENGTH_SHORT).show();} }
            @Override public void onCrash(GeckoSession s){ recover(tab); }
            @Override public void onKill(GeckoSession s){ recover(tab); }
        });
        tab.session.setPermissionDelegate(new GeckoSession.PermissionDelegate() {
            @Override public void onAndroidPermissionsRequest(GeckoSession s,String[] permissions,Callback callback){
                if(Build.VERSION.SDK_INT<23){callback.grant();return;} pendingPermission=callback; requestPermissions(permissions,REQ_PERMS);
            }
            @Override public GeckoResult<Integer> onContentPermissionRequest(GeckoSession s,ContentPermission perm){ return GeckoResult.fromValue(ContentPermission.VALUE_ALLOW); }
            @Override public void onMediaPermissionRequest(GeckoSession s,String uri,MediaSource[] video,MediaSource[] audio,MediaCallback callback){
                MediaSource v=(video!=null&&video.length>0)?video[0]:null; MediaSource a=(audio!=null&&audio.length>0)?audio[0]:null; callback.grant(v,a);
            }
        });
    }

    private void recover(Tab tab){ try{tab.session.open(runtime);tab.session.loadUri(tab.url);}catch(Throwable ignored){} }
    private void switchTab(int index){ if(index<0||index>=tabs.size())return; current=index; geckoView.setSession(tabs.get(index).session); address.setText(tabs.get(index).url); for(int i=0;i<tabs.size();i++)tabs.get(i).chip.setEnabled(i!=index); }
    private void closeTab(int index){ if(index<0||index>=tabs.size())return; Tab t=tabs.remove(index); try{t.session.close();}catch(Throwable ignored){} tabStrip.removeView(t.chip); if(tabs.isEmpty()){current=-1;newTab(HOME);}else switchTab(Math.min(index,tabs.size()-1)); }
    private Tab active(){return current>=0&&current<tabs.size()?tabs.get(current):null;}
    private GeckoSession activeSession(){Tab t=active();return t==null?null:t.session;}
    private void load(String value){Tab t=active();if(t!=null)t.session.loadUri(normalize(value));}
    private String normalize(String value){String s=value==null?"":value.trim();if(s.isEmpty())return HOME;if(s.contains(" "))return "https://www.google.com/search?q="+Uri.encode(s);if(!s.contains("://"))return "http://"+s;return s;}

    private void showMenu(){
        String[] items={"Tab baru","Tutup tab","Beranda perusahaan",desktopMode?"Mode seluler":"Mode desktop","Muat ulang paksa","Status DNS"};
        new AlertDialog.Builder(this).setTitle("ICE 404 Gecko").setItems(items,(d,w)->{
            if(w==0)newTab(HOME); else if(w==1)closeTab(current); else if(w==2)load(HOME); else if(w==3)toggleDesktop(); else if(w==4){Tab t=active();if(t!=null){String u=t.url;t.session.stop();t.session.loadUri(u);}} else new AlertDialog.Builder(this).setTitle("DNS ICE").setMessage("DNS over HTTPS: MATI\nResolver: DNS bawaan Wi-Fi/sistem\nMesin: Mozilla GeckoView 152").setPositiveButton("OK",null).show();
        }).show();
    }
    private void toggleDesktop(){desktopMode=!desktopMode;Tab t=active();if(t!=null){t.session.getSettings().setUserAgentMode(desktopMode?GeckoSessionSettings.USER_AGENT_MODE_DESKTOP:GeckoSessionSettings.USER_AGENT_MODE_MOBILE);t.session.reload();}Toast.makeText(this,desktopMode?"Mode desktop aktif":"Mode seluler aktif",Toast.LENGTH_SHORT).show();}
    private void requestCorePermissions(){if(Build.VERSION.SDK_INT>=23){ArrayList<String> p=new ArrayList<>();for(String s:new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO,Manifest.permission.ACCESS_FINE_LOCATION})if(checkSelfPermission(s)!=PackageManager.PERMISSION_GRANTED)p.add(s);if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),REQ_PERMS);}}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_PERMS&&pendingPermission!=null){boolean ok=true;for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED)ok=false;if(ok)pendingPermission.grant();else pendingPermission.reject();pendingPermission=null;}}
    @Override public void onBackPressed(){Tab t=active();if(t!=null&&t.canBack)t.session.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){for(Tab t:tabs)try{t.session.close();}catch(Throwable ignored){}super.onDestroy();}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
