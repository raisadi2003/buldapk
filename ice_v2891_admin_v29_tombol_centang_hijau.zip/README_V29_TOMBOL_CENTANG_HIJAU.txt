# ICE v2.8.9.1 V29 — Tombol Centang Semua Hijau

Fitur baru:
- Menu gelembung ICE memiliki tombol `Centang Semua Hijau`.
- Fitur hanya berjalan setelah tombol ditekan.
- Tidak ada auto-centang saat halaman dibuka atau tabel berubah.
- Tombol hanya bekerja pada `/PackingAccuracy/Index`.
- Memilih semua input pada kolom `PASSED` hijau.
- Tidak memilih kolom `FAILED`.
- Tidak menekan Submit/Kirim; pengiriman tetap manual.

Build:
- Admin: `build_admin.sh`
- User: `build_user.sh`
- Workflow gabungan: `.github/workflows/build-admin-user-from-zips.yml`
