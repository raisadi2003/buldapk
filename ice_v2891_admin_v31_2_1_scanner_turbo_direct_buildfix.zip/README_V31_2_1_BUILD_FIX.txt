ICE v31.2.1 Scanner Turbo Direct - Build Fix

Perbaikan:
- Memperbaiki error compile Java pada TurboScannerActivity.
- setResult(...) kini dipanggil melalui TurboScannerActivity.this agar tidak bentrok dengan BroadcastReceiver.setResult(...).
- Alur scanner tetap: terbaca -> langsung diproses website -> kamera tertutup pada mode otomatis.
- Submit/finalisasi pekerjaan tetap manual.

Varian: Admin
