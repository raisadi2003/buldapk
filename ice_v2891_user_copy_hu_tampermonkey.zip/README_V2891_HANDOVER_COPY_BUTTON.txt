ICE v2.8.9.1 User - Tombol Copy HU
- Tombol COPY HU muncul di halaman Picked Material Handover Scanner.
- Tombol dapat ditekan berulang kali dan selalu membaca ulang HU operator yang sedang tampil.
- Semua kode HU disalin satu per baris ke clipboard.
