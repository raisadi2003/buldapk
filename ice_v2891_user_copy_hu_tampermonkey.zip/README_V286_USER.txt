ICE Inject User v2.8.6

FITUR BARU — FOTO BANYAK KE ANTREAN
- Tombol baru: "Jepret Banyak → Antrean".
- Kamera dibuka untuk satu jepretan, hasil langsung dibaca, lalu kamera terbuka kembali otomatis.
- Setiap QR/barcode yang berhasil dibaca hanya ditambahkan ke antrean; belum langsung dikirim ke website.
- Jepretan dapat diteruskan tanpa batas tetap selama memori perangkat masih mencukupi.
- File foto disimpan hanya sementara di cache dan langsung dihapus setelah dibaca, sehingga tidak masuk galeri dan tidak menumpuk.
- Kode duplikat otomatis dilewati.
- Foto buram/tidak terbaca dihitung gagal dan kamera dibuka lagi untuk mencoba ulang.
- Tekan tombol Kembali pada kamera untuk mengakhiri sesi. Dialog Antrean QR otomatis terbuka.
- Tekan Mulai pada dialog antrean untuk mengirim kode satu per satu dengan jeda yang sudah diatur.
- Jika antrean sedang berjalan saat mode ini dimulai, antrean dijeda otomatis agar seluruh foto terkumpul dahulu.

FITUR FOTO SATUAN TETAP ADA
- Tombol "Foto QR lalu scan" tetap langsung membaca dan mengirim satu kode.

VERSI
- Nama aplikasi: ICE Inject
- Package: com.mimar.iceinject
- Version code: 26
- Version name: 2.8.6
- Mode user / ADMIN_BUILD=false.

CATATAN BUILD
- Gunakan workflow build-apk.yml versi terbaru karena workflow lama masih mencari nama APK v2.8.5.
- Source memakai compile SDK 34, Android Gradle Plugin 8.5.2, Gradle 8.7, dan Java 17.
- Repository yang memuat folder signing wajib Private.
