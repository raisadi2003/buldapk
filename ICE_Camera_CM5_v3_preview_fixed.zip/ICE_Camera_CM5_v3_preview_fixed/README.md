# ICE Camera CM5 v3

Perbaikan utama:
- Preview tidak lagi memakai `fillCenter` yang memotong gambar dan terlihat zoom.
- Preview dan hasil foto memakai rasio yang sama (4:3 atau 16:9).
- Pilihan kualitas foto / mode cepat.
- Zoom manual, kompensasi pencahayaan, fokus sentuh, grid, timer, flash.
- Foto depan otomatis dicerminkan seperti kamera selfie.
- Video FHD/HD, kamera depan-belakang, dan galeri.

Catatan: AI Beauty, Super Night, Portrait proprietary, Live Photo Tecno, dan akses 50 MP/ultrawide tidak dapat dijamin karena memerlukan API privat Tecno/MediaTek.
