ICE v1.1 - perubahan identitas aplikasi

ADMIN
- Application name: ICE Admin
- Package/Application ID: com.mimar.iceinject.admin
- versionCode: 37
- versionName: 1.1-admin
- Launcher icon: logo ICE hijau khusus Admin
- Splash screen: hijau gelap + logo ICE Admin
- Runtime APP_VERSION: 1.1 Admin

USER
- Application name: ICE User
- Package/Application ID: com.mimar.iceinject.user
- versionCode: 37
- versionName: 1.1-user
- Launcher icon: logo lama tetap
- Splash screen: gelap + logo lama
- Runtime APP_VERSION: 1.1 User

Catatan struktur:
- namespace dan package source Java tetap com.mimar.iceinject.
- applicationId dipisah agar Admin dan User dapat terpasang bersamaan tanpa bentrok.
- provider authority memakai ${applicationId}.fileprovider sehingga otomatis ikut unik.
- IceSplashTheme dipakai saat launch, lalu MainActivity mengganti ke IceTheme.
