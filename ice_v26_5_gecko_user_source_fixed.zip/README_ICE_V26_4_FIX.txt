ICE v26.4 Gecko build fix
- Mengaktifkan AndroidX yang diwajibkan dependency GeckoView/Media3.
- android.useAndroidX=true
- android.enableJetifier=true
- JVM heap build dinaikkan menjadi 3 GB.
- DNS over HTTPS tetap dimatikan melalui TRR_MODE_DISABLED.
