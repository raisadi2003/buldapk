ICE v26.2 Gecko API Fix

Perbaikan build:
- Menghapus pemanggilan dohAutoselectEnabled(false) dari GeckoRuntimeSettings.Builder karena method tersebut tidak tersedia pada Builder GeckoView.
- DoH autoselect dimatikan sesudah GeckoRuntime dibuat melalui runtime.getSettings().setDohAutoselectEnabled(false).
- TRR/DoH tetap dipaksa TRR_MODE_DISABLED.
- Version code dinaikkan ke 33.
