ICE v26.3 Gecko build fix
- Menghapus pemanggilan setDohAutoselectEnabled(false) yang tidak tersedia pada GeckoRuntimeSettings versi ini.
- DNS over HTTPS tetap dimatikan dengan trustedRecursiveResolverMode(TRR_MODE_DISABLED), sehingga DNS memakai resolver native Wi-Fi/sistem.
- compileSdk 36, Java 17, AGP 8.10.1.
