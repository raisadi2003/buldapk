ICE v26.5 Gecko build fix
- minSdk dinaikkan dari API 23 ke API 26 sesuai persyaratan GeckoView 152.
- compileSdk/targetSdk tetap API 36.
- AndroidX dan Jetifier tetap aktif.
- Java 17 dan Gradle 8.11.1.
- DoH Gecko tetap dinonaktifkan melalui TRR_MODE_DISABLED.
