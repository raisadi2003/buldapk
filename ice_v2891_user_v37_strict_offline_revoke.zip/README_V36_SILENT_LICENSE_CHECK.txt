ICE v2.8.9.1 v36 — Silent License Check

Perubahan:
- Pemeriksaan lisensi realtime dan polling 5 detik tetap aktif.
- Popup “ICE INJECT — Memeriksa status lisensi terbaru” dihapus.
- Scanner, WebView, antrean QR, dan tombol browser tetap dapat digunakan selama pemeriksaan rutin.
- Pemeriksaan aktif berhasil berlangsung tanpa toast/status yang mengganggu.
- Jika akun nonaktif, dicabut, diblokir, atau expired, ICE tetap langsung mengunci dan menampilkan login.
- Login ulang setelah aplikasi benar-benar ditutup tetap dipertahankan.
- Notifikasi foreground service ICE INJECT tetap wajib agar pemantauan latar belakang stabil.
