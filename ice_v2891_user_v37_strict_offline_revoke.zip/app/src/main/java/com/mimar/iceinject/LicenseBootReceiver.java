package com.mimar.iceinject;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Menyalakan kembali pemantauan lisensi setelah boot atau aplikasi diperbarui. */
public class LicenseBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null) return;
        // Restart HP, unlock pertama, atau update aplikasi selalu mengakhiri sesi browser.
        LicenseBackgroundService.requireLoginOnNextOpen(context);
        if (LicenseBackgroundService.shouldRun(context)) {
            LicenseBackgroundService.start(context);
        }
    }
}
