package com.mimar.iceinject;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.SystemClock;

/** Alarm cadangan untuk OEM yang mematikan foreground service setelah Recent Apps dibersihkan. */
public class LicenseServiceRestartReceiver extends BroadcastReceiver {
    private static final int REQUEST_CODE = 289134;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context != null && LicenseBackgroundService.shouldRun(context)) {
            LicenseBackgroundService.start(context);
        }
    }

    public static void schedule(Context context, long delayMs) {
        if (context == null || !LicenseBackgroundService.shouldRun(context)) return;
        try {
            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (alarm == null) return;
            Intent intent = new Intent(context, LicenseServiceRestartReceiver.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
            long trigger = SystemClock.elapsedRealtime() + Math.max(1000L, delayMs);
            try {
                if (Build.VERSION.SDK_INT >= 23) {
                    alarm.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                } else if (Build.VERSION.SDK_INT >= 19) {
                    alarm.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                } else {
                    alarm.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                }
            } catch (Throwable exactDenied) {
                if (Build.VERSION.SDK_INT >= 23) {
                    alarm.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                } else {
                    alarm.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pending);
                }
            }
        } catch (Throwable ignored) {}
    }
}
