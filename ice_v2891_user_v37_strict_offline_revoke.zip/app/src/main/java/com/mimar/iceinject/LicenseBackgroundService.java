package com.mimar.iceinject;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Foreground service untuk menyinkronkan status lisensi ketika Activity ICE diminimalkan.
 * Service memakai WebView mini karena beberapa hosting gratis membutuhkan cookie/JavaScript.
 */
public class LicenseBackgroundService extends Service {
    public static final String ACTION_LICENSE_UPDATED = "com.mimar.iceinject.action.LICENSE_UPDATED";
    public static final String EXTRA_STATE = "state";

    public static final String STATE_ACTIVE = "active";
    public static final String STATE_BLOCKED = "blocked";
    public static final String STATE_OFFLINE = "offline";
    public static final String STATE_CHECKING = "checking";

    private static final String PREFS = "ice_inject_prefs";
    private static final String PREF_LICENSE_SERVER = "license_server";
    private static final String PREF_LICENSE_KEY = "license_key";
    private static final String PREF_LICENSE_TOKEN = "license_token";
    private static final String PREF_LICENSE_EXPIRY = "license_expiry_ms";
    private static final String PREF_LICENSE_CREATED = "license_created_ms";
    private static final String PREF_LICENSE_DURATION_LABEL = "license_duration_label";
    private static final String PREF_LAST_SERVER_TIME = "last_server_time_ms";
    private static final String PREF_LAST_SERVER_ELAPSED = "last_server_elapsed_ms";
    private static final String PREF_LAST_CHECK = "last_license_check_ms";
    private static final String PREF_DEVICE_ID = "device_id_fallback";
    public static final String PREF_BG_MONITOR_ENABLED = "license_bg_monitor_enabled";
    public static final String PREF_BG_STATE = "license_bg_state";
    public static final String PREF_BG_REASON = "license_bg_reason";
    public static final String PREF_BG_LAST_RESULT = "license_bg_last_result_ms";
    public static final String PREF_APP_FOREGROUND = "ice_app_foreground";
    public static final String PREF_LOGIN_REQUIRED = "ice_interactive_login_required";
    // Latch keamanan: sekali server menyatakan akun nonaktif, cache offline tidak boleh dipakai lagi.
    public static final String PREF_SECURITY_BLOCKED = "license_security_blocked";
    // Nomor verifikasi dipakai untuk memastikan ada hasil server baru setelah pengguna meninggalkan ICE.
    public static final String PREF_REQUIRED_VERIFY_SEQ = "license_required_verify_seq";
    public static final String PREF_CONFIRMED_VERIFY_SEQ = "license_confirmed_verify_seq";
    public static final String PREF_REVERIFY_AFTER_BACKGROUND = "license_reverify_after_background";

    private static final String DEFAULT_LICENSE_SERVER = "https://accuracy.fwh.is";
    private static final String APP_VERSION = "2.8.9.1 User v37";
    private static final String CHANNEL_ID = "ice_license_monitor";
    private static final int NOTIFICATION_ID = 289131;
    private static final long PERIODIC_CHECK_MS = 5_000L;
    private static final long RETRY_CHECK_MS = 5_000L;
    private static final long WEB_TIMEOUT_MS = 25_000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences preferences;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;
    private BroadcastReceiver legacyConnectivityReceiver;
    private WebView checkWebView;
    private Network previousBoundNetwork;
    private boolean processNetworkBound;
    private boolean checkInProgress;
    private boolean immediateCheckPending;
    private boolean destroyed;
    private int checkGeneration;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();
    private volatile HttpURLConnection activeConnection;

    private final Runnable periodicCheck = new Runnable() {
        @Override
        public void run() {
            performLicenseCheck();
        }
    };

    public static void start(Context context) {
        if (context == null) return;
        Intent intent = new Intent(context, LicenseBackgroundService.class);
        intent.setAction("com.mimar.iceinject.action.CHECK_LICENSE_NOW");
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } catch (Throwable ignored) {
            try { context.startService(intent); } catch (Throwable ignoredAgain) {}
        }
    }

    public static boolean shouldRun(Context context) {
        if (context == null) return false;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return !prefs.getBoolean(PREF_SECURITY_BLOCKED, false)
                && prefs.getBoolean(PREF_BG_MONITOR_ENABLED, false)
                && normalizeStaticUsername(prefs.getString(PREF_LICENSE_KEY, "")).length() >= 3
                && prefs.getString(PREF_LICENSE_TOKEN, "").length() > 0;
    }

    private static String normalizeStaticUsername(String value) {
        if (value == null) return "";
        String source = value.trim().toLowerCase(Locale.US);
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < source.length(); i++) {
            char c = source.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-') {
                output.append(c);
            }
        }
        return output.toString();
    }

    public static void requireLoginOnNextOpen(Context context) {
        if (context == null) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(PREF_LOGIN_REQUIRED, true)
                .putBoolean(PREF_APP_FOREGROUND, false)
                .apply();
    }

    /**
     * Dipanggil hanya ketika pengguna benar-benar meninggalkan ICE (Home/app lain),
     * bukan saat dialog atau Activity internal dibuka. Service harus menghasilkan
     * konfirmasi aktif baru sebelum cache boleh dipakai lagi tanpa internet.
     */
    public static void markBackgroundVerificationRequired(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int current = prefs.getInt(PREF_REQUIRED_VERIFY_SEQ, 0);
        int next = current >= 2_000_000_000 ? 1 : current + 1;
        prefs.edit()
                .putInt(PREF_REQUIRED_VERIFY_SEQ, next)
                .putBoolean(PREF_REVERIFY_AFTER_BACKGROUND, true)
                .putBoolean(PREF_APP_FOREGROUND, false)
                .commit();
    }

    public static void stop(Context context, boolean clearSession) {
        if (context == null) return;
        if (clearSession) clearStoredSession(context);
        try { context.stopService(new Intent(context, LicenseBackgroundService.class)); } catch (Throwable ignored) {}
    }

    public static void clearStoredSession(Context context) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit()
                .remove(PREF_LICENSE_TOKEN)
                .remove(PREF_LICENSE_EXPIRY)
                .remove(PREF_LICENSE_CREATED)
                .putBoolean(PREF_BG_MONITOR_ENABLED, false)
                .putBoolean(PREF_APP_FOREGROUND, false)
                .putBoolean(PREF_LOGIN_REQUIRED, true)
                .putString(PREF_BG_STATE, "")
                .putString(PREF_BG_REASON, "")
                .putLong(PREF_LAST_CHECK, 0L)
                .apply();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        preferences = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Menyiapkan pemeriksaan lisensi…"));
        registerConnectivityWatch();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (preferences.getBoolean(PREF_SECURITY_BLOCKED, false)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!hasStoredSession()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!hasMandatoryBackgroundAccess()) {
            preferences.edit()
                    .putString(PREF_BG_STATE, STATE_BLOCKED)
                    .putString(PREF_BG_REASON, "Izin notifikasi atau aktivitas latar belakang dinonaktifkan.")
                    .putLong(PREF_BG_LAST_RESULT, System.currentTimeMillis())
                    .putBoolean(PREF_BG_MONITOR_ENABLED, false)
                    .putBoolean(PREF_LOGIN_REQUIRED, true)
                    .remove(PREF_LICENSE_TOKEN)
                    .remove(PREF_LICENSE_EXPIRY)
                    .apply();
            broadcastState(STATE_BLOCKED);
            stopSelf();
            return START_NOT_STICKY;
        }
        preferences.edit().putBoolean(PREF_BG_MONITOR_ENABLED, true).apply();
        requestImmediateLicenseCheck("Layanan lisensi aktif");
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // v35: swipe dari Recent Apps adalah penutupan nyata, bukan minimize.
        // Credential tetap dipakai service untuk memantau lisensi, tetapi browser wajib login ulang.
        requireLoginOnNextOpen(this);
        if (hasStoredSession()) {
            requestImmediateLicenseCheck("ICE ditutup • login ulang wajib • lisensi tetap dipantau");
            LicenseServiceRestartReceiver.schedule(this, 1500L);
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        boolean restartRequired = hasStoredSession();
        destroyed = true;
        immediateCheckPending = false;
        handler.removeCallbacksAndMessages(null);
        unregisterConnectivityWatch();
        disconnectActiveConnection();
        try { networkExecutor.shutdownNow(); } catch (Throwable ignored) {}
        destroyCheckWebView();
        restoreProcessNetwork();
        if (restartRequired) LicenseServiceRestartReceiver.schedule(this, 2000L);
        super.onDestroy();
    }

    private void registerConnectivityWatch() {
        if (connectivityManager == null) return;
        if (Build.VERSION.SDK_INT >= 21) {
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    // Android 21-22 belum memiliki NET_CAPABILITY_VALIDATED.
                    // Mulai cek segera; Android 23+ akan dipicu lagi saat internet benar-benar tervalidasi.
                    if (Build.VERSION.SDK_INT < 23) {
                        requestImmediateLicenseCheck("Jaringan tersedia");
                    }
                }

                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities capabilities) {
                    if (capabilities == null
                            || !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                        return;
                    }
                    boolean validated = Build.VERSION.SDK_INT < 23
                            || capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                    if (validated) {
                        requestImmediateLicenseCheck("Internet tersambung");
                    }
                }

                @Override
                public void onLost(Network network) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!destroyed && !hasValidatedInternetNetwork()) {
                                markOffline("Menunggu koneksi internet/data");
                                scheduleCheck(RETRY_CHECK_MS);
                            }
                        }
                    });
                }
            };
            try {
                NetworkRequest request = new NetworkRequest.Builder()
                        .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        .build();
                connectivityManager.registerNetworkCallback(request, networkCallback);
            } catch (Throwable ignored) {}
        } else {
            legacyConnectivityReceiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    requestImmediateLicenseCheck("Perubahan jaringan");
                }
            };
            try {
                registerReceiver(legacyConnectivityReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
            } catch (Throwable ignored) {}
        }
    }

    private void unregisterConnectivityWatch() {
        if (connectivityManager != null && networkCallback != null) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Throwable ignored) {}
            networkCallback = null;
        }
        if (legacyConnectivityReceiver != null) {
            try { unregisterReceiver(legacyConnectivityReceiver); } catch (Throwable ignored) {}
            legacyConnectivityReceiver = null;
        }
    }

    private boolean hasMandatoryBackgroundAccess() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (manager == null || !manager.areNotificationsEnabled()) return false;
                if (Build.VERSION.SDK_INT >= 26) {
                    NotificationChannel channel = manager.getNotificationChannel(CHANNEL_ID);
                    if (channel != null && channel.getImportance() == NotificationManager.IMPORTANCE_NONE) {
                        return false;
                    }
                }
            } catch (Throwable ignored) {
                return false;
            }
        }
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (powerManager == null || !powerManager.isIgnoringBatteryOptimizations(getPackageName())) {
                    return false;
                }
            } catch (Throwable ignored) {
                return false;
            }
        }
        return true;
    }

    private void scheduleCheck(long delayMs) {
        if (destroyed) return;
        handler.removeCallbacks(periodicCheck);
        handler.postDelayed(periodicCheck, Math.max(0L, delayMs));
    }

    /**
     * Memicu pemeriksaan event-driven tanpa menunggu polling 5 detik.
     * Semua perubahan state dijalankan pada main looper agar tidak terjadi dua WebView pemeriksa bersamaan.
     */
    private void requestImmediateLicenseCheck(final String reason) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (destroyed || !hasStoredSession()) return;
                if (checkInProgress) {
                    immediateCheckPending = true;
                    return;
                }
                if (reason != null && reason.length() > 0) {
                    updateNotification(reason + " • memeriksa lisensi…");
                }
                scheduleCheck(0L);
            }
        });
    }

    private void scheduleNextCheck(long normalDelayMs) {
        if (immediateCheckPending) {
            immediateCheckPending = false;
            scheduleCheck(0L);
        } else {
            scheduleCheck(normalDelayMs);
        }
    }

    private boolean hasStoredSession() {
        return !preferences.getBoolean(PREF_SECURITY_BLOCKED, false)
                && preferences.getBoolean(PREF_BG_MONITOR_ENABLED, false)
                && normalizeUsername(preferences.getString(PREF_LICENSE_KEY, "")).length() >= 3
                && preferences.getString(PREF_LICENSE_TOKEN, "").length() > 0;
    }

    private Network chooseInternetNetwork() {
        if (connectivityManager == null || Build.VERSION.SDK_INT < 21) return null;
        Network fallbackValidated = null;
        Network fallbackInternet = null;
        try {
            Network[] networks = connectivityManager.getAllNetworks();
            if (networks == null) return null;
            for (Network network : networks) {
                NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(network);
                if (caps == null || !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) continue;
                if (fallbackInternet == null) fallbackInternet = network;
                boolean validated = Build.VERSION.SDK_INT < 23
                        || caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                if (!validated) continue;
                if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return network;
                if (fallbackValidated == null) fallbackValidated = network;
            }
        } catch (Throwable ignored) {}
        return fallbackValidated != null ? fallbackValidated : fallbackInternet;
    }

    private boolean hasInternetNetwork() {
        if (Build.VERSION.SDK_INT >= 21) return chooseInternetNetwork() != null;
        if (connectivityManager == null) return false;
        try {
            NetworkInfo info = connectivityManager.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean hasValidatedInternetNetwork() {
        if (connectivityManager == null) return false;
        if (Build.VERSION.SDK_INT < 23) return hasInternetNetwork();
        try {
            Network[] networks = connectivityManager.getAllNetworks();
            if (networks == null) return false;
            for (Network network : networks) {
                NetworkCapabilities caps = connectivityManager.getNetworkCapabilities(network);
                if (caps != null
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                    return true;
                }
            }
        } catch (Throwable ignored) {}
        return false;
    }

    private void bindProcessForLicenseCheck(Network network) {
        if (connectivityManager == null || network == null || Build.VERSION.SDK_INT < 23) return;
        try {
            previousBoundNetwork = connectivityManager.getBoundNetworkForProcess();
            processNetworkBound = connectivityManager.bindProcessToNetwork(network);
        } catch (Throwable ignored) {
            processNetworkBound = false;
            previousBoundNetwork = null;
        }
    }

    private void restoreProcessNetwork() {
        if (!processNetworkBound || connectivityManager == null || Build.VERSION.SDK_INT < 23) return;
        try { connectivityManager.bindProcessToNetwork(previousBoundNetwork); } catch (Throwable ignored) {}
        processNetworkBound = false;
        previousBoundNetwork = null;
    }

    private void performLicenseCheck() {
        if (!hasMandatoryBackgroundAccess()) {
            preferences.edit()
                    .putString(PREF_BG_STATE, STATE_BLOCKED)
                    .putString(PREF_BG_REASON, "Izin notifikasi atau aktivitas latar belakang dinonaktifkan.")
                    .putLong(PREF_BG_LAST_RESULT, System.currentTimeMillis())
                    .putBoolean(PREF_BG_MONITOR_ENABLED, false)
                    .putBoolean(PREF_LOGIN_REQUIRED, true)
                    .remove(PREF_LICENSE_TOKEN)
                    .remove(PREF_LICENSE_EXPIRY)
                    .apply();
            broadcastState(STATE_BLOCKED);
            stopSelf();
            return;
        }
        if (destroyed) return;
        if (checkInProgress) {
            immediateCheckPending = true;
            return;
        }
        if (!hasStoredSession()) {
            stopSelf();
            return;
        }
        if (!hasInternetNetwork()) {
            markOffline("Menunggu koneksi internet/data");
            scheduleCheck(RETRY_CHECK_MS);
            return;
        }

        final Network internetNetwork = chooseInternetNetwork();
        final String server = normalizeServerUrl(preferences.getString(PREF_LICENSE_SERVER, DEFAULT_LICENSE_SERVER));
        final String username = normalizeUsername(preferences.getString(PREF_LICENSE_KEY, ""));
        final String token = preferences.getString(PREF_LICENSE_TOKEN, "");
        if (server.length() == 0 || username.length() < 3 || token.length() == 0) {
            stopSelf();
            return;
        }

        checkInProgress = true;
        final int generation = ++checkGeneration;
        preferences.edit()
                .putString(PREF_BG_STATE, STATE_CHECKING)
                .putString(PREF_BG_REASON, "Memeriksa status lisensi terbaru…")
                .apply();
        broadcastState(STATE_CHECKING);
        updateNotification("Mengecek pembaruan lisensi…");
        disconnectActiveConnection();
        destroyCheckWebView();
        restoreProcessNetwork();
        startHttpLicenseCheck(internetNetwork, server, username, token, generation);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isCurrentCheck(generation)) {
                    finishAsOffline("Timeout pemeriksaan lisensi", generation);
                }
            }
        }, WEB_TIMEOUT_MS);
    }

    private void startHttpLicenseCheck(final Network internetNetwork, final String server,
                                       final String username, final String token, final int generation) {
        networkExecutor.execute(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                try {
                    String urlText = buildCheckUrl(server, username, token);
                    URL endpoint = new URL(urlText);
                    if (Build.VERSION.SDK_INT >= 21 && internetNetwork != null) {
                        connection = (HttpURLConnection) internetNetwork.openConnection(endpoint);
                    } else {
                        connection = (HttpURLConnection) endpoint.openConnection();
                    }
                    activeConnection = connection;
                    connection.setConnectTimeout(9000);
                    connection.setReadTimeout(9000);
                    connection.setUseCaches(false);
                    connection.setRequestMethod("GET");
                    connection.setRequestProperty("Accept", "application/json,text/plain,*/*");
                    connection.setRequestProperty("Cache-Control", "no-cache, no-store");
                    connection.setRequestProperty("Pragma", "no-cache");
                    connection.setRequestProperty("User-Agent", "ICE-INJECT/" + APP_VERSION);
                    int responseCode = connection.getResponseCode();
                    InputStream stream = responseCode >= 200 && responseCode < 400
                            ? connection.getInputStream() : connection.getErrorStream();
                    final String responseText = readStreamText(stream);
                    final JSONObject data = jsonFromText(responseText);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentCheck(generation)) return;
                            activeConnection = null;
                            if (data != null) {
                                handleServerJson(data, generation);
                            } else {
                                startWebViewFallback(internetNetwork, server, username, token, generation);
                            }
                        }
                    });
                } catch (final Throwable error) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (!isCurrentCheck(generation)) return;
                            activeConnection = null;
                            startWebViewFallback(internetNetwork, server, username, token, generation);
                        }
                    });
                } finally {
                    if (connection != null) {
                        try { connection.disconnect(); } catch (Throwable ignored) {}
                    }
                }
            }
        });
    }

    private void startWebViewFallback(Network internetNetwork, String server,
                                      String username, String token, final int generation) {
        if (!isCurrentCheck(generation)) return;
        destroyCheckWebView();
        restoreProcessNetwork();
        bindProcessForLicenseCheck(internetNetwork);
        try {
            checkWebView = new WebView(LicenseBackgroundService.this);
            WebSettings settings = checkWebView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.setAcceptCookie(true);
            if (Build.VERSION.SDK_INT >= 21) {
                try {
                    Method method = CookieManager.class.getMethod("setAcceptThirdPartyCookies", WebView.class, boolean.class);
                    method.invoke(cookieManager, checkWebView, true);
                } catch (Throwable ignored) {}
            }

            checkWebView.setWebChromeClient(new WebChromeClient());
            checkWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(final WebView view, String url) {
                    if (!isCurrentCheck(generation)) return;
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            readWebResult(view, generation, 0);
                        }
                    }, 650L);
                }

                @Override
                public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                    if (!isCurrentCheck(generation)) return;
                    finishAsOffline(description == null ? "Server lisensi tidak tersambung" : description, generation);
                }
            });
            checkWebView.loadUrl(buildCheckUrl(server, username, token));
        } catch (Throwable error) {
            finishAsOffline(error.getMessage() == null ? "Gagal membuka server lisensi" : error.getMessage(), generation);
        }
    }

    private String buildCheckUrl(String server, String username, String token) throws Exception {
        return server + "/check-session.php"
                + "?username=" + URLEncoder.encode(username, "UTF-8")
                + "&session_token=" + URLEncoder.encode(token, "UTF-8")
                + "&device_id=" + URLEncoder.encode(getInstallDeviceId(), "UTF-8")
                + "&device_name=" + URLEncoder.encode(Build.MANUFACTURER + " " + Build.MODEL, "UTF-8")
                + "&app_version=" + URLEncoder.encode(APP_VERSION, "UTF-8")
                + "&api=1&format=json&_t=" + System.currentTimeMillis();
    }

    private String readStreamText(InputStream stream) throws Exception {
        if (stream == null) return "";
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, "UTF-8"));
        StringBuilder text = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            text.append(line).append('\n');
            if (text.length() > 1024 * 1024) break;
        }
        try { reader.close(); } catch (Throwable ignored) {}
        return text.toString();
    }

    private void disconnectActiveConnection() {
        HttpURLConnection connection = activeConnection;
        activeConnection = null;
        if (connection != null) {
            try { connection.disconnect(); } catch (Throwable ignored) {}
        }
    }

    private void readWebResult(final WebView view, final int generation, final int retry) {
        if (!isCurrentCheck(generation) || view == null) return;
        try {
            view.evaluateJavascript("(function(){return document.body ? document.body.innerText : document.documentElement.innerText;})()",
                    new ValueCallback<String>() {
                        @Override
                        public void onReceiveValue(String value) {
                            if (!isCurrentCheck(generation)) return;
                            String text = decodeJsString(value);
                            JSONObject data = jsonFromText(text);
                            if (data != null) {
                                handleServerJson(data, generation);
                                return;
                            }
                            // Beri waktu untuk halaman challenge/cookie hosting gratis selesai.
                            if (retry < 5) {
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        readWebResult(view, generation, retry + 1);
                                    }
                                }, 1500L);
                            }
                        }
                    });
        } catch (Throwable error) {
            finishAsOffline(error.getMessage() == null ? "Gagal membaca server lisensi" : error.getMessage(), generation);
        }
    }

    private void handleServerJson(JSONObject data, int generation) {
        if (!isCurrentCheck(generation)) return;
        // Respons aktif yang terlambat tidak boleh membatalkan hasil blokir yang sudah tersimpan.
        if (preferences.getBoolean(PREF_SECURITY_BLOCKED, false)) {
            finishCheck(generation);
            stopSelf();
            return;
        }
        if (jsonSaysActive(data)) {
            long expiry = extractMillis(data, new String[]{"expires_at", "expires", "expiry", "expire_at", "expire_date", "expired_at"});
            String username = normalizeUsername(data.optString("username", preferences.getString(PREF_LICENSE_KEY, "")));
            String token = data.optString("session_token", data.optString("token", preferences.getString(PREF_LICENSE_TOKEN, "")));
            if (expiry <= 0 || username.length() < 3 || token.length() == 0) {
                finishAsOffline("Respons server belum lengkap", generation);
                return;
            }

            long serverTime = extractMillis(data, new String[]{"server_time", "server_timestamp"});
            if (serverTime <= 0) serverTime = System.currentTimeMillis();
            String message = data.optString("message", "Lisensi aktif");
            preferences.edit()
                    .putString(PREF_LICENSE_KEY, username)
                    .putString(PREF_LICENSE_TOKEN, token)
                    .putLong(PREF_LICENSE_EXPIRY, expiry)
                    .putLong(PREF_LICENSE_CREATED, serverTime)
                    .putString(PREF_LICENSE_DURATION_LABEL, "Login user")
                    .putLong(PREF_LAST_SERVER_TIME, serverTime)
                    .putLong(PREF_LAST_SERVER_ELAPSED, SystemClock.elapsedRealtime())
                    .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                    .putBoolean(PREF_BG_MONITOR_ENABLED, true)
                    .putString(PREF_BG_STATE, STATE_ACTIVE)
                    .putString(PREF_BG_REASON, message)
                    .putLong(PREF_BG_LAST_RESULT, System.currentTimeMillis())
                    .putInt(PREF_CONFIRMED_VERIFY_SEQ, preferences.getInt(PREF_REQUIRED_VERIFY_SEQ, 0))
                    .putBoolean(PREF_REVERIFY_AFTER_BACKGROUND, false)
                    .apply();
            finishCheck(generation);
            updateNotification("Lisensi aktif • sinkron otomatis");
            broadcastState(STATE_ACTIVE);
            scheduleNextCheck(PERIODIC_CHECK_MS);
            return;
        }

        String message = data.optString("message", "Lisensi tidak aktif atau sesi telah dicabut.");
        preferences.edit()
                .putString(PREF_BG_STATE, STATE_BLOCKED)
                .putString(PREF_BG_REASON, message)
                .putLong(PREF_BG_LAST_RESULT, System.currentTimeMillis())
                .putLong(PREF_LAST_CHECK, System.currentTimeMillis())
                .putBoolean(PREF_BG_MONITOR_ENABLED, false)
                .putBoolean(PREF_LOGIN_REQUIRED, true)
                .putBoolean(PREF_SECURITY_BLOCKED, true)
                .putBoolean(PREF_REVERIFY_AFTER_BACKGROUND, true)
                .remove(PREF_LICENSE_TOKEN)
                .remove(PREF_LICENSE_EXPIRY)
                .remove(PREF_LICENSE_CREATED)
                .commit();
        finishCheck(generation);
        updateNotification("Lisensi tidak aktif • akses ICE diblokir");
        broadcastState(STATE_BLOCKED);
        stopSelf();
    }

    private boolean jsonSaysActive(JSONObject data) {
        if (data == null) return false;
        // Beberapa server menaruh status akun di object data/user/account/session.
        // Nilai negatif di level mana pun harus selalu menang.
        if (jsonContainsBlockedValue(data, 0)) return false;

        // Nilai negatif eksplisit selalu menang. "ok" hanya berarti request berhasil,
        // bukan berarti akun/lisensi masih aktif.
        String[] explicitKeys = new String[]{
                "active", "is_active", "user_active", "enabled",
                "valid", "is_valid", "license_valid", "session_valid"
        };
        boolean hasExplicitPositive = false;
        for (String key : explicitKeys) {
            if (!data.has(key) || data.isNull(key)) continue;
            Object raw = data.opt(key);
            Boolean parsed = parseJsonBoolean(raw);
            if (parsed != null) {
                if (!parsed.booleanValue()) return false;
                hasExplicitPositive = true;
            }
        }

        String status = data.optString("status", "").trim().toLowerCase(Locale.US);
        if (isBlockedStatus(status)) return false;
        if ("active".equals(status) || "enabled".equals(status)
                || "valid".equals(status) || "approved".equals(status)) {
            hasExplicitPositive = true;
        }

        String code = data.optString("code", "").trim().toLowerCase(Locale.US);
        if (isBlockedStatus(code)) return false;

        String message = data.optString("message", "").trim().toLowerCase(Locale.US);
        if (containsBlockedMeaning(message)) return false;

        if (hasExplicitPositive) return true;

        // Kompatibilitas server lama: ok/success boleh dipakai hanya bila respons juga
        // membawa expiry yang sah. Ini mencegah {ok:true, active:false} lolos.
        boolean requestOk = booleanFieldTrue(data, "ok") || booleanFieldTrue(data, "success");
        long expiry = extractMillis(data, new String[]{"expires_at", "expires", "expiry", "expire_at", "expire_date", "expired_at"});
        return requestOk && expiry > System.currentTimeMillis();
    }

    private boolean jsonContainsBlockedValue(JSONObject object, int depth) {
        if (object == null || depth > 4) return false;
        java.util.Iterator<String> keys = object.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            Object raw = object.opt(key);
            String name = key == null ? "" : key.trim().toLowerCase(Locale.US);
            if (raw instanceof JSONObject) {
                if (jsonContainsBlockedValue((JSONObject) raw, depth + 1)) return true;
                continue;
            }
            if (raw instanceof JSONArray) {
                JSONArray array = (JSONArray) raw;
                for (int i = 0; i < array.length(); i++) {
                    Object item = array.opt(i);
                    if (item instanceof JSONObject && jsonContainsBlockedValue((JSONObject) item, depth + 1)) return true;
                }
                continue;
            }
            if ("active".equals(name) || "is_active".equals(name) || "user_active".equals(name)
                    || "enabled".equals(name) || "valid".equals(name) || "is_valid".equals(name)
                    || "license_valid".equals(name) || "session_valid".equals(name)) {
                Boolean parsed = parseJsonBoolean(raw);
                if (parsed != null && !parsed.booleanValue()) return true;
            }
            String value = raw == null || raw == JSONObject.NULL ? "" : String.valueOf(raw);
            if ("status".equals(name) || "code".equals(name) || name.endsWith("_status")) {
                if (isBlockedStatus(value)) return true;
            }
            if ("message".equals(name) || "reason".equals(name) || "error".equals(name)
                    || "detail".equals(name)) {
                if (containsBlockedMeaning(value)) return true;
            }
        }
        return false;
    }

    private Boolean parseJsonBoolean(Object raw) {
        if (raw == null || raw == JSONObject.NULL) return null;
        if (raw instanceof Boolean) return (Boolean) raw;
        if (raw instanceof Number) return ((Number) raw).intValue() != 0;
        String value = String.valueOf(raw).trim().toLowerCase(Locale.US);
        if ("1".equals(value) || "true".equals(value) || "yes".equals(value)
                || "active".equals(value) || "enabled".equals(value) || "valid".equals(value)) return Boolean.TRUE;
        if ("0".equals(value) || "false".equals(value) || "no".equals(value)
                || "inactive".equals(value) || "disabled".equals(value) || "invalid".equals(value)) return Boolean.FALSE;
        return null;
    }

    private boolean booleanFieldTrue(JSONObject data, String key) {
        if (data == null || !data.has(key)) return false;
        Boolean value = parseJsonBoolean(data.opt(key));
        return value != null && value.booleanValue();
    }

    private boolean isBlockedStatus(String value) {
        if (value == null) return false;
        String status = value.trim().toLowerCase(Locale.US);
        return "inactive".equals(status) || "nonaktif".equals(status)
                || "disabled".equals(status) || "blocked".equals(status)
                || "revoked".equals(status) || "expired".equals(status)
                || "invalid".equals(status) || "suspended".equals(status)
                || "deactivated".equals(status) || "not_found".equals(status)
                || "user_disabled".equals(status) || "account_disabled".equals(status)
                || "denied".equals(status) || "forbidden".equals(status)
                || "locked".equals(status);
    }

    private boolean containsBlockedMeaning(String value) {
        if (value == null) return false;
        String text = value.toLowerCase(Locale.US);
        return text.contains("nonaktif") || text.contains("tidak aktif")
                || text.contains("dinonaktifkan") || text.contains("disabled")
                || text.contains("revoked") || text.contains("dicabut")
                || text.contains("expired") || text.contains("kedaluwarsa")
                || text.contains("diblokir") || text.contains("suspended")
                || text.contains("akun tidak aktif") || text.contains("akun dinonaktifkan")
                || text.contains("user disabled") || text.contains("account disabled")
                || text.contains("akses ditolak") || text.contains("tidak ditemukan")
                || text.contains("session invalid") || text.contains("sesi tidak valid");
    }

    private void finishAsOffline(String reason, int generation) {
        if (!isCurrentCheck(generation)) return;
        finishCheck(generation);
        if (hasValidatedInternetNetwork()) {
            // Internet publik tersedia, jadi ICE tidak boleh memakai cache sebelum server
            // berhasil diverifikasi. Tetap di layar pemeriksaan dan ulangi setiap 5 detik.
            preferences.edit()
                    .putString(PREF_BG_STATE, STATE_CHECKING)
                    .putString(PREF_BG_REASON,
                            reason == null ? "Server lisensi belum merespons. Mencoba lagi…"
                                    : reason + ". Mencoba lagi…")
                    .putLong(PREF_BG_LAST_RESULT, System.currentTimeMillis())
                    .apply();
            updateNotification("Server belum merespons • mencoba lagi");
            broadcastState(STATE_CHECKING);
        } else {
            markOffline(reason);
        }
        scheduleNextCheck(RETRY_CHECK_MS);
    }

    private void markOffline(String reason) {
        preferences.edit()
                .putString(PREF_BG_STATE, STATE_OFFLINE)
                .putString(PREF_BG_REASON, reason == null ? "Server lisensi belum terjangkau" : reason)
                .putLong(PREF_BG_LAST_RESULT, System.currentTimeMillis())
                .apply();
        updateNotification("Menunggu internet • lisensi akan dicek otomatis");
        broadcastState(STATE_OFFLINE);
    }

    private boolean isCurrentCheck(int generation) {
        return !destroyed && checkInProgress && generation == checkGeneration;
    }

    private void finishCheck(int generation) {
        if (generation != checkGeneration) return;
        checkInProgress = false;
        disconnectActiveConnection();
        destroyCheckWebView();
        restoreProcessNetwork();
    }

    private void destroyCheckWebView() {
        final WebView view = checkWebView;
        checkWebView = null;
        if (view == null) return;
        try { view.stopLoading(); } catch (Throwable ignored) {}
        try { view.setWebChromeClient(null); } catch (Throwable ignored) {}
        try { view.setWebViewClient(null); } catch (Throwable ignored) {}
        try { view.destroy(); } catch (Throwable ignored) {}
    }

    private void broadcastState(String state) {
        try {
            Intent intent = new Intent(ACTION_LICENSE_UPDATED);
            intent.setPackage(getPackageName());
            intent.putExtra(EXTRA_STATE, state);
            sendBroadcast(intent);
        } catch (Throwable ignored) {}
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "ICE INJECT",
                NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Menjaga lisensi ICE tetap tersinkron saat aplikasi diminimalkan.");
        channel.setShowBadge(false);
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification(String text) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, openIntent, pendingFlags);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("ICE INJECT")
                .setContentText(text)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false);
        if (Build.VERSION.SDK_INT < 26) builder.setPriority(Notification.PRIORITY_LOW);
        return builder.build();
    }

    private void updateNotification(String text) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            try { manager.notify(NOTIFICATION_ID, buildNotification(text)); } catch (Throwable ignored) {}
        }
    }

    private JSONObject jsonFromText(String text) {
        if (text == null) return null;
        String value = text.trim();
        if (value.startsWith("\uFEFF")) value = value.substring(1).trim();
        int first = value.indexOf('{');
        int last = value.lastIndexOf('}');
        if (first < 0 || last <= first) return null;
        try { return new JSONObject(value.substring(first, last + 1)); }
        catch (Throwable ignored) { return null; }
    }

    private String decodeJsString(String value) {
        if (value == null || "null".equals(value)) return "";
        try {
            JSONArray array = new JSONArray("[" + value + "]");
            return array.optString(0, value);
        } catch (Throwable ignored) {
            return value;
        }
    }

    private long extractMillis(JSONObject data, String[] keys) {
        if (data == null || keys == null) return 0L;
        for (String key : keys) {
            long parsed = parseServerMillis(data.optString(key, ""));
            if (parsed > 0) return parsed;
        }
        return 0L;
    }

    private long parseServerMillis(String value) {
        if (value == null) return 0L;
        String normalized = value.trim();
        if (normalized.length() == 0) return 0L;
        try {
            if (normalized.matches("^[0-9]+$")) {
                long number = Long.parseLong(normalized);
                return number < 100000000000L ? number * 1000L : number;
            }
        } catch (Throwable ignored) {}
        try {
            normalized = normalized.replace('T', ' ');
            if (normalized.endsWith("Z")) normalized = normalized.substring(0, normalized.length() - 1);
            int plus = normalized.indexOf('+', 10);
            if (plus > 0) normalized = normalized.substring(0, plus).trim();
            int dot = normalized.indexOf('.');
            if (dot > 0) normalized = normalized.substring(0, dot);
            if (normalized.length() >= 19) normalized = normalized.substring(0, 19);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            format.setTimeZone(TimeZone.getTimeZone("Asia/Jakarta"));
            Date parsed = format.parse(normalized);
            return parsed == null ? 0L : parsed.getTime();
        } catch (Throwable ignored) {
            return 0L;
        }
    }

    private String normalizeServerUrl(String value) {
        String url = value == null ? "" : value.trim();
        if (url.length() == 0) return "";
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://" + url;
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    private String normalizeUsername(String value) {
        if (value == null) return "";
        String source = value.trim().toLowerCase(Locale.US);
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < source.length(); i++) {
            char c = source.charAt(i);
            if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '-') {
                output.append(c);
            }
        }
        return output.toString();
    }

    private String getInstallDeviceId() {
        String id = null;
        try { id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID); }
        catch (Throwable ignored) {}
        if (id == null || id.length() < 6) {
            id = preferences.getString(PREF_DEVICE_ID, "");
            if (id.length() < 6) {
                id = "ICE-" + Long.toHexString(System.currentTimeMillis()) + "-"
                        + Integer.toHexString((int) (Math.random() * Integer.MAX_VALUE));
                preferences.edit().putString(PREF_DEVICE_ID, id).apply();
            }
        }
        return id;
    }
}
