ICE v2.8.9.1 v37 — Strict Offline Revoke

Perbaikan keamanan:
- Hasil akun nonaktif disimpan sebagai latch permanen dengan commit sinkron.
- Cache lisensi lama tidak dapat membuka ICE lagi setelah server menyatakan akun nonaktif/dicabut/expired.
- Status negatif juga dibaca dari object JSON bertingkat seperti data/user/account/session.
- Saat pengguna menekan Home, ICE meminta satu konfirmasi server baru.
- Jika data dimatikan sebelum konfirmasi selesai, saat kembali browser dikunci dan pengguna wajib login online.
- Jika konfirmasi aktif selesai saat diminimalkan, ICE tetap boleh dilanjutkan saat data kemudian dimatikan.
- Pengecekan tetap diam-diam tanpa popup dan polling 5 detik tetap aktif.
- Minimize tidak menghapus sesi; menutup task tetap wajib login ulang.
