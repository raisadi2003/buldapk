ICE v2.8.9.1 v33 - Realtime Network License

Perubahan:
- Cek lisensi langsung saat internet tervalidasi/tersambung.
- Berlaku saat ICE terbuka maupun diminimalkan.
- Perpindahan Wi-Fi/data memicu pemeriksaan baru tanpa menunggu 5 detik.
- Bila event jaringan datang ketika pemeriksaan sedang berlangsung, satu pemeriksaan langsung diantrekan setelahnya.
- Polling 5 detik tetap dipertahankan sebagai fallback untuk pencabutan/perpanjangan saat jaringan terus aktif.
- Izin notifikasi dan pengecualian optimasi baterai tetap wajib.
- Judul notifikasi: ICE INJECT.
- Fitur Centang Hijau Semua URL tetap tersedia; tidak submit otomatis.

Catatan:
Realtime yang dimaksud adalah event-driven ketika kondisi jaringan berubah. Perubahan lisensi di server saat jaringan tetap tersambung dideteksi maksimal melalui fallback 5 detik, kecuali server ditambah WebSocket/SSE/FCM.
