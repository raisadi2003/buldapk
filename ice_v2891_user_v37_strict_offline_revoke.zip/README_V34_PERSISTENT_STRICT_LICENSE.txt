ICE v2.8.9.1 v34 - Persistent Strict License

Perbaikan utama:
- Service lisensi tidak dihentikan ketika ICE dihapus dari Recent Apps.
- Alarm restart cadangan untuk OEM Android yang membunuh service.
- Service aktif kembali setelah boot, user unlock, dan update aplikasi.
- Saat internet tersedia, ICE wajib menunggu hasil pengecekan server terbaru sebelum browser dibuka.
- Saat kembali dari minimize, ICE melakukan pengecekan langsung sebelum dapat digunakan.
- Respons ok=true tidak lagi otomatis dianggap akun aktif. Status nonaktif/disabled/revoked/expired selalu memblokir.
- Polling 5 detik dan NetworkCallback realtime tetap aktif.
- Notifikasi tetap bernama ICE INJECT.

Batas Android:
- Force Stop dari menu Pengaturan Android memblokir semua receiver/service sampai aplikasi dibuka manual kembali.
