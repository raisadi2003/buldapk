ICE v2.8.9.1 v31 — LICENSE BACKGROUND

Perubahan utama:
1. Lisensi user tetap dipantau saat ICE diminimalkan dengan tombol Home.
2. Layanan foreground memakai notifikasi tetap agar Android tidak mudah menghentikan proses.
3. Saat internet/data tersedia, status lisensi dicek langsung dan kemudian setiap 30 detik.
4. Pemeriksaan memilih jaringan internet tervalidasi dan memprioritaskan seluler bila WiFi perusahaan tidak memiliki internet.
5. Perpanjangan masa aktif, perubahan expiry, pencabutan, dan status expired disimpan otomatis tanpa membuka ICE.
6. Saat kembali ke ICE, hasil background langsung diterapkan: aktif tetap masuk, revoked/expired langsung terkunci.
7. Menekan Home = tetap berjalan. Menggeser ICE dari recent / memilih Keluar = sesi background dibersihkan.
8. Semua fitur v30 tetap dipertahankan, termasuk tombol Centang Hijau untuk semua URL dan tidak auto-submit.

Catatan penggunaan Android:
- Izinkan notifikasi ICE.
- Untuk kestabilan maksimal pada Android 16/Tecno, set baterai ICE ke Tidak dibatasi dan izinkan Auto-start bila menu tersebut tersedia.
- Jangan menekan Paksa berhenti karena Android akan menghentikan seluruh layanan aplikasi.
