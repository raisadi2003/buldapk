ICE v2.8.9.1 v35 - Login After Close

Perubahan utama:
- Tombol Home/minimize tidak menghapus sesi selama proses ICE masih hidup. Jika Android membunuh proses saat diminimalkan, pembukaan berikutnya wajib login demi keamanan.
- Swipe ICE dari Recent Apps menandai sesi browser berakhir.
- Tombol Back pada halaman utama menutup task dan mewajibkan login ulang.
- Restart HP, cold start proses, Force Stop, crash, unlock pertama setelah boot, dan update aplikasi mewajibkan login ulang.
- Credential lisensi tetap disimpan terpisah untuk foreground service agar status akun tetap dipantau di latar belakang.
- Hasil service ACTIVE tidak dapat membuka browser bila flag login ulang masih aktif.
- Login username/password yang berhasil membuka sesi baru.
- Pengecekan realtime saat jaringan tersedia dan polling cadangan 5 detik tetap dipertahankan.
- Notifikasi foreground service tetap bernama ICE INJECT.
