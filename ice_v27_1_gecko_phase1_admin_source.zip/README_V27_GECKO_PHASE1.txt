ICE v27 Gecko Migration - Tahap 1

- Seluruh UI, login, lisensi, scanner, antrean, akun QR, dan fitur v25 tetap dipertahankan di MainActivity lama.
- Menu baru: "Buka dengan mesin Firefox" membuka URL tab aktif menggunakan Mozilla GeckoView.
- DNS over HTTPS pada mesin Gecko dimatikan dengan TRR_MODE_DISABLED.
- Tahap ini belum memindahkan JavaScript bridge/scanner ke tab Gecko. Gunakan mode v25 untuk scan, dan mode Firefox untuk menguji akses jaringan internal.
- Minimum Android 8 (API 26), Java 17, compileSdk 36.

FIX v27.1: Mozilla Maven repository added so GeckoView dependency can be resolved.
