ICE v2.8.9.1 User v39 — Persistent Background Sync

Perubahan utama:
- Foreground service memegang PARTIAL_WAKE_LOCK agar timer tidak tidur saat ICE diminimalkan.
- Scheduler 5 detik berjalan pada executor terpisah dari main/WebView Activity.
- NetworkCallback tetap memicu pengecekan segera ketika internet tersambung.
- Alarm heartbeat menjadi cadangan jika OEM menunda atau mematikan thread service.
- Request lisensi hanya dikirim ketika internet tervalidasi. Saat offline, akses aktif terakhir tetap berlaku sampai expired.
- Status nonaktif/revoked tetap disimpan sebagai blokir lokal permanen.
- Notifikasi tetap bernama ICE INJECT.

Catatan Android:
Force Stop dari menu Pengaturan selalu menghentikan seluruh service/alarm sampai aplikasi dibuka lagi.
