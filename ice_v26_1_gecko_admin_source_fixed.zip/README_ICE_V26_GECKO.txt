ICE v26 Gecko — ICE 404

Perubahan utama:
- Mesin browser utama diganti dari Android WebView/Chromium menjadi Mozilla GeckoView 152.
- DNS over HTTPS dimatikan dengan TRR_MODE_DISABLED.
- Pemilihan DoH otomatis dimatikan, sehingga DNS mengikuti resolver jaringan/Wi-Fi Android.
- HTTP lokal diizinkan untuk website perusahaan.
- Tab terpisah memakai GeckoSession.
- Mode desktop/seluler, reload paksa, crash recovery, kamera, mikrofon, lokasi, dan unduhan dasar.

Catatan pengujian:
- Source disiapkan untuk GitHub Actions Java 17 + Android SDK 35.
- APK GeckoView berukuran jauh lebih besar karena mesin Firefox ikut dibundel.
- Fitur khusus v25 yang bergantung pada JavaScript bridge WebView lama belum dipindahkan seluruhnya pada tahap ini.
