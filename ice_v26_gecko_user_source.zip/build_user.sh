#!/usr/bin/env bash
set -euo pipefail
OUT_NAME="ice_v26_gecko_user.apk"
KEYSTORE="signing/ice_v271_release.keystore"
KEY_ALIAS="icev271"
STORE_PASS="${ICE_STORE_PASS:-ICEv271Stable!}"
KEY_PASS="${ICE_KEY_PASS:-$STORE_PASS}"
gradle --no-daemon :app:assembleRelease
SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
BUILD_TOOLS="$(find "$SDK_ROOT/build-tools" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"
"$BUILD_TOOLS/zipalign" -f 4 app/build/outputs/apk/release/app-release-unsigned.apk app/build/outputs/apk/release/app-release-aligned.apk
"$BUILD_TOOLS/apksigner" sign --ks "$KEYSTORE" --ks-key-alias "$KEY_ALIAS" --ks-pass "pass:$STORE_PASS" --key-pass "pass:$KEY_PASS" --out "$OUT_NAME" app/build/outputs/apk/release/app-release-aligned.apk
"$BUILD_TOOLS/apksigner" verify --verbose --print-certs "$OUT_NAME"
