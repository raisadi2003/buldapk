ICE v2.8.9.1 v38 — Online Check, Offline Access

Perubahan:
- Pemeriksaan lisensi hanya mengirim request ketika Android mendeteksi internet tervalidasi.
- Ketika data/Wi-Fi internet mati, service tidak melakukan polling jaringan setiap 5 detik.
- NetworkCallback memicu pemeriksaan langsung saat internet kembali.
- Hasil verifikasi aktif terakhir tetap dapat dipakai offline sampai tanggal kedaluwarsa lokal.
- Minimize/Home tidak lagi memaksa verifikasi baru atau login ulang hanya karena data dimatikan.
- Jika server sudah menyatakan akun nonaktif/dicabut/expired, blokir disimpan permanen dan tetap berlaku offline.
- Menutup aplikasi dari Recent Apps/Back/restart tetap mewajibkan login ulang sesuai aturan v35.
- Polling 5 detik tetap berjalan hanya selama internet tersedia untuk mendeteksi perubahan akun.
- Pengecekan berjalan diam-diam tanpa popup.
