(function () {
  'use strict';

  var w = window;
  var VERSION = 7;
  var existing = w.__LPWScannerBridge;
  if (existing && existing.version === VERSION) {
    try { existing.patch(); } catch (_) {}
    return;
  }
  if (existing && existing.version !== VERSION) {
    try { existing.destroy(); } catch (_) {}
  }

  var callbacks = [];
  var patched = {};
  var patchTimers = [];
  var observer = null;
  var lastPatchAt = 0;
  var lastGuideAt = 0;
  var lastPackingCheckedTotal = 0;
  var lastCount = -1;
  var recent = {};
  var queue = [];
  var processing = false;
  var destroyed = false;

  var MAX_CALLBACKS = 4;
  var MAX_QUEUE = 24;
  var CALLBACK_TTL = 3 * 60 * 1000;
  var DUPLICATE_MS = 1100;
  var SEND_GAP_MS = 140;

  function now() { return Date.now ? Date.now() : new Date().getTime(); }

  function androidCall(name, args) {
    try {
      if (w.AndroidBridge && typeof w.AndroidBridge[name] === 'function') {
        w.AndroidBridge[name].apply(w.AndroidBridge, args || []);
      }
    } catch (_) {}
  }

  function report(message) {
    androidCall('onStatus', [String(message || '')]);
  }

  function reportCount(force) {
    var count = callbacks.length;
    if (!force && count === lastCount) return;
    lastCount = count;
    androidCall('onCallbackCount', [count]);
  }

  function callbackSources() {
    var out = [];
    for (var i = callbacks.length - 1; i >= 0; i--) {
      var source = callbacks[i] && callbacks[i].source;
      if (source && out.indexOf(source) < 0) out.push(source);
    }
    return out;
  }

  function cleanupRecent() {
    var cutoff = now() - Math.max(DUPLICATE_MS * 4, 10000);
    for (var key in recent) {
      if (Object.prototype.hasOwnProperty.call(recent, key) && recent[key] < cutoff) {
        delete recent[key];
      }
    }
  }

  function cleanupCallbacks() {
    var cutoff = now() - CALLBACK_TTL;
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      if (entry.addedAt && entry.addedAt < cutoff) continue;
      next.push(entry);
    }
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
  }

  function addCallback(fn, source, mode) {
    if (typeof fn !== 'function') return;
    source = source || 'callback';
    mode = mode || 'html5';

    var stamp = now();
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var item = callbacks[i];
      if (!item || item.fn === fn || item.source === source) continue;
      next.push(item);
    }
    next.push({ fn: fn, source: source, mode: mode, addedAt: stamp });
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
    report('Scanner siap. Jalur aktif: ' + source + '.');
  }

  function decodedResult(text) {
    return {
      decodedText: text,
      text: text,
      rawValue: text,
      data: text,
      code: text,
      barcode: text,
      result: {
        text: text,
        format: { formatName: 'QR_CODE', format: 'QR_CODE' }
      }
    };
  }

  function wrapMethod(proto, name, makeWrapper, key) {
    try {
      if (!proto || typeof proto[name] !== 'function') return false;
      if (proto[name].__iceBridgeV4) return true;
      var original = proto[name];
      var wrapped = makeWrapper(original);
      wrapped.__iceBridgeV4 = true;
      wrapped.__iceOriginal = original;
      proto[name] = wrapped;
      patched[key || name] = true;
      return true;
    } catch (_) {
      return false;
    }
  }

  function patchHtml5Qrcode() {
    try {
      var Html5Qrcode = w.Html5Qrcode;
      if (typeof Html5Qrcode === 'function' && Html5Qrcode.prototype) {
        wrapMethod(Html5Qrcode.prototype, 'start', function (original) {
          return function (cameraIdOrConfig, configuration, successCallback, errorCallback) {
            addCallback(successCallback, 'Html5Qrcode.start', 'html5');
            return original.call(this, cameraIdOrConfig, configuration, successCallback, errorCallback);
          };
        }, 'Html5Qrcode.start');
      }
    } catch (_) {}

    try {
      var Scanner = w.Html5QrcodeScanner;
      if (typeof Scanner === 'function' && Scanner.prototype) {
        wrapMethod(Scanner.prototype, 'render', function (original) {
          return function (successCallback, errorCallback) {
            addCallback(successCallback, 'Html5QrcodeScanner.render', 'html5');
            return original.call(this, successCallback, errorCallback);
          };
        }, 'Html5QrcodeScanner.render');
      }
    } catch (_) {}
  }

  function patchOtherLibraries() {
    try {
      var QrScanner = w.QrScanner;
      if (typeof QrScanner === 'function' && !QrScanner.__iceBridgeV4Wrapped && typeof Proxy === 'function') {
        var Wrapped = new Proxy(QrScanner, {
          construct: function (target, args, newTarget) {
            addCallback(args && args[1], 'QrScanner.constructor', 'qrscanner');
            return Reflect.construct(target, args, newTarget === Wrapped ? target : newTarget);
          }
        });
        Wrapped.__iceBridgeV4Wrapped = true;
        w.QrScanner = Wrapped;
      }
    } catch (_) {}

    try {
      var InstascanScanner = w.Instascan && w.Instascan.Scanner;
      if (typeof InstascanScanner === 'function' && InstascanScanner.prototype) {
        wrapMethod(InstascanScanner.prototype, 'addListener', function (original) {
          return function (eventName, callback) {
            if (String(eventName).toLowerCase() === 'scan') {
              addCallback(callback, 'Instascan.addListener', 'text');
            }
            return original.call(this, eventName, callback);
          };
        }, 'Instascan.addListener');
      }
    } catch (_) {}

    try {
      var Quagga = w.Quagga;
      if (Quagga && typeof Quagga.onDetected === 'function' && !Quagga.onDetected.__iceBridgeV4) {
        var originalOnDetected = Quagga.onDetected;
        var wrappedOnDetected = function (callback) {
          addCallback(callback, 'Quagga.onDetected', 'quagga');
          return originalOnDetected.call(this, callback);
        };
        wrappedOnDetected.__iceBridgeV4 = true;
        Quagga.onDetected = wrappedOnDetected;
      }
    } catch (_) {}
  }

  function tryContinuousFocus(video) {
    try {
      if (!video || !video.srcObject || !video.srcObject.getVideoTracks) return;
      var track = video.srcObject.getVideoTracks()[0];
      if (!track || track.__iceFocusV4) return;
      track.__iceFocusV4 = true;
      if (!track.getCapabilities || !track.applyConstraints) return;
      var caps = track.getCapabilities() || {};
      if (caps.focusMode && Array.prototype.indexOf.call(caps.focusMode, 'continuous') >= 0) {
        track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(function () {});
      }
    } catch (_) {}
  }

  function directGuide(parent) {
    try {
      var children = parent.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i] && children[i].classList && children[i].classList.contains('ice-scan-guide')) {
          return children[i];
        }
      }
    } catch (_) {}
    return null;
  }

  function ensureScannerGuide() {
    if (document.hidden) return;
    var videos = [];
    try { videos = Array.prototype.slice.call(document.querySelectorAll('video')); } catch (_) {}
    for (var i = 0; i < videos.length; i++) {
      var video = videos[i];
      try {
        var rect = video.getBoundingClientRect();
        var style = w.getComputedStyle(video);
        if (rect.width < 160 || rect.height < 120 || style.display === 'none' || style.visibility === 'hidden') continue;
        tryContinuousFocus(video);
        var parent = video.parentElement;
        if (!parent || directGuide(parent)) continue;
        if (w.getComputedStyle(parent).position === 'static') parent.style.position = 'relative';

        var guide = document.createElement('div');
        guide.className = 'ice-scan-guide';
        guide.setAttribute('aria-hidden', 'true');
        guide.innerHTML = '<span>Pas-kan QR / barcode di dalam kotak</span><b></b>';
        guide.style.cssText = 'position:absolute;left:8%;right:8%;top:23%;height:48%;z-index:2147483000;pointer-events:none;border:2px solid rgba(34,197,94,.9);border-radius:14px;box-sizing:border-box;';
        var label = guide.querySelector('span');
        if (label) label.style.cssText = 'position:absolute;left:50%;bottom:-34px;transform:translateX(-50%);white-space:nowrap;background:rgba(15,23,42,.82);color:#fff;border-radius:999px;padding:6px 10px;font:600 12px system-ui,sans-serif;';
        var line = guide.querySelector('b');
        if (line) line.style.cssText = 'position:absolute;left:7%;right:7%;top:50%;height:2px;background:#22c55e;box-shadow:0 0 8px #22c55e;';
        parent.appendChild(guide);
      } catch (_) {}
    }
  }


  function greenHeaderText(value) {
    return String(value == null ? '' : value)
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function greenCompactText(value) {
    return greenHeaderText(value).replace(/[^a-z0-9]+/g, '');
  }

  function greenSemanticMatch(value) {
    var text = greenCompactText(value);
    return text === 'passed' || text === 'pass' || text === 'lulus' ||
      text === 'sesuai' || text === 'ok' || text === 'yes' || text === 'benar';
  }

  function greenRgb(value) {
    var text = String(value || '').trim().toLowerCase();
    var match = text.match(/^rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d+(?:\.\d+)?))?\s*\)$/);
    if (match) {
      return {
        r: Number(match[1]),
        g: Number(match[2]),
        b: Number(match[3]),
        a: match[4] == null ? 1 : Number(match[4])
      };
    }
    var hex = text.match(/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i);
    if (!hex) return null;
    var raw = hex[1];
    if (raw.length === 3) raw = raw.charAt(0) + raw.charAt(0) + raw.charAt(1) + raw.charAt(1) + raw.charAt(2) + raw.charAt(2);
    var alpha = 1;
    if (raw.length === 8) {
      alpha = parseInt(raw.slice(6, 8), 16) / 255;
      raw = raw.slice(0, 6);
    }
    return {
      r: parseInt(raw.slice(0, 2), 16),
      g: parseInt(raw.slice(2, 4), 16),
      b: parseInt(raw.slice(4, 6), 16),
      a: alpha
    };
  }

  function greenColorMatch(value) {
    var rgb = greenRgb(value);
    if (!rgb || rgb.a < 0.12) return false;
    return rgb.g >= 70 && (rgb.g - rgb.r) >= 12 && (rgb.g - rgb.b) >= 7;
  }

  function greenElementMatch(element) {
    if (!element) return false;
    var hints = '';
    try {
      hints = [
        element.className,
        element.getAttribute && element.getAttribute('style'),
        element.getAttribute && element.getAttribute('title'),
        element.getAttribute && element.getAttribute('aria-label'),
        element.getAttribute && element.getAttribute('data-status'),
        element.getAttribute && element.getAttribute('data-state')
      ].join(' ').toLowerCase();
    } catch (_) {}

    if (/(^|[\s_\-])(success|green|passed|pass|lulus|sesuai)([\s_\-]|$)/i.test(hints)) return true;
    try {
      var text = element.innerText || element.textContent || '';
      if (greenSemanticMatch(text)) return true;
    } catch (_) {}

    try {
      var style = w.getComputedStyle(element);
      if (style && (
        greenColorMatch(style.backgroundColor) ||
        greenColorMatch(style.borderTopColor) ||
        greenColorMatch(style.borderRightColor) ||
        greenColorMatch(style.borderBottomColor) ||
        greenColorMatch(style.borderLeftColor) ||
        greenColorMatch(style.color)
      )) return true;
    } catch (_) {}
    return false;
  }

  function greenDescendantMatch(element) {
    if (greenElementMatch(element)) return true;
    var nodes = [];
    try { nodes = Array.prototype.slice.call(element.querySelectorAll('label,span,div,button,[class],[style]')); } catch (_) {}
    var limit = Math.min(nodes.length, 24);
    for (var i = 0; i < limit; i++) {
      if (greenElementMatch(nodes[i])) return true;
    }
    return false;
  }

  function greenHeaderRows(table) {
    var rows = [];
    try { rows = Array.prototype.slice.call(table.querySelectorAll('thead tr')); } catch (_) {}
    if (!rows.length) {
      try {
        var first = table.querySelector('tr');
        if (first) rows = [first];
      } catch (_) {}
    }
    return rows;
  }

  function greenTargetColumnIndexes(table) {
    var rows = greenHeaderRows(table);
    var semantic = {};
    var styled = {};
    var maxCells = 0;

    for (var r = 0; r < rows.length; r++) {
      var cells = [];
      try { cells = Array.prototype.slice.call(rows[r].children || []); } catch (_) {}
      maxCells = Math.max(maxCells, cells.length);
      for (var c = 0; c < cells.length; c++) {
        var text = cells[c].innerText || cells[c].textContent || '';
        if (greenSemanticMatch(text)) semantic[c] = true;
        else if (greenDescendantMatch(cells[c])) styled[c] = true;
      }
    }

    var result = Object.keys(semantic).map(function (key) { return Number(key); });
    if (!result.length) result = Object.keys(styled).map(function (key) { return Number(key); });
    result.sort(function (a, b) { return a - b; });

    // Jika seluruh header memperoleh warna hijau dari parent/theme, jangan anggap semua kolom target.
    if (!Object.keys(semantic).length && maxCells > 1 && result.length === maxCells) return [];
    return result;
  }

  function greenClickControl(control) {
    if (!control || control.disabled || control.checked) return false;
    try {
      control.click();
      if (control.checked) return true;
    } catch (_) {}

    try {
      var proto = w.HTMLInputElement && w.HTMLInputElement.prototype;
      var descriptor = proto && Object.getOwnPropertyDescriptor(proto, 'checked');
      if (descriptor && descriptor.set) descriptor.set.call(control, true);
      else control.checked = true;
      try { control.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
      try { control.dispatchEvent(new Event('change', { bubbles: true })); } catch (_) {}
      return !!control.checked;
    } catch (_) {
      return false;
    }
  }

  function greenRowControls(row, targetIndexes) {
    var cells = [];
    try { cells = Array.prototype.slice.call(row.children || []); } catch (_) {}
    var controls = [];
    var seen = [];

    function addFromCell(cell, requireGreen) {
      if (!cell || (requireGreen && !greenDescendantMatch(cell))) return;
      var found = [];
      try { found = Array.prototype.slice.call(cell.querySelectorAll('input[type="radio"],input[type="checkbox"]')); } catch (_) {}
      for (var i = 0; i < found.length; i++) {
        var control = found[i];
        if (!control || control.disabled || seen.indexOf(control) >= 0) continue;
        seen.push(control);
        controls.push(control);
        break;
      }
    }

    if (targetIndexes && targetIndexes.length) {
      for (var i = 0; i < targetIndexes.length; i++) {
        var index = targetIndexes[i];
        if (index >= 0 && index < cells.length) addFromCell(cells[index], false);
      }
      return controls;
    }

    for (var c = 0; c < cells.length; c++) addFromCell(cells[c], true);
    return controls;
  }

  function checkGreenColumnsManual() {
    var tables = [];
    try { tables = Array.prototype.slice.call(document.querySelectorAll('table')); } catch (_) {}
    var changed = 0;
    var eligible = 0;
    var foundGreenTarget = false;

    for (var t = 0; t < tables.length; t++) {
      var table = tables[t];
      var targetIndexes = greenTargetColumnIndexes(table);
      var rows = [];
      try { rows = Array.prototype.slice.call(table.querySelectorAll('tbody tr')); } catch (_) {}
      if (!rows.length) {
        try { rows = Array.prototype.slice.call(table.querySelectorAll('tr')); } catch (_) {}
        var headers = greenHeaderRows(table);
        rows = rows.filter(function (row) { return headers.indexOf(row) < 0; });
      }

      for (var r = 0; r < rows.length; r++) {
        var row = rows[r];
        if (!row || row.getAttribute('data-ice-skip-auto-passed') === '1') continue;
        var controls = greenRowControls(row, targetIndexes);
        if (controls.length) foundGreenTarget = true;
        for (var i = 0; i < controls.length; i++) {
          var control = controls[i];
          eligible++;
          if (!control.checked && greenClickControl(control)) changed++;
        }
      }
    }

    lastPackingCheckedTotal += changed;
    if (!foundGreenTarget) {
      report('Kolom hijau atau PASSED belum ditemukan di halaman ini.');
      return { ok: false, reason: 'green_column_missing', changed: 0 };
    }
    if (eligible < 1) {
      report('Belum ada baris yang dapat dicentang.');
      return { ok: false, reason: 'no_rows', changed: 0 };
    }
    if (changed < 1) {
      report('Semua pilihan hijau sudah dicentang. Submit tetap manual.');
      return { ok: true, reason: 'already_checked', changed: 0, eligible: eligible };
    }

    report(changed + ' pilihan hijau berhasil dicentang. Submit tetap manual.');
    return { ok: true, reason: 'checked', changed: changed, eligible: eligible };
  }

  function patch() {
    if (destroyed) return;
    var stamp = now();
    if (stamp - lastPatchAt < 220) return;
    lastPatchAt = stamp;
    cleanupCallbacks();
    cleanupRecent();
    patchHtml5Qrcode();
    patchOtherLibraries();
    if (stamp - lastGuideAt > 1200) {
      lastGuideAt = stamp;
      ensureScannerGuide();
    }
    reportCount(false);
  }

  function clearPatchTimers() {
    for (var i = 0; i < patchTimers.length; i++) {
      try { w.clearTimeout(patchTimers[i]); } catch (_) {}
    }
    patchTimers = [];
  }

  function schedulePatch() {
    clearPatchTimers();
    var delays = [0, 250, 700, 1500, 3000, 6000, 12000, 22000];
    for (var i = 0; i < delays.length; i++) {
      (function (delay) {
        patchTimers.push(w.setTimeout(function () {
          patch();
        }, delay));
      })(delays[i]);
    }
  }

  function installObserver() {
    if (observer || !w.MutationObserver || !document.documentElement) return;
    var timer = 0;
    observer = new w.MutationObserver(function (records) {
      if (destroyed || document.hidden) return;
      var useful = false;
      for (var i = 0; i < records.length && !useful; i++) {
        var added = records[i].addedNodes || [];
        for (var j = 0; j < added.length; j++) {
          var node = added[j];
          if (!node || node.nodeType !== 1) continue;
          var tag = String(node.tagName || '').toLowerCase();
          if (tag === 'video' || tag === 'script' || (node.querySelector && node.querySelector('video,script'))) {
            useful = true;
            break;
          }
        }
      }
      if (!useful || timer) return;
      timer = w.setTimeout(function () {
        timer = 0;
        patch();
      }, 350);
    });
    try { observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'disabled'] }); } catch (_) {}
  }

  function invokeCallback(entry, text) {
    var detail = decodedResult(text);
    if (entry.mode === 'qrscanner') {
      return entry.fn({
        data: text,
        text: text,
        rawValue: text,
        cornerPoints: [],
        toString: function () { return text; },
        valueOf: function () { return text; }
      });
    }
    if (entry.mode === 'quagga') {
      return entry.fn({
        codeResult: { code: text, format: 'code_128' },
        result: { code: text }
      });
    }
    return entry.fn(text, detail);
  }

  function invokeLatestCaptured(text) {
    cleanupCallbacks();
    var attempted = 0;
    for (var i = callbacks.length - 1; i >= 0 && attempted < 2; i--) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      attempted++;
      try {
        invokeCallback(entry, text);
        entry.addedAt = now();
        return { called: 1, source: entry.source, errors: 0 };
      } catch (_) {}
    }
    return { called: 0, source: '', errors: attempted };
  }

  function invokeOneNamed(text) {
    var detail = decodedResult(text);
    var names = [
      'onScanSuccess', 'qrCodeSuccessCallback', 'scanSuccess',
      'scannerSuccess', 'onQrCodeScanned', 'onBarcodeScanned',
      'handleScan', 'handleBarcode', 'processBarcode'
    ];
    for (var i = 0; i < names.length; i++) {
      try {
        if (typeof w[names[i]] === 'function') {
          w[names[i]](text, detail);
          return names[i];
        }
      } catch (_) {}
    }
    return '';
  }

  function fieldScore(el) {
    var meta = '';
    try {
      meta = [
        el.id, el.name, el.type, el.placeholder,
        el.getAttribute && el.getAttribute('aria-label'),
        el.getAttribute && el.getAttribute('data-testid'),
        typeof el.className === 'string' ? el.className : ''
      ].filter(Boolean).join(' ').toLowerCase();
    } catch (_) {}
    var score = 0;
    if (/barcode/.test(meta)) score += 70;
    if (/(^|\W)hu($|\W)/.test(meta)) score += 65;
    if (/qr|scan|scanner/.test(meta)) score += 45;
    if (/kode|code/.test(meta)) score += 30;
    if (/serial|nomor|number/.test(meta)) score += 12;
    try {
      if (el.disabled || el.readOnly || el.type === 'hidden') score -= 60;
      var rect = el.getBoundingClientRect();
      if (rect.width > 20 && rect.height > 12) score += 10;
    } catch (_) {}
    return score;
  }

  function setNativeValue(el, text) {
    var tag = String(el.tagName || '').toLowerCase();
    if (tag === 'input') {
      var inputSetter = Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype, 'value');
      if (inputSetter && inputSetter.set) inputSetter.set.call(el, text); else el.value = text;
    } else if (tag === 'textarea') {
      var areaSetter = Object.getOwnPropertyDescriptor(w.HTMLTextAreaElement.prototype, 'value');
      if (areaSetter && areaSetter.set) areaSetter.set.call(el, text); else el.value = text;
    } else if (el.isContentEditable) {
      el.textContent = text;
    }
  }

  function fillBestInput(text) {
    var nodes = [];
    try { nodes = Array.prototype.slice.call(document.querySelectorAll('input,textarea,[contenteditable="true"]')); } catch (_) {}
    var best = null;
    var bestScore = 19;
    var limit = Math.min(nodes.length, 250);
    for (var i = 0; i < limit; i++) {
      var score = fieldScore(nodes[i]);
      if (score > bestScore) {
        best = nodes[i];
        bestScore = score;
      }
    }
    if (!best) return false;
    try {
      best.disabled = false;
      best.readOnly = false;
      best.removeAttribute('disabled');
      best.removeAttribute('readonly');
      setNativeValue(best, text);
      try { best.focus(); } catch (_) {}
      try { best.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
      try { best.dispatchEvent(new Event('change', { bubbles: true })); } catch (_) {}
      return true;
    } catch (_) {
      return false;
    }
  }

  function dispatchFallbackEvents(text) {
    var detail = decodedResult(text);
    var names = ['scanSuccess', 'qr-scanned', 'barcode-scanned'];
    var count = 0;
    for (var i = 0; i < names.length; i++) {
      try {
        document.dispatchEvent(new CustomEvent(names[i], { bubbles: true, detail: detail }));
        count++;
      } catch (_) {}
    }
    return count;
  }

  function processOne(item) {
    patch();
    var captured = invokeLatestCaptured(item.text);
    var named = '';
    var input = false;
    var events = 0;

    if (!captured.called) named = invokeOneNamed(item.text);
    if (!captured.called && !named) input = fillBestInput(item.text);
    if (!captured.called && !named && !input) events = dispatchFallbackEvents(item.text);

    var ok = !!(captured.called || named || input);
    var result = {
      ok: ok,
      callbacks: captured.called,
      source: captured.source,
      named: named,
      inputs: input ? 1 : 0,
      events: events,
      errors: captured.errors,
      captured: callbacks.length,
      queued: queue.length,
      sources: callbackSources(),
      requestId: item.requestId || '',
      text: item.text,
      reason: ok ? '' : 'scanner_not_ready'
    };

    if (captured.called) report('Kode terkirim ke scanner aktif.');
    else if (named) report('Kode terkirim lewat ' + named + '.');
    else if (input) report('Kode diisi ke kolom barcode/HU.');
    else report('Scanner belum siap. Buka ulang menu Scan QR.');

    androidCall('onSendReport', [JSON.stringify(result)]);
  }

  function processQueue() {
    if (processing || destroyed) return;
    processing = true;

    function next() {
      if (destroyed || !queue.length) {
        processing = false;
        return;
      }
      var item = queue.shift();
      try { processOne(item); } catch (_) {}
      w.setTimeout(next, SEND_GAP_MS);
    }

    next();
  }

  function send(text, requestId) {
    text = String(text == null ? '' : text).trim();
    if (!text) {
      report('Kode masih kosong.');
      return JSON.stringify({ ok: false, reason: 'empty' });
    }

    var stamp = now();
    if (recent[text] && stamp - recent[text] < DUPLICATE_MS) {
      report('Kode sama baru saja diproses.');
      return JSON.stringify({ ok: false, reason: 'duplicate' });
    }
    recent[text] = stamp;
    cleanupRecent();

    if (queue.length >= MAX_QUEUE) {
      report('Antrean scan penuh. Tunggu sebentar.');
      return JSON.stringify({ ok: false, reason: 'queue_full', queued: queue.length });
    }

    queue.push({ text: text, addedAt: stamp, requestId: String(requestId == null ? '' : requestId) });
    processQueue();
    return JSON.stringify({ ok: true, queued: queue.length, processing: processing });
  }

  function status() {
    patch();
    return JSON.stringify({
      version: VERSION,
      callbacks: callbacks.length,
      sources: callbackSources(),
      queued: queue.length,
      processing: processing,
      html5Qrcode: typeof w.Html5Qrcode === 'function',
      html5Scanner: typeof w.Html5QrcodeScanner === 'function',
      universalGreenCheck: true,
      packingCheckedTotal: lastPackingCheckedTotal
    });
  }

  function destroy() {
    destroyed = true;
    clearPatchTimers();
    queue = [];
    callbacks = [];
    try { if (observer) observer.disconnect(); } catch (_) {}
    observer = null;
    reportCount(true);
  }

  w.__LPWScannerBridge = {
    version: VERSION,
    patch: patch,
    send: send,
    status: status,
    checkGreenColumns: checkGreenColumnsManual,
    checkPackingPassed: checkGreenColumnsManual,
    report: report,
    destroy: destroy,
    getCallbackCount: function () { return callbacks.length; }
  };

  try {
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) schedulePatch();
    }, false);
    w.addEventListener('pageshow', schedulePatch, false);
    w.addEventListener('pagehide', function () {
      clearPatchTimers();
      queue = [];
    }, false);
  } catch (_) {}

  patch();
  installObserver();
  schedulePatch();
  report('Tools stabil siap. Buka menu Scan QR lalu kirim kode.');
})();



;(function(){
'use strict';
var w=window;
if(w.__ICEToolsV30){try{w.__ICEToolsV30.rescan();}catch(e){} return;}
var T={
  version:'30.1',
  requests:[], logs:[], qrs:[], hus:[],
  qrRe:/\bMPA-[A-Z0-9._:/-]{3,}\b/gi,
  huKeyRe:/^(hu|hu[_\s-]?code|hu[_\s-]?no|hu[_\s-]?number|handling[_\s-]?unit|handling[_\s-]?unit[_\s-]?(code|no|number))$/i,
  huCtxRe:/\b(hu|handling\s*unit)\b/i,
  esc:function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});},
  uniq:function(a){var o={},r=[];for(var i=0;i<a.length;i++){var k=String(a[i]);if(!o[k]){o[k]=1;r.push(a[i]);}}return r;},
  addQr:function(code,source,context){code=String(code||'').toUpperCase();if(!code)return;for(var i=0;i<this.qrs.length;i++){var x=this.qrs[i];if(x.code===code&&x.source===source&&x.context===context)return;}this.qrs.push({code:code,source:source||'',context:context||''});},
  addHu:function(value,source,context,key){value=String(value||'').trim();if(!value)return;for(var i=0;i<this.hus.length;i++){var x=this.hus[i];if(x.value===value&&x.source===source&&x.context===context)return;}this.hus.push({value:value,source:source||'',context:context||'',key:key||''});},
  scanText:function(txt,source,context){txt=String(txt==null?'':txt);var m=txt.match(this.qrRe)||[];for(var i=0;i<m.length;i++)this.addQr(m[i],source,context);},
  walk:function(obj,source,path,depth,seen){if(depth>7||obj==null)return;if(typeof obj==='string'){this.scanText(obj,source,path);return;}if(typeof obj!=='object')return;seen=seen||[];if(seen.indexOf(obj)>=0)return;seen.push(obj);if(Array.isArray(obj)){for(var i=0;i<obj.length&&i<800;i++)this.walk(obj[i],source,path+'['+i+']',depth+1,seen);return;}var keys=[];try{keys=Object.keys(obj);}catch(e){}for(var j=0;j<keys.length&&j<1500;j++){var k=keys[j],v;try{v=obj[k];}catch(e){continue;}var p=path+'.'+k;if(this.huKeyRe.test(k)){var val='';try{val=typeof v==='string'?v:JSON.stringify(v);}catch(e){val=String(v);}if(val&&val!=='[object Object]')this.addHu(val,source,p,k);}if(typeof v==='string')this.scanText(v,source,p);this.walk(v,source,p,depth+1,seen);}},
  scanStorage:function(){var self=this;function one(st,name){try{for(var i=0;i<st.length;i++){var k=st.key(i),v=st.getItem(k)||'';if(self.huKeyRe.test(k)||self.huCtxRe.test(k))self.addHu(v,name,k,k);self.scanText(v,name,k);try{self.walk(JSON.parse(v),name+'-json',k,0,[]);}catch(e){}}}catch(e){}}one(localStorage,'localStorage');one(sessionStorage,'sessionStorage');},
  scanDom:function(){var self=this,els=[];try{els=[].slice.call(document.querySelectorAll('*'),0,25000);}catch(e){}for(var i=0;i<els.length;i++){var el=els[i];try{var tag=(el.tagName||'').toLowerCase(),id=el.id||'',name=el.getAttribute('name')||'',aria=el.getAttribute('aria-label')||'',ph=el.getAttribute('placeholder')||'',title=el.getAttribute('title')||'';var labels=[id,name,aria,ph,title].join(' ');var value='';if(typeof el.value==='string')value=el.value;if(!value)value=(el.textContent||'').trim();var explicit=self.huKeyRe.test(id)||self.huKeyRe.test(name)||self.huCtxRe.test(labels);var labelText='';if(id){try{var lb=document.querySelector('label[for="'+CSS.escape(id)+'"]');if(lb)labelText=(lb.textContent||'').trim();}catch(e){}}if((explicit||self.huCtxRe.test(labelText))&&value&&value.length<200)self.addHu(value,'dom',tag+'#'+id+'['+name+']',labels||labelText);var attrs='';try{attrs=[].map.call(el.attributes,function(a){return a.name+'='+a.value;}).join(' ');}catch(e){}self.scanText(attrs,'dom-attr',tag+'#'+id);if(value&&value.length<5000)self.scanText(value,'dom-value',tag+'#'+id);}catch(e){}}try{self.scanText(document.documentElement.outerHTML.slice(0,1800000),'dom-html',location.href);}catch(e){}try{var scripts=[].slice.call(document.scripts);for(var s=0;s<scripts.length;s++){var tx=(scripts[s].textContent||'').slice(0,250000);self.scanText(tx,'script','script['+s+']');var rx=/["']?(hu|hu[_-]?code|hu[_-]?no|handling[_-]?unit(?:[_-]?(?:code|no|number))?)["']?\s*[:=]\s*["']([^"']+)["']/gi,mm;while((mm=rx.exec(tx)))self.addHu(mm[2],'script','script['+s+']',mm[1]);}}catch(e){}self.scanStorage();},
  rescan:function(){this.scanDom();},
  copy:function(t){t=String(t||'');try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t);return;}}catch(e){}try{var a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();}catch(e){}},
  hookNet:function(){if(this.netHooked)return;this.netHooked=true;var self=this;if(w.fetch){var of=w.fetch.bind(w);w.fetch=function(){var args=arguments,url='';try{url=typeof args[0]==='string'?args[0]:args[0].url||'';}catch(e){}return of.apply(w,args).then(function(res){try{res.clone().text().then(function(body){self.requests.push({type:'fetch',url:url,status:res.status,body:String(body).slice(0,80000)});if(self.requests.length>300)self.requests.shift();self.scanText(body,'fetch',url);try{self.walk(JSON.parse(body),'fetch-json',url,0,[]);}catch(e){}});}catch(e){}return res;});};}
    try{var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__iceNet={m:m,u:String(u||'')};return xo.apply(this,arguments);};XMLHttpRequest.prototype.send=function(){this.addEventListener('loadend',function(){var b='';try{b=this.responseType==='json'?JSON.stringify(this.response):this.responseText||'';}catch(e){}var meta=this.__iceNet||{};self.requests.push({type:'xhr',url:meta.u||'',status:this.status,body:String(b).slice(0,80000)});if(self.requests.length>300)self.requests.shift();self.scanText(b,'xhr',meta.u||'');try{self.walk(JSON.parse(b),'xhr-json',meta.u||'',0,[]);}catch(e){}});return xs.apply(this,arguments);};}catch(e){}},
  correlate:function(){var out=[];for(var i=0;i<this.hus.length;i++){var h=this.hus[i],qs=[];for(var j=0;j<this.qrs.length;j++){var q=this.qrs[j];if(q.source===h.source&&q.context===h.context)qs.push(q.code);else if(q.context&&h.context&&(q.context.indexOf(h.context)>=0||h.context.indexOf(q.context)>=0))qs.push(q.code);}out.push({hu:h.value,source:h.source,context:h.context,qrs:this.uniq(qs)});}return out;},
  ensurePanel:function(){var p=document.getElementById('__ice_v30_panel');if(p)return p;var st=document.createElement('style');st.textContent='#__ice_v30_panel{position:fixed;inset:3%;z-index:2147483647;background:#0f172a;color:#fff;border-radius:16px;box-shadow:0 0 0 9999px rgba(0,0,0,.65);font:13px system-ui,sans-serif;overflow:hidden}#__ice_v30_panel .h{height:48px;display:flex;align-items:center;padding:0 12px;background:#111827;border-bottom:1px solid #334155}#__ice_v30_panel .h b{flex:1}#__ice_v30_panel button{border:0;border-radius:9px;background:#334155;color:#fff;padding:8px 10px;margin:3px}#__ice_v30_panel .b{height:calc(100% - 48px);overflow:auto;padding:10px}#__ice_v30_panel .c{background:#111827;border:1px solid #334155;border-radius:10px;padding:9px;margin-bottom:8px;word-break:break-word}#__ice_v30_panel .m{color:#94a3b8;font-size:12px}#__ice_v30_panel pre{white-space:pre-wrap;word-break:break-all;background:#020617;padding:8px;border-radius:8px}';document.documentElement.appendChild(st);p=document.createElement('div');p.id='__ice_v30_panel';p.innerHTML='<div class=h><b>ICE Tools</b><button id=__ice_close>✕</button></div><div class=b></div>';document.documentElement.appendChild(p);p.querySelector('#__ice_close').onclick=function(){p.remove();};return p;},
  show:function(title,html){var p=this.ensurePanel();p.querySelector('.h b').textContent=title;p.querySelector('.b').innerHTML=html;},
  inspector:function(){this.rescan();var d=this.correlate(),html='';if(!d.length)html='<div class=c><b>HU asli belum ditemukan.</b><div class=m>ICE tidak menganggap kode Record/Item sebagai HU.</div></div>';for(var i=0;i<d.length;i++){var x=d[i];html+='<div class=c><div class=m>HU • '+this.esc(x.source)+'</div><b>'+this.esc(x.hu)+'</b><div class=m>'+this.esc(x.context)+'</div>';if(x.qrs.length){for(var j=0;j<x.qrs.length;j++)html+='<div><code>'+this.esc(x.qrs[j])+'</code> <button onclick="window.__ICEToolsV30.copy(\''+this.esc(x.qrs[j])+'\')">Copy</button></div>';}else html+='<div class=m>Split QR belum dapat dipastikan untuk HU ini.</div>';html+='</div>';}this.show('HU Inspector',html);},
  hiddenHu:function(){this.rescan();var html='';for(var i=0;i<this.hus.length;i++){var x=this.hus[i];html+='<div class=c><b>'+this.esc(x.value)+'</b><div class=m>'+this.esc(x.source)+' • '+this.esc(x.context)+' • '+this.esc(x.key)+'</div><button onclick="window.__ICEToolsV30.copy(\''+this.esc(x.value)+'\')">Copy HU</button></div>';}if(!html)html='<div class=c>Belum ada HU dari field/key yang jelas.</div>';this.show('Hidden HU Finder',html);},
  qrFinder:function(){this.rescan();var map={},html='';for(var i=0;i<this.qrs.length;i++){var x=this.qrs[i];if(!map[x.code])map[x.code]=[];map[x.code].push(x);}for(var q in map){html+='<div class=c><b>'+this.esc(q)+'</b><div class=m>'+map[q].map(function(x){return T.esc(x.source)+' • '+T.esc(x.context);}).join('<br>')+'</div><button onclick="window.__ICEToolsV30.copy(\''+this.esc(q)+'\')">Copy QR</button></div>';}if(!html)html='<div class=c>MPA-... belum ditemukan.</div>';this.show('Split QR Finder',html);},
  hunter:function(){this.hookNet();var html='<div class=c><b>QR Hunter aktif.</b><div class=m>Request berikutnya akan dipantau. Jika request sudah terjadi sebelum hook aktif, buka ulang/refresh halaman terkait.</div></div>';for(var i=this.requests.length-1;i>=0&&i>this.requests.length-80;i--){var r=this.requests[i];html+='<div class=c><b>'+this.esc(r.type.toUpperCase())+' '+this.esc(r.status)+'</b><div class=m>'+this.esc(r.url)+'</div><details><summary>Response</summary><pre>'+this.esc(r.body)+'</pre></details></div>';}this.show('QR Hunter',html);},
  devtools:function(){this.hookNet();var html='<div class=c><button onclick="window.__ICEToolsV30.devElements()">Elements</button><button onclick="window.__ICEToolsV30.devSource()">Source</button><button onclick="window.__ICEToolsV30.devNetwork()">Network</button><button onclick="window.__ICEToolsV30.devStorage()">Storage</button><button onclick="window.__ICEToolsV30.devFind()">Find</button></div><div class=c><b>Mini DevTools ICE</b><div class=m>Bukan Chrome DevTools penuh, tetapi bisa melihat DOM, source, request yang tertangkap, storage, dan pencarian teks.</div></div>';this.show('DevTools',html);},
  devElements:function(){var s='';try{s=document.documentElement.outerHTML.slice(0,500000);}catch(e){}this.show('DevTools • Elements','<div class=c><button onclick="window.__ICEToolsV30.copy(document.documentElement.outerHTML)">Copy DOM</button><pre>'+this.esc(s)+'</pre></div>');},
  devSource:function(){var s='';try{s='<!DOCTYPE html>\n'+document.documentElement.outerHTML;}catch(e){}this.show('DevTools • Source','<div class=c><button onclick="window.__ICEToolsV30.copy(\'source copied\')">Gunakan Copy DOM di Elements</button><pre>'+this.esc(s.slice(0,500000))+'</pre></div>');},
  devNetwork:function(){var h='';for(var i=this.requests.length-1;i>=0&&i>this.requests.length-100;i--){var r=this.requests[i];h+='<div class=c><b>'+this.esc(r.type)+' '+this.esc(r.status)+'</b><div class=m>'+this.esc(r.url)+'</div><details><summary>Response</summary><pre>'+this.esc(r.body)+'</pre></details></div>';}if(!h)h='<div class=c>Belum ada request tertangkap.</div>';this.show('DevTools • Network',h);},
  devStorage:function(){var o={localStorage:{},sessionStorage:{}};try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);o.localStorage[k]=localStorage.getItem(k);}}catch(e){}try{for(var j=0;j<sessionStorage.length;j++){var q=sessionStorage.key(j);o.sessionStorage[q]=sessionStorage.getItem(q);}}catch(e){}this.show('DevTools • Storage','<div class=c><pre>'+this.esc(JSON.stringify(o,null,2))+'</pre></div>');},
  devFind:function(){this.show('DevTools • Find','<div class=c><input id=__ice_find style="width:100%;box-sizing:border-box;padding:9px;background:#020617;color:#fff;border:1px solid #475569;border-radius:8px" placeholder="Cari MPA-, HU, key..."><button onclick="window.__ICEToolsV30.doFind()">Cari</button><div id=__ice_find_out></div></div>');},
  doFind:function(){var inp=document.getElementById('__ice_find'),out=document.getElementById('__ice_find_out');if(!inp||!out)return;var q=(inp.value||'').trim(),html='';if(!q){out.innerHTML='Masukkan teks.';return;}var src='';try{src=document.documentElement.outerHTML;}catch(e){}var low=src.toLowerCase(),n=q.toLowerCase(),p=0,c=0;while((p=low.indexOf(n,p))>=0&&c<80){html+='<pre>'+this.esc(src.slice(Math.max(0,p-140),Math.min(src.length,p+n.length+220)))+'</pre>';p+=n.length;c++;}out.innerHTML=html||'Tidak ditemukan.';}
};
w.__ICEToolsV30=T;
T.hookNet();
try{T.rescan();}catch(e){}
})();
