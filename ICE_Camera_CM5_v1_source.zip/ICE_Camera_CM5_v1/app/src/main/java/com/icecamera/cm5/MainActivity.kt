package com.icecamera.cm5

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.icecamera.cm5.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var camera: Camera? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var isVideoMode = false
    private var flashMode = ImageCapture.FLASH_MODE_OFF
    private var timerSeconds = 0

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        if (grants[Manifest.permission.CAMERA] == true) startCamera()
        else Toast.makeText(this, "Izin kamera diperlukan", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupUi()
        requestPermissionsIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(permissions)
    }

    private fun setupUi() {
        binding.btnShutter.setOnClickListener { if (isVideoMode) toggleRecording() else takePhotoWithTimer() }
        binding.btnSwitch.setOnClickListener {
            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            startCamera()
        }
        binding.modePhoto.setOnClickListener { setMode(false) }
        binding.modeVideo.setOnClickListener { setMode(true) }
        binding.btnFlash.setOnClickListener {
            flashMode = when (flashMode) {
                ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
            imageCapture?.flashMode = flashMode
            binding.btnFlash.text = "Flash: " + when (flashMode) { ImageCapture.FLASH_MODE_AUTO -> "Auto"; ImageCapture.FLASH_MODE_ON -> "On"; else -> "Off" }
        }
        binding.btnTimer.setOnClickListener {
            timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 10; else -> 0 }
            binding.btnTimer.text = "Timer: $timerSeconds"
        }
        binding.btnGrid.setOnClickListener {
            val newVisibility = if (binding.gridV1.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            listOf(binding.gridV1, binding.gridV2, binding.gridH1, binding.gridH2).forEach { it.visibility = newVisibility }
        }
        binding.btnGallery.setOnClickListener {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)) }
                .onFailure { Toast.makeText(this, "Buka aplikasi Galeri secara manual", Toast.LENGTH_SHORT).show() }
        }
        binding.previewView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val point = binding.previewView.meteringPointFactory.createPoint(event.x, event.y)
                val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                    .setAutoCancelDuration(3, TimeUnit.SECONDS).build()
                camera?.cameraControl?.startFocusAndMetering(action)
                true
            } else false
        }
    }

    private fun setMode(video: Boolean) {
        if (recording != null) return
        isVideoMode = video
        binding.modePhoto.setTextColor(if (!video) 0xFFFFD43B.toInt() else 0xFFFFFFFF.toInt())
        binding.modeVideo.setTextColor(if (video) 0xFFFFD43B.toInt() else 0xFFFFFFFF.toInt())
        binding.btnShutter.setBackgroundResource(if (video) R.drawable.record else R.drawable.shutter)
        binding.statusText.text = if (video) "Mode video" else "Mode foto"
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                val preview = Preview.Builder().build().also { it.surfaceProvider = binding.previewView.surfaceProvider }
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setFlashMode(flashMode)
                    .build()
                val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.FHD)).build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview, imageCapture, videoCapture)
                binding.statusText.text = "ICE Camera siap"
            } catch (e: Exception) {
                binding.statusText.text = "Kamera gagal: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhotoWithTimer() {
        if (timerSeconds == 0) takePhoto() else object : CountDownTimer(timerSeconds * 1000L, 1000) {
            override fun onTick(ms: Long) { binding.statusText.text = "${(ms + 999) / 1000}" }
            override fun onFinish() { takePhoto() }
        }.start()
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        binding.btnShutter.isEnabled = false
        binding.statusText.text = "Menyimpan foto…"
        val name = "ICE_${timestamp()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/ICE Camera")
        }
        val options = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values).build()
        capture.takePicture(options, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                binding.btnShutter.isEnabled = true
                binding.statusText.text = "Foto tersimpan"
                Toast.makeText(this@MainActivity, "Tersimpan: $name", Toast.LENGTH_SHORT).show()
            }
            override fun onError(exc: ImageCaptureException) {
                binding.btnShutter.isEnabled = true
                binding.statusText.text = "Gagal: ${exc.message}"
            }
        })
    }

    private fun toggleRecording() {
        recording?.let {
            it.stop(); recording = null; binding.statusText.text = "Menyelesaikan video…"; return
        }
        val capture = videoCapture ?: return
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "ICE_${timestamp()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "DCIM/ICE Camera")
        }
        val options = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(values).build()
        var pending = capture.output.prepareRecording(this, options)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pending = pending.withAudioEnabled()
        recording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> binding.statusText.text = "Merekam… tekan lagi untuk berhenti"
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    binding.statusText.text = if (event.hasError()) "Video gagal: ${event.error}" else "Video tersimpan"
                }
            }
        }
    }

    private fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())

    override fun onDestroy() {
        recording?.stop()
        super.onDestroy()
    }
}
