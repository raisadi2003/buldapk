# ICE Camera CM5 v1

Aplikasi kamera alternatif untuk TECNO CAMON 40 / CM5. Dibuat dengan CameraX, tidak memakai pipeline aplikasi kamera bawaan TECNO.

## Fitur v1
- Foto JPEG ke `DCIM/ICE Camera`
- Video 1080p + audio
- Kamera depan/belakang
- Flash Off/Auto/On
- Timer 0/3/10 detik
- Grid 3x3
- Tap-to-focus
- UI sederhana bergaya kamera bawaan

## Build GitHub Actions
1. Buat repository baru.
2. Upload seluruh isi source ini (bukan ZIP di dalam repository).
3. Buka tab **Actions** > **Build ICE Camera CM5** > **Run workflow**.
4. Setelah selesai, unduh artifact `ICE-Camera-CM5-APK`.

Catatan: APK release dari workflow ini belum ditandatangani dengan keystore pribadi. Untuk pemasangan cepat gunakan APK debug.
