(function () {
  'use strict';

  var w = window;
  var VERSION = 7;
  var existing = w.__LPWScannerBridge;
  if (existing && existing.version === VERSION) {
    try { existing.patch(); } catch (_) {}
    return;
  }
  if (existing && existing.version !== VERSION) {
    try { existing.destroy(); } catch (_) {}
  }

  var callbacks = [];
  var patched = {};
  var patchTimers = [];
  var observer = null;
  var lastPatchAt = 0;
  var lastGuideAt = 0;
  var lastPackingCheckedTotal = 0;
  var lastCount = -1;
  var recent = {};
  var queue = [];
  var processing = false;
  var destroyed = false;

  var MAX_CALLBACKS = 4;
  var MAX_QUEUE = 24;
  var CALLBACK_TTL = 3 * 60 * 1000;
  var DUPLICATE_MS = 1100;
  var SEND_GAP_MS = 140;

  function now() { return Date.now ? Date.now() : new Date().getTime(); }

  function androidCall(name, args) {
    try {
      if (w.AndroidBridge && typeof w.AndroidBridge[name] === 'function') {
        w.AndroidBridge[name].apply(w.AndroidBridge, args || []);
      }
    } catch (_) {}
  }

  function report(message) {
    androidCall('onStatus', [String(message || '')]);
  }

  function reportCount(force) {
    var count = callbacks.length;
    if (!force && count === lastCount) return;
    lastCount = count;
    androidCall('onCallbackCount', [count]);
  }

  function callbackSources() {
    var out = [];
    for (var i = callbacks.length - 1; i >= 0; i--) {
      var source = callbacks[i] && callbacks[i].source;
      if (source && out.indexOf(source) < 0) out.push(source);
    }
    return out;
  }

  function cleanupRecent() {
    var cutoff = now() - Math.max(DUPLICATE_MS * 4, 10000);
    for (var key in recent) {
      if (Object.prototype.hasOwnProperty.call(recent, key) && recent[key] < cutoff) {
        delete recent[key];
      }
    }
  }

  function cleanupCallbacks() {
    var cutoff = now() - CALLBACK_TTL;
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      if (entry.addedAt && entry.addedAt < cutoff) continue;
      next.push(entry);
    }
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
  }

  function addCallback(fn, source, mode) {
    if (typeof fn !== 'function') return;
    source = source || 'callback';
    mode = mode || 'html5';

    var stamp = now();
    var next = [];
    for (var i = 0; i < callbacks.length; i++) {
      var item = callbacks[i];
      if (!item || item.fn === fn || item.source === source) continue;
      next.push(item);
    }
    next.push({ fn: fn, source: source, mode: mode, addedAt: stamp });
    callbacks = next.slice(-MAX_CALLBACKS);
    reportCount(false);
    report('Scanner siap. Jalur aktif: ' + source + '.');
  }

  function decodedResult(text) {
    return {
      decodedText: text,
      text: text,
      rawValue: text,
      data: text,
      code: text,
      barcode: text,
      result: {
        text: text,
        format: { formatName: 'QR_CODE', format: 'QR_CODE' }
      }
    };
  }

  function wrapMethod(proto, name, makeWrapper, key) {
    try {
      if (!proto || typeof proto[name] !== 'function') return false;
      if (proto[name].__iceBridgeV4) return true;
      var original = proto[name];
      var wrapped = makeWrapper(original);
      wrapped.__iceBridgeV4 = true;
      wrapped.__iceOriginal = original;
      proto[name] = wrapped;
      patched[key || name] = true;
      return true;
    } catch (_) {
      return false;
    }
  }

  function patchHtml5Qrcode() {
    try {
      var Html5Qrcode = w.Html5Qrcode;
      if (typeof Html5Qrcode === 'function' && Html5Qrcode.prototype) {
        wrapMethod(Html5Qrcode.prototype, 'start', function (original) {
          return function (cameraIdOrConfig, configuration, successCallback, errorCallback) {
            addCallback(successCallback, 'Html5Qrcode.start', 'html5');
            return original.call(this, cameraIdOrConfig, configuration, successCallback, errorCallback);
          };
        }, 'Html5Qrcode.start');
      }
    } catch (_) {}

    try {
      var Scanner = w.Html5QrcodeScanner;
      if (typeof Scanner === 'function' && Scanner.prototype) {
        wrapMethod(Scanner.prototype, 'render', function (original) {
          return function (successCallback, errorCallback) {
            addCallback(successCallback, 'Html5QrcodeScanner.render', 'html5');
            return original.call(this, successCallback, errorCallback);
          };
        }, 'Html5QrcodeScanner.render');
      }
    } catch (_) {}
  }

  function patchOtherLibraries() {
    try {
      var QrScanner = w.QrScanner;
      if (typeof QrScanner === 'function' && !QrScanner.__iceBridgeV4Wrapped && typeof Proxy === 'function') {
        var Wrapped = new Proxy(QrScanner, {
          construct: function (target, args, newTarget) {
            addCallback(args && args[1], 'QrScanner.constructor', 'qrscanner');
            return Reflect.construct(target, args, newTarget === Wrapped ? target : newTarget);
          }
        });
        Wrapped.__iceBridgeV4Wrapped = true;
        w.QrScanner = Wrapped;
      }
    } catch (_) {}

    try {
      var InstascanScanner = w.Instascan && w.Instascan.Scanner;
      if (typeof InstascanScanner === 'function' && InstascanScanner.prototype) {
        wrapMethod(InstascanScanner.prototype, 'addListener', function (original) {
          return function (eventName, callback) {
            if (String(eventName).toLowerCase() === 'scan') {
              addCallback(callback, 'Instascan.addListener', 'text');
            }
            return original.call(this, eventName, callback);
          };
        }, 'Instascan.addListener');
      }
    } catch (_) {}

    try {
      var Quagga = w.Quagga;
      if (Quagga && typeof Quagga.onDetected === 'function' && !Quagga.onDetected.__iceBridgeV4) {
        var originalOnDetected = Quagga.onDetected;
        var wrappedOnDetected = function (callback) {
          addCallback(callback, 'Quagga.onDetected', 'quagga');
          return originalOnDetected.call(this, callback);
        };
        wrappedOnDetected.__iceBridgeV4 = true;
        Quagga.onDetected = wrappedOnDetected;
      }
    } catch (_) {}
  }

  function tryContinuousFocus(video) {
    try {
      if (!video || !video.srcObject || !video.srcObject.getVideoTracks) return;
      var track = video.srcObject.getVideoTracks()[0];
      if (!track || track.__iceFocusV4) return;
      track.__iceFocusV4 = true;
      if (!track.getCapabilities || !track.applyConstraints) return;
      var caps = track.getCapabilities() || {};
      if (caps.focusMode && Array.prototype.indexOf.call(caps.focusMode, 'continuous') >= 0) {
        track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(function () {});
      }
    } catch (_) {}
  }

  function directGuide(parent) {
    try {
      var children = parent.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i] && children[i].classList && children[i].classList.contains('ice-scan-guide')) {
          return children[i];
        }
      }
    } catch (_) {}
    return null;
  }

  function ensureScannerGuide() {
    if (document.hidden) return;
    var videos = [];
    try { videos = Array.prototype.slice.call(document.querySelectorAll('video')); } catch (_) {}
    for (var i = 0; i < videos.length; i++) {
      var video = videos[i];
      try {
        var rect = video.getBoundingClientRect();
        var style = w.getComputedStyle(video);
        if (rect.width < 160 || rect.height < 120 || style.display === 'none' || style.visibility === 'hidden') continue;
        tryContinuousFocus(video);
        var parent = video.parentElement;
        if (!parent || directGuide(parent)) continue;
        if (w.getComputedStyle(parent).position === 'static') parent.style.position = 'relative';

        var guide = document.createElement('div');
        guide.className = 'ice-scan-guide';
        guide.setAttribute('aria-hidden', 'true');
        guide.innerHTML = '<span>Pas-kan QR / barcode di dalam kotak</span><b></b>';
        guide.style.cssText = 'position:absolute;left:8%;right:8%;top:23%;height:48%;z-index:2147483000;pointer-events:none;border:2px solid rgba(34,197,94,.9);border-radius:14px;box-sizing:border-box;';
        var label = guide.querySelector('span');
        if (label) label.style.cssText = 'position:absolute;left:50%;bottom:-34px;transform:translateX(-50%);white-space:nowrap;background:rgba(15,23,42,.82);color:#fff;border-radius:999px;padding:6px 10px;font:600 12px system-ui,sans-serif;';
        var line = guide.querySelector('b');
        if (line) line.style.cssText = 'position:absolute;left:7%;right:7%;top:50%;height:2px;background:#22c55e;box-shadow:0 0 8px #22c55e;';
        parent.appendChild(guide);
      } catch (_) {}
    }
  }


  function greenHeaderText(value) {
    return String(value == null ? '' : value)
      .replace(/\u00a0/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function greenCompactText(value) {
    return greenHeaderText(value).replace(/[^a-z0-9]+/g, '');
  }

  function greenSemanticMatch(value) {
    var text = greenCompactText(value);
    return text === 'passed' || text === 'pass' || text === 'lulus' ||
      text === 'sesuai' || text === 'ok' || text === 'yes' || text === 'benar';
  }

  function greenRgb(value) {
    var text = String(value || '').trim().toLowerCase();
    var match = text.match(/^rgba?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)(?:\s*,\s*(\d+(?:\.\d+)?))?\s*\)$/);
    if (match) {
      return {
        r: Number(match[1]),
        g: Number(match[2]),
        b: Number(match[3]),
        a: match[4] == null ? 1 : Number(match[4])
      };
    }
    var hex = text.match(/^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i);
    if (!hex) return null;
    var raw = hex[1];
    if (raw.length === 3) raw = raw.charAt(0) + raw.charAt(0) + raw.charAt(1) + raw.charAt(1) + raw.charAt(2) + raw.charAt(2);
    var alpha = 1;
    if (raw.length === 8) {
      alpha = parseInt(raw.slice(6, 8), 16) / 255;
      raw = raw.slice(0, 6);
    }
    return {
      r: parseInt(raw.slice(0, 2), 16),
      g: parseInt(raw.slice(2, 4), 16),
      b: parseInt(raw.slice(4, 6), 16),
      a: alpha
    };
  }

  function greenColorMatch(value) {
    var rgb = greenRgb(value);
    if (!rgb || rgb.a < 0.12) return false;
    return rgb.g >= 70 && (rgb.g - rgb.r) >= 12 && (rgb.g - rgb.b) >= 7;
  }

  function greenElementMatch(element) {
    if (!element) return false;
    var hints = '';
    try {
      hints = [
        element.className,
        element.getAttribute && element.getAttribute('style'),
        element.getAttribute && element.getAttribute('title'),
        element.getAttribute && element.getAttribute('aria-label'),
        element.getAttribute && element.getAttribute('data-status'),
        element.getAttribute && element.getAttribute('data-state')
      ].join(' ').toLowerCase();
    } catch (_) {}

    if (/(^|[\s_\-])(success|green|passed|pass|lulus|sesuai)([\s_\-]|$)/i.test(hints)) return true;
    try {
      var text = element.innerText || element.textContent || '';
      if (greenSemanticMatch(text)) return true;
    } catch (_) {}

    try {
      var style = w.getComputedStyle(element);
      if (style && (
        greenColorMatch(style.backgroundColor) ||
        greenColorMatch(style.borderTopColor) ||
        greenColorMatch(style.borderRightColor) ||
        greenColorMatch(style.borderBottomColor) ||
        greenColorMatch(style.borderLeftColor) ||
        greenColorMatch(style.color)
      )) return true;
    } catch (_) {}
    return false;
  }

  function greenDescendantMatch(element) {
    if (greenElementMatch(element)) return true;
    var nodes = [];
    try { nodes = Array.prototype.slice.call(element.querySelectorAll('label,span,div,button,[class],[style]')); } catch (_) {}
    var limit = Math.min(nodes.length, 24);
    for (var i = 0; i < limit; i++) {
      if (greenElementMatch(nodes[i])) return true;
    }
    return false;
  }

  function greenHeaderRows(table) {
    var rows = [];
    try { rows = Array.prototype.slice.call(table.querySelectorAll('thead tr')); } catch (_) {}
    if (!rows.length) {
      try {
        var first = table.querySelector('tr');
        if (first) rows = [first];
      } catch (_) {}
    }
    return rows;
  }

  function greenTargetColumnIndexes(table) {
    var rows = greenHeaderRows(table);
    var semantic = {};
    var styled = {};
    var maxCells = 0;

    for (var r = 0; r < rows.length; r++) {
      var cells = [];
      try { cells = Array.prototype.slice.call(rows[r].children || []); } catch (_) {}
      maxCells = Math.max(maxCells, cells.length);
      for (var c = 0; c < cells.length; c++) {
        var text = cells[c].innerText || cells[c].textContent || '';
        if (greenSemanticMatch(text)) semantic[c] = true;
        else if (greenDescendantMatch(cells[c])) styled[c] = true;
      }
    }

    var result = Object.keys(semantic).map(function (key) { return Number(key); });
    if (!result.length) result = Object.keys(styled).map(function (key) { return Number(key); });
    result.sort(function (a, b) { return a - b; });

    // Jika seluruh header memperoleh warna hijau dari parent/theme, jangan anggap semua kolom target.
    if (!Object.keys(semantic).length && maxCells > 1 && result.length === maxCells) return [];
    return result;
  }

  function greenClickControl(control) {
    if (!control || control.disabled || control.checked) return false;
    try {
      control.click();
      if (control.checked) return true;
    } catch (_) {}

    try {
      var proto = w.HTMLInputElement && w.HTMLInputElement.prototype;
      var descriptor = proto && Object.getOwnPropertyDescriptor(proto, 'checked');
      if (descriptor && descriptor.set) descriptor.set.call(control, true);
      else control.checked = true;
      try { control.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
      try { control.dispatchEvent(new Event('change', { bubbles: true })); } catch (_) {}
      return !!control.checked;
    } catch (_) {
      return false;
    }
  }

  function greenRowControls(row, targetIndexes) {
    var cells = [];
    try { cells = Array.prototype.slice.call(row.children || []); } catch (_) {}
    var controls = [];
    var seen = [];

    function addFromCell(cell, requireGreen) {
      if (!cell || (requireGreen && !greenDescendantMatch(cell))) return;
      var found = [];
      try { found = Array.prototype.slice.call(cell.querySelectorAll('input[type="radio"],input[type="checkbox"]')); } catch (_) {}
      for (var i = 0; i < found.length; i++) {
        var control = found[i];
        if (!control || control.disabled || seen.indexOf(control) >= 0) continue;
        seen.push(control);
        controls.push(control);
        break;
      }
    }

    if (targetIndexes && targetIndexes.length) {
      for (var i = 0; i < targetIndexes.length; i++) {
        var index = targetIndexes[i];
        if (index >= 0 && index < cells.length) addFromCell(cells[index], false);
      }
      return controls;
    }

    for (var c = 0; c < cells.length; c++) addFromCell(cells[c], true);
    return controls;
  }

  function checkGreenColumnsManual() {
    var tables = [];
    try { tables = Array.prototype.slice.call(document.querySelectorAll('table')); } catch (_) {}
    var changed = 0;
    var eligible = 0;
    var foundGreenTarget = false;

    for (var t = 0; t < tables.length; t++) {
      var table = tables[t];
      var targetIndexes = greenTargetColumnIndexes(table);
      var rows = [];
      try { rows = Array.prototype.slice.call(table.querySelectorAll('tbody tr')); } catch (_) {}
      if (!rows.length) {
        try { rows = Array.prototype.slice.call(table.querySelectorAll('tr')); } catch (_) {}
        var headers = greenHeaderRows(table);
        rows = rows.filter(function (row) { return headers.indexOf(row) < 0; });
      }

      for (var r = 0; r < rows.length; r++) {
        var row = rows[r];
        if (!row || row.getAttribute('data-ice-skip-auto-passed') === '1') continue;
        var controls = greenRowControls(row, targetIndexes);
        if (controls.length) foundGreenTarget = true;
        for (var i = 0; i < controls.length; i++) {
          var control = controls[i];
          eligible++;
          if (!control.checked && greenClickControl(control)) changed++;
        }
      }
    }

    lastPackingCheckedTotal += changed;
    if (!foundGreenTarget) {
      report('Kolom hijau atau PASSED belum ditemukan di halaman ini.');
      return { ok: false, reason: 'green_column_missing', changed: 0 };
    }
    if (eligible < 1) {
      report('Belum ada baris yang dapat dicentang.');
      return { ok: false, reason: 'no_rows', changed: 0 };
    }
    if (changed < 1) {
      report('Semua pilihan hijau sudah dicentang. Submit tetap manual.');
      return { ok: true, reason: 'already_checked', changed: 0, eligible: eligible };
    }

    report(changed + ' pilihan hijau berhasil dicentang. Submit tetap manual.');
    return { ok: true, reason: 'checked', changed: changed, eligible: eligible };
  }

  function patch() {
    if (destroyed) return;
    var stamp = now();
    if (stamp - lastPatchAt < 220) return;
    lastPatchAt = stamp;
    cleanupCallbacks();
    cleanupRecent();
    patchHtml5Qrcode();
    patchOtherLibraries();
    if (stamp - lastGuideAt > 1200) {
      lastGuideAt = stamp;
      ensureScannerGuide();
    }
    reportCount(false);
  }

  function clearPatchTimers() {
    for (var i = 0; i < patchTimers.length; i++) {
      try { w.clearTimeout(patchTimers[i]); } catch (_) {}
    }
    patchTimers = [];
  }

  function schedulePatch() {
    clearPatchTimers();
    var delays = [0, 250, 700, 1500, 3000, 6000, 12000, 22000];
    for (var i = 0; i < delays.length; i++) {
      (function (delay) {
        patchTimers.push(w.setTimeout(function () {
          patch();
        }, delay));
      })(delays[i]);
    }
  }

  function installObserver() {
    if (observer || !w.MutationObserver || !document.documentElement) return;
    var timer = 0;
    observer = new w.MutationObserver(function (records) {
      if (destroyed || document.hidden) return;
      var useful = false;
      for (var i = 0; i < records.length && !useful; i++) {
        var added = records[i].addedNodes || [];
        for (var j = 0; j < added.length; j++) {
          var node = added[j];
          if (!node || node.nodeType !== 1) continue;
          var tag = String(node.tagName || '').toLowerCase();
          if (tag === 'video' || tag === 'script' || (node.querySelector && node.querySelector('video,script'))) {
            useful = true;
            break;
          }
        }
      }
      if (!useful || timer) return;
      timer = w.setTimeout(function () {
        timer = 0;
        patch();
      }, 350);
    });
    try { observer.observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class', 'style', 'disabled'] }); } catch (_) {}
  }

  function invokeCallback(entry, text) {
    var detail = decodedResult(text);
    if (entry.mode === 'qrscanner') {
      return entry.fn({
        data: text,
        text: text,
        rawValue: text,
        cornerPoints: [],
        toString: function () { return text; },
        valueOf: function () { return text; }
      });
    }
    if (entry.mode === 'quagga') {
      return entry.fn({
        codeResult: { code: text, format: 'code_128' },
        result: { code: text }
      });
    }
    return entry.fn(text, detail);
  }

  function invokeLatestCaptured(text) {
    cleanupCallbacks();
    var attempted = 0;
    for (var i = callbacks.length - 1; i >= 0 && attempted < 2; i--) {
      var entry = callbacks[i];
      if (!entry || typeof entry.fn !== 'function') continue;
      attempted++;
      try {
        invokeCallback(entry, text);
        entry.addedAt = now();
        return { called: 1, source: entry.source, errors: 0 };
      } catch (_) {}
    }
    return { called: 0, source: '', errors: attempted };
  }

  function invokeOneNamed(text) {
    var detail = decodedResult(text);
    var names = [
      'onScanSuccess', 'qrCodeSuccessCallback', 'scanSuccess',
      'scannerSuccess', 'onQrCodeScanned', 'onBarcodeScanned',
      'handleScan', 'handleBarcode', 'processBarcode'
    ];
    for (var i = 0; i < names.length; i++) {
      try {
        if (typeof w[names[i]] === 'function') {
          w[names[i]](text, detail);
          return names[i];
        }
      } catch (_) {}
    }
    return '';
  }

  function fieldScore(el) {
    var meta = '';
    try {
      meta = [
        el.id, el.name, el.type, el.placeholder,
        el.getAttribute && el.getAttribute('aria-label'),
        el.getAttribute && el.getAttribute('data-testid'),
        typeof el.className === 'string' ? el.className : ''
      ].filter(Boolean).join(' ').toLowerCase();
    } catch (_) {}
    var score = 0;
    if (/barcode/.test(meta)) score += 70;
    if (/(^|\W)hu($|\W)/.test(meta)) score += 65;
    if (/qr|scan|scanner/.test(meta)) score += 45;
    if (/kode|code/.test(meta)) score += 30;
    if (/serial|nomor|number/.test(meta)) score += 12;
    try {
      if (el.disabled || el.readOnly || el.type === 'hidden') score -= 60;
      var rect = el.getBoundingClientRect();
      if (rect.width > 20 && rect.height > 12) score += 10;
    } catch (_) {}
    return score;
  }

  function setNativeValue(el, text) {
    var tag = String(el.tagName || '').toLowerCase();
    if (tag === 'input') {
      var inputSetter = Object.getOwnPropertyDescriptor(w.HTMLInputElement.prototype, 'value');
      if (inputSetter && inputSetter.set) inputSetter.set.call(el, text); else el.value = text;
    } else if (tag === 'textarea') {
      var areaSetter = Object.getOwnPropertyDescriptor(w.HTMLTextAreaElement.prototype, 'value');
      if (areaSetter && areaSetter.set) areaSetter.set.call(el, text); else el.value = text;
    } else if (el.isContentEditable) {
      el.textContent = text;
    }
  }

  function fillBestInput(text) {
    var nodes = [];
    try { nodes = Array.prototype.slice.call(document.querySelectorAll('input,textarea,[contenteditable="true"]')); } catch (_) {}
    var best = null;
    var bestScore = 19;
    var limit = Math.min(nodes.length, 250);
    for (var i = 0; i < limit; i++) {
      var score = fieldScore(nodes[i]);
      if (score > bestScore) {
        best = nodes[i];
        bestScore = score;
      }
    }
    if (!best) return false;
    try {
      best.disabled = false;
      best.readOnly = false;
      best.removeAttribute('disabled');
      best.removeAttribute('readonly');
      setNativeValue(best, text);
      try { best.focus(); } catch (_) {}
      try { best.dispatchEvent(new Event('input', { bubbles: true })); } catch (_) {}
      try { best.dispatchEvent(new Event('change', { bubbles: true })); } catch (_) {}
      return true;
    } catch (_) {
      return false;
    }
  }

  function dispatchFallbackEvents(text) {
    var detail = decodedResult(text);
    var names = ['scanSuccess', 'qr-scanned', 'barcode-scanned'];
    var count = 0;
    for (var i = 0; i < names.length; i++) {
      try {
        document.dispatchEvent(new CustomEvent(names[i], { bubbles: true, detail: detail }));
        count++;
      } catch (_) {}
    }
    return count;
  }

  function processOne(item) {
    patch();
    var captured = invokeLatestCaptured(item.text);
    var named = '';
    var input = false;
    var events = 0;

    if (!captured.called) named = invokeOneNamed(item.text);
    if (!captured.called && !named) input = fillBestInput(item.text);
    if (!captured.called && !named && !input) events = dispatchFallbackEvents(item.text);

    var ok = !!(captured.called || named || input);
    var result = {
      ok: ok,
      callbacks: captured.called,
      source: captured.source,
      named: named,
      inputs: input ? 1 : 0,
      events: events,
      errors: captured.errors,
      captured: callbacks.length,
      queued: queue.length,
      sources: callbackSources(),
      requestId: item.requestId || '',
      text: item.text,
      reason: ok ? '' : 'scanner_not_ready'
    };

    if (captured.called) report('Kode terkirim ke scanner aktif.');
    else if (named) report('Kode terkirim lewat ' + named + '.');
    else if (input) report('Kode diisi ke kolom barcode/HU.');
    else report('Scanner belum siap. Buka ulang menu Scan QR.');

    androidCall('onSendReport', [JSON.stringify(result)]);
  }

  function processQueue() {
    if (processing || destroyed) return;
    processing = true;

    function next() {
      if (destroyed || !queue.length) {
        processing = false;
        return;
      }
      var item = queue.shift();
      try { processOne(item); } catch (_) {}
      w.setTimeout(next, SEND_GAP_MS);
    }

    next();
  }

  function send(text, requestId) {
    text = String(text == null ? '' : text).trim();
    if (!text) {
      report('Kode masih kosong.');
      return JSON.stringify({ ok: false, reason: 'empty' });
    }

    var stamp = now();
    if (recent[text] && stamp - recent[text] < DUPLICATE_MS) {
      report('Kode sama baru saja diproses.');
      return JSON.stringify({ ok: false, reason: 'duplicate' });
    }
    recent[text] = stamp;
    cleanupRecent();

    if (queue.length >= MAX_QUEUE) {
      report('Antrean scan penuh. Tunggu sebentar.');
      return JSON.stringify({ ok: false, reason: 'queue_full', queued: queue.length });
    }

    queue.push({ text: text, addedAt: stamp, requestId: String(requestId == null ? '' : requestId) });
    processQueue();
    return JSON.stringify({ ok: true, queued: queue.length, processing: processing });
  }

  function status() {
    patch();
    return JSON.stringify({
      version: VERSION,
      callbacks: callbacks.length,
      sources: callbackSources(),
      queued: queue.length,
      processing: processing,
      html5Qrcode: typeof w.Html5Qrcode === 'function',
      html5Scanner: typeof w.Html5QrcodeScanner === 'function',
      universalGreenCheck: true,
      packingCheckedTotal: lastPackingCheckedTotal
    });
  }

  function destroy() {
    destroyed = true;
    clearPatchTimers();
    queue = [];
    callbacks = [];
    try { if (observer) observer.disconnect(); } catch (_) {}
    observer = null;
    reportCount(true);
  }

  w.__LPWScannerBridge = {
    version: VERSION,
    patch: patch,
    send: send,
    status: status,
    checkGreenColumns: checkGreenColumnsManual,
    checkPackingPassed: checkGreenColumnsManual,
    report: report,
    destroy: destroy,
    getCallbackCount: function () { return callbacks.length; }
  };

  try {
    document.addEventListener('visibilitychange', function () {
      if (!document.hidden) schedulePatch();
    }, false);
    w.addEventListener('pageshow', schedulePatch, false);
    w.addEventListener('pagehide', function () {
      clearPatchTimers();
      queue = [];
    }, false);
  } catch (_) {}

  patch();
  installObserver();
  schedulePatch();
  report('Tools stabil siap. Buka menu Scan QR lalu kirim kode.');
})();



;(function(){
'use strict';
var w=window;
if(w.__ICEToolsV30){try{w.__ICEToolsV30.rescan();}catch(e){} return;}
var T={
  version:'30.7-material-cell-picker',
  requests:[], logs:[], qrs:[], hus:[],
  qrRe:/\bMPA-[A-Z0-9._:/-]{3,}\b/gi,
  huKeyRe:/^(hu|hu[_\s-]?code|hu[_\s-]?no|hu[_\s-]?number|handling[_\s-]?unit|handling[_\s-]?unit[_\s-]?(code|no|number))$/i,
  huCtxRe:/\b(hu|handling\s*unit)\b/i,
  esc:function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});},
  uniq:function(a){var o={},r=[];for(var i=0;i<a.length;i++){var k=String(a[i]);if(!o[k]){o[k]=1;r.push(a[i]);}}return r;},
  addQr:function(code,source,context){code=String(code||'').toUpperCase();if(!code)return;for(var i=0;i<this.qrs.length;i++){var x=this.qrs[i];if(x.code===code&&x.source===source&&x.context===context)return;}this.qrs.push({code:code,source:source||'',context:context||''});},
  addHu:function(value,source,context,key){value=String(value||'').trim();if(!value)return;for(var i=0;i<this.hus.length;i++){var x=this.hus[i];if(x.value===value&&x.source===source&&x.context===context)return;}this.hus.push({value:value,source:source||'',context:context||'',key:key||''});},
  scanText:function(txt,source,context){txt=String(txt==null?'':txt);var m=txt.match(this.qrRe)||[];for(var i=0;i<m.length;i++)this.addQr(m[i],source,context);},
  walk:function(obj,source,path,depth,seen){if(depth>7||obj==null)return;if(typeof obj==='string'){this.scanText(obj,source,path);return;}if(typeof obj!=='object')return;seen=seen||[];if(seen.indexOf(obj)>=0)return;seen.push(obj);if(Array.isArray(obj)){for(var i=0;i<obj.length&&i<800;i++)this.walk(obj[i],source,path+'['+i+']',depth+1,seen);return;}var keys=[];try{keys=Object.keys(obj);}catch(e){}for(var j=0;j<keys.length&&j<1500;j++){var k=keys[j],v;try{v=obj[k];}catch(e){continue;}var p=path+'.'+k;if(this.huKeyRe.test(k)){var val='';try{val=typeof v==='string'?v:JSON.stringify(v);}catch(e){val=String(v);}if(val&&val!=='[object Object]')this.addHu(val,source,p,k);}if(typeof v==='string')this.scanText(v,source,p);this.walk(v,source,p,depth+1,seen);}},
  scanStorage:function(){var self=this;function one(st,name){try{for(var i=0;i<st.length;i++){var k=st.key(i),v=st.getItem(k)||'';if(self.huKeyRe.test(k)||self.huCtxRe.test(k))self.addHu(v,name,k,k);self.scanText(v,name,k);try{self.walk(JSON.parse(v),name+'-json',k,0,[]);}catch(e){}}}catch(e){}}one(localStorage,'localStorage');one(sessionStorage,'sessionStorage');},
  scanDom:function(){var self=this,els=[];try{els=[].slice.call(document.querySelectorAll('*'),0,25000);}catch(e){}for(var i=0;i<els.length;i++){var el=els[i];try{var tag=(el.tagName||'').toLowerCase(),id=el.id||'',name=el.getAttribute('name')||'',aria=el.getAttribute('aria-label')||'',ph=el.getAttribute('placeholder')||'',title=el.getAttribute('title')||'';var labels=[id,name,aria,ph,title].join(' ');var value='';if(typeof el.value==='string')value=el.value;if(!value)value=(el.textContent||'').trim();var explicit=self.huKeyRe.test(id)||self.huKeyRe.test(name)||self.huCtxRe.test(labels);var labelText='';if(id){try{var lb=document.querySelector('label[for="'+CSS.escape(id)+'"]');if(lb)labelText=(lb.textContent||'').trim();}catch(e){}}if((explicit||self.huCtxRe.test(labelText))&&value&&value.length<200)self.addHu(value,'dom',tag+'#'+id+'['+name+']',labels||labelText);var attrs='';try{attrs=[].map.call(el.attributes,function(a){return a.name+'='+a.value;}).join(' ');}catch(e){}self.scanText(attrs,'dom-attr',tag+'#'+id);if(value&&value.length<5000)self.scanText(value,'dom-value',tag+'#'+id);}catch(e){}}try{self.scanText(document.documentElement.outerHTML.slice(0,1800000),'dom-html',location.href);}catch(e){}try{var scripts=[].slice.call(document.scripts);for(var s=0;s<scripts.length;s++){var tx=(scripts[s].textContent||'').slice(0,250000);self.scanText(tx,'script','script['+s+']');var rx=/["']?(hu|hu[_-]?code|hu[_-]?no|handling[_-]?unit(?:[_-]?(?:code|no|number))?)["']?\s*[:=]\s*["']([^"']+)["']/gi,mm;while((mm=rx.exec(tx)))self.addHu(mm[2],'script','script['+s+']',mm[1]);}}catch(e){}self.scanStorage();},
  rescan:function(){this.scanDom();},
  copy:function(t){t=String(t||'');try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t);return;}}catch(e){}try{var a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();}catch(e){}},
  hookNet:function(){if(this.netHooked)return;this.netHooked=true;var self=this;if(w.fetch){var of=w.fetch.bind(w);w.fetch=function(){var args=arguments,url='';try{url=typeof args[0]==='string'?args[0]:args[0].url||'';}catch(e){}return of.apply(w,args).then(function(res){try{res.clone().text().then(function(body){self.requests.push({type:'fetch',url:url,status:res.status,body:String(body).slice(0,80000)});if(self.requests.length>300)self.requests.shift();self.scanText(body,'fetch',url);try{self.walk(JSON.parse(body),'fetch-json',url,0,[]);}catch(e){}});}catch(e){}return res;});};}
    try{var xo=XMLHttpRequest.prototype.open,xs=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this.__iceNet={m:m,u:String(u||'')};return xo.apply(this,arguments);};XMLHttpRequest.prototype.send=function(){this.addEventListener('loadend',function(){var b='';try{b=this.responseType==='json'?JSON.stringify(this.response):this.responseText||'';}catch(e){}var meta=this.__iceNet||{};self.requests.push({type:'xhr',url:meta.u||'',status:this.status,body:String(b).slice(0,80000)});if(self.requests.length>300)self.requests.shift();self.scanText(b,'xhr',meta.u||'');try{self.walk(JSON.parse(b),'xhr-json',meta.u||'',0,[]);}catch(e){}});return xs.apply(this,arguments);};}catch(e){}},

  getHeaderRecords:function(){
    var self=this, out=[], seen={};

    function primitives(obj,prefix,res,depth){
      if(depth>5||obj==null)return;
      if(Array.isArray(obj)){
        for(var i=0;i<obj.length&&i<100;i++)primitives(obj[i],prefix+'['+i+']',res,depth+1);
        return;
      }
      if(typeof obj==='object'){
        Object.keys(obj).slice(0,200).forEach(function(k){
          var v;try{v=obj[k];}catch(e){return;}
          var p=prefix?prefix+'.'+k:k;
          if(v==null)return;
          if(typeof v==='string'||typeof v==='number'||typeof v==='boolean'){
            var s=String(v).trim();
            if(s&&s.length<500)res.push({key:k,path:p,value:s});
          }else primitives(v,p,res,depth+1);
        });
      }
    }

    function scan(obj,path,reqUrl,depth){
      if(depth>8||obj==null)return;
      if(Array.isArray(obj)){
        for(var i=0;i<obj.length&&i<1000;i++)scan(obj[i],path+'['+i+']',reqUrl,depth+1);
        return;
      }
      if(typeof obj!=='object')return;

      Object.keys(obj).slice(0,500).forEach(function(k){
        var v;try{v=obj[k];}catch(e){return;}
        var p=path?path+'.'+k:k;

        if(Array.isArray(v)&&/^header$/i.test(k)){
          for(var i=0;i<v.length;i++){
            var rec=v[i];
            if(!rec||typeof rec!=='object')continue;
            var hu='';
            Object.keys(rec).some(function(rk){
              if(/^(hu|hu[_\s-]?code|hu[_\s-]?no|hu[_\s-]?number|handling[_\s-]?unit(?:[_\s-]?(?:code|no|number))?)$/i.test(rk)){
                var rv=rec[rk];
                if(rv!=null&&typeof rv!=='object'){hu=String(rv).trim();return true;}
              }
              return false;
            });
            if(!hu)continue;

            var fields=[];primitives(rec,'header['+i+']',fields,0);
            var qrs=[];
            fields.forEach(function(f){
              var ms=f.value.match(/\bMPA[\s:_-]*[A-Z0-9][A-Z0-9._:/-]{2,}\b/gi)||[];
              ms.forEach(function(q){
                q=q.replace(/^MPA[\s:_-]*/i,'MPA-').replace(/\s+/g,'').toUpperCase();
                if(qrs.indexOf(q)<0)qrs.push(q);
              });
            });

            var sig=reqUrl+'|'+i+'|'+hu;
            if(!seen[sig]){
              seen[sig]=1;
              out.push({index:i,hu:hu,path:p+'['+i+']',url:reqUrl||'',record:rec,fields:fields,qrs:qrs});
            }
          }
        }
        scan(v,p,reqUrl,depth+1);
      });
    }

    // Prioritaskan response API terbaru agar record yang tampil adalah dataset terakhir.
    for(var ri=this.requests.length-1;ri>=0;ri--){
      var r=this.requests[ri], obj=null;
      if(!r||!r.body)continue;
      try{obj=JSON.parse(r.body);}catch(e){continue;}
      scan(obj,'',r.url||'',0);
      if(out.length)break;
    }

    return out.sort(function(a,b){return a.index-b.index;});
  },

  matchVisibleRow:function(rec){
    var rows=[].slice.call(document.querySelectorAll('table tbody tr'));
    if(!rows.length)return null;

    var vals=(rec.fields||[]).map(function(f){return String(f.value||'').trim();})
      .filter(function(v){
        return v.length>=2 && v.length<=120 && v!==rec.hu && !/^(true|false|null)$/i.test(v);
      });

    var best=null;
    rows.forEach(function(row,idx){
      var text=(row.innerText||row.textContent||'').replace(/\s+/g,' ').trim();
      var low=text.toLowerCase(), score=0, hits=[];
      vals.forEach(function(v){
        var x=v.toLowerCase();
        if(x.length>=3&&low.indexOf(x)>=0){score+=Math.min(5,Math.max(1,Math.floor(x.length/4)));hits.push(v);}
      });
      if(!best||score>best.score)best={row:row,index:idx,text:text,score:score,hits:hits};
    });
    return best&&best.score>0?best:null;
  },

  recordDisplayFields:function(rec){
    var skip=/^(hu|id|createdby|updatedby)$/i;
    var arr=[],seen={};
    (rec.fields||[]).forEach(function(f){
      var key=String(f.key||'');
      var val=String(f.value||'').trim();
      if(!val||val===rec.hu||/^MPA-/i.test(val))return;
      var s=key+'|'+val;if(seen[s])return;seen[s]=1;

      var priority=0;
      if(/desc|description|style|article|material|product|model|item|code/i.test(key))priority+=8;
      if(/size/i.test(key))priority+=7;
      if(/status/i.test(key))priority+=6;
      if(/color|colour/i.test(key))priority+=5;
      if(/defect|reject/i.test(key))priority+=4;
      if(skip.test(key))priority-=5;
      arr.push({key:key,value:val,priority:priority});
    });
    arr.sort(function(a,b){return b.priority-a.priority;});
    return arr.slice(0,10);
  },

  renderHiddenHuRecords:function(query){
    var p=this.ensurePanel(), body=p.querySelector('.b'), self=this;
    var records=this.getHeaderRecords();
    var q=String(query||'').trim().toLowerCase();

    var filtered=records.filter(function(rec){
      if(!q)return true;
      var hay=[rec.hu,rec.path,rec.url]
        .concat((rec.fields||[]).map(function(f){return f.key+' '+f.value;}))
        .concat(rec.qrs||[]).join(' ').toLowerCase();
      return hay.indexOf(q)>=0;
    });

    var top='<div class=c>'+
      '<input id=__ice_hu_filter style="width:100%;box-sizing:border-box;padding:10px;background:#020617;color:#fff;border:1px solid #475569;border-radius:8px" placeholder="Filter HU / description / size / status / QR..." value="'+this.esc(query||'')+'">'+
      '<div class=m style="margin-top:6px">Record API: '+records.length+' • Ditampilkan: '+filtered.length+'. Urutan memakai header[index] dari response API, bukan menebak dari kode yang terlihat.</div>'+
      '</div>';

    var html=top;

    if(!records.length){
      html+='<div class=c><b>Record header belum tertangkap.</b><div class=m>Refresh halaman lalu buka Hidden HU Finder lagi. QR Hunter/Network harus aktif sebelum response masuk.</div></div>';
    }

    filtered.forEach(function(rec){
      var match=self.matchVisibleRow(rec);
      var fields=self.recordDisplayFields(rec);
      html+='<div class=c>'+
        '<div class=m><b>API ROW '+(rec.index+1)+'</b> • '+self.esc(rec.path)+'</div>'+
        '<div style="font-size:19px;font-weight:700;margin:5px 0">'+self.esc(rec.hu)+'</div>';

      if(fields.length){
        html+='<div style="margin:7px 0">';
        fields.forEach(function(f){
          html+='<div><span class=m>'+self.esc(f.key)+':</span> <b>'+self.esc(f.value)+'</b></div>';
        });
        html+='</div>';
      }

      if(rec.qrs&&rec.qrs.length){
        html+='<div style="margin:7px 0"><div class=m>Split QR dari object yang sama:</div>';
        rec.qrs.forEach(function(qr){
          html+='<div><code>'+self.esc(qr)+'</code> <button onclick="window.__ICEToolsV30.copy(\''+self.esc(qr)+'\')">Copy QR</button></div>';
        });
        html+='</div>';
      }else{
        html+='<div class=m style="margin:7px 0">Split QR belum ditemukan di object header ini.</div>';
      }

      if(match){
        html+='<div style="margin-top:8px;padding:7px;border:1px solid #475569;border-radius:8px">'+
          '<div class=m>🎯 Kandidat baris tabel: <b>Baris '+(match.index+1)+'</b> • score '+match.score+'</div>'+
          '<div>'+self.esc(match.text)+'</div>'+
          (match.hits.length?'<div class=m>Match: '+self.esc(match.hits.slice(0,5).join(' • '))+'</div>':'')+
          '</div>';
      }else{
        html+='<div class=m style="margin-top:7px">Belum bisa mencocokkan record ini ke baris tabel yang sedang terlihat.</div>';
      }

      html+='<div style="margin-top:7px">'+
        '<button onclick="window.__ICEToolsV30.copy(\''+self.esc(rec.hu)+'\')">Copy HU</button>'+
        '<button onclick="window.__ICEToolsV30.showRecordJson('+rec.index+')">Lihat JSON Record</button>'+
        '</div>'+
        '<div class=m>'+self.esc(rec.url)+'</div>'+
        '</div>';
    });

    body.innerHTML=html;
    var inp=document.getElementById('__ice_hu_filter');
    if(inp){
      inp.oninput=function(){
        clearTimeout(self.__huFilterTimer);
        var val=this.value;
        self.__huFilterTimer=setTimeout(function(){self.renderHiddenHuRecords(val);},120);
      };
      try{inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length);}catch(e){}
    }
  },

  showRecordJson:function(index){
    var records=this.getHeaderRecords(), rec=null;
    for(var i=0;i<records.length;i++)if(records[i].index===index){rec=records[i];break;}
    if(!rec){this.show('Record JSON','<div class=c>Record tidak ditemukan.</div>');return;}
    this.show('Record JSON • header['+index+']',
      '<div class=c><b>HU '+this.esc(rec.hu)+'</b>'+
      '<button onclick="window.__ICEToolsV30.copy(JSON.stringify(window.__ICEToolsV30.getHeaderRecords().filter(function(x){return x.index=='+index+';})[0].record,null,2))">Copy JSON</button>'+
      '<pre>'+this.esc(JSON.stringify(rec.record,null,2))+'</pre></div>');
  },


  findRecordArrays:function(obj,path,out,depth){
    out=out||[];depth=depth||0;if(depth>5||obj==null||typeof obj!=='object')return out;
    if(Array.isArray(obj)){
      if(obj.length && obj.some(function(x){return x&&typeof x==='object'&&!Array.isArray(x);})){
        out.push({path:path||'root',items:obj});
      }
      for(var i=0;i<obj.length&&i<40;i++)this.findRecordArrays(obj[i],(path||'root')+'['+i+']',out,depth+1);
      return out;
    }
    var ks=[];try{ks=Object.keys(obj);}catch(e){}
    for(var j=0;j<ks.length&&j<200;j++){
      var k=ks[j],v;try{v=obj[k];}catch(e){continue;}
      if(v&&typeof v==='object')this.findRecordArrays(v,(path?path+'.':'')+k,out,depth+1);
    }
    return out;
  },
  recordHu:function(rec){
    if(!rec||typeof rec!=='object')return '';
    var ks=[];try{ks=Object.keys(rec);}catch(e){}
    for(var i=0;i<ks.length;i++){
      var k=ks[i];
      if(this.huKeyRe.test(k)){
        var v=rec[k]; if(v!=null && typeof v!=='object') return String(v).trim();
      }
    }
    return '';
  },
  recordQrs:function(rec){
    var found=[],self=this;
    function walk(v,d){
      if(d>6||v==null)return;
      if(typeof v==='string'){
        var m=v.match(self.qrRe)||[];
        for(var i=0;i<m.length;i++)found.push(String(m[i]).toUpperCase());
        return;
      }
      if(typeof v!=='object')return;
      if(Array.isArray(v)){for(var a=0;a<v.length&&a<100;a++)walk(v[a],d+1);return;}
      var ks=[];try{ks=Object.keys(v);}catch(e){}
      for(var j=0;j<ks.length&&j<300;j++){try{walk(v[ks[j]],d+1);}catch(e){}}
    }
    walk(rec,0);return this.uniq(found);
  },
  recordSummary:function(rec){
    var out=[],preferred=/description|desc|article|style|material|product|item|size|status|defect|color|colour|order|sku/i;
    if(!rec||typeof rec!=='object')return out;
    var ks=[];try{ks=Object.keys(rec);}catch(e){}
    for(var pass=0;pass<2;pass++){
      for(var i=0;i<ks.length;i++){
        var k=ks[i],v=rec[k];
        if(v==null||typeof v==='object')continue;
        var s=String(v).trim();if(!s||s.length>180)continue;
        if(this.huKeyRe.test(k)||this.qrRe.test(s))continue;
        if((pass===0&&!preferred.test(k))||(pass===1&&preferred.test(k)))continue;
        out.push({k:k,v:s});
        if(out.length>=8)return out;
      }
    }
    return out;
  },
  latestRecordSet:function(){
    var best=null;
    for(var i=this.requests.length-1;i>=0;i--){
      var r=this.requests[i],obj=null;
      try{obj=JSON.parse(r.body);}catch(e){continue;}
      var arrays=this.findRecordArrays(obj,'',[],0);
      for(var j=0;j<arrays.length;j++){
        var a=arrays[j],huCount=0;
        for(var x=0;x<a.items.length;x++)if(this.recordHu(a.items[x]))huCount++;
        if(huCount){
          var score=huCount*100 + a.items.length;
          if(/header/i.test(a.path))score+=10000;
          if(!best||score>best.score)best={score:score,path:a.path,items:a.items,url:r.url,type:r.type};
        }
      }
      if(best && /header/i.test(best.path))break;
    }
    return best;
  },
  visibleTableRows:function(){
    var rows=[];try{
      var trs=[].slice.call(document.querySelectorAll('tbody tr'));
      for(var i=0;i<trs.length;i++){
        var txt=(trs[i].innerText||trs[i].textContent||'').replace(/\s+/g,' ').trim();
        if(txt)rows.push({index:i+1,text:txt,el:trs[i]});
      }
    }catch(e){}
    return rows;
  },
  matchRecordRow:function(rec,rows){
    if(!rows||!rows.length)return null;
    var vals=[],ks=[];try{ks=Object.keys(rec||{});}catch(e){}
    for(var i=0;i<ks.length;i++){
      var k=ks[i],v=rec[k];
      if(v==null||typeof v==='object'||this.huKeyRe.test(k))continue;
      var s=String(v).replace(/\s+/g,' ').trim();
      if(s.length>=2&&s.length<=120)vals.push(s.toLowerCase());
    }
    var best=null;
    for(var r=0;r<rows.length;r++){
      var rt=rows[r].text.toLowerCase(),score=0,hits=[];
      for(var j=0;j<vals.length;j++){
        if(rt.indexOf(vals[j])>=0){score+=Math.min(20,vals[j].length);hits.push(vals[j]);}
      }
      if(!best||score>best.score)best={row:rows[r],score:score,hits:hits};
    }
    return best&&best.score>=4?best:null;
  },
  correlate:function(){var out=[];for(var i=0;i<this.hus.length;i++){var h=this.hus[i],qs=[];for(var j=0;j<this.qrs.length;j++){var q=this.qrs[j];if(q.source===h.source&&q.context===h.context)qs.push(q.code);else if(q.context&&h.context&&(q.context.indexOf(h.context)>=0||h.context.indexOf(q.context)>=0))qs.push(q.code);}out.push({hu:h.value,source:h.source,context:h.context,qrs:this.uniq(qs)});}return out;},
  ensurePanel:function(){var p=document.getElementById('__ice_v30_panel');if(p)return p;var st=document.createElement('style');st.textContent='#__ice_v30_panel{position:fixed;inset:3%;z-index:2147483647;background:#0f172a;color:#fff;border-radius:16px;box-shadow:0 0 0 9999px rgba(0,0,0,.65);font:13px system-ui,sans-serif;overflow:hidden}#__ice_v30_panel .h{height:48px;display:flex;align-items:center;padding:0 12px;background:#111827;border-bottom:1px solid #334155}#__ice_v30_panel .h b{flex:1}#__ice_v30_panel button{border:0;border-radius:9px;background:#334155;color:#fff;padding:8px 10px;margin:3px}#__ice_v30_panel .b{height:calc(100% - 48px);overflow:auto;padding:10px}#__ice_v30_panel .c{background:#111827;border:1px solid #334155;border-radius:10px;padding:9px;margin-bottom:8px;word-break:break-word}#__ice_v30_panel .m{color:#94a3b8;font-size:12px}#__ice_v30_panel pre{white-space:pre-wrap;word-break:break-all;background:#020617;padding:8px;border-radius:8px}';document.documentElement.appendChild(st);p=document.createElement('div');p.id='__ice_v30_panel';p.innerHTML='<div class=h><b>ICE Tools</b><button id=__ice_close>✕</button></div><div class=b></div>';document.documentElement.appendChild(p);p.querySelector('#__ice_close').onclick=function(){p.remove();};return p;},
  show:function(title,html){var p=this.ensurePanel();p.querySelector('.h b').textContent=title;p.querySelector('.b').innerHTML=html;},
  inspector:function(){this.rescan();var d=this.correlate(),html='';if(!d.length)html='<div class=c><b>HU asli belum ditemukan.</b><div class=m>ICE tidak menganggap kode Record/Item sebagai HU.</div></div>';for(var i=0;i<d.length;i++){var x=d[i];html+='<div class=c><div class=m>HU • '+this.esc(x.source)+'</div><b>'+this.esc(x.hu)+'</b><div class=m>'+this.esc(x.context)+'</div>';if(x.qrs.length){for(var j=0;j<x.qrs.length;j++)html+='<div><code>'+this.esc(x.qrs[j])+'</code> <button onclick="window.__ICEToolsV30.copy(\''+this.esc(x.qrs[j])+'\')">Copy</button></div>';}else html+='<div class=m>Split QR belum dapat dipastikan untuk HU ini.</div>';html+='</div>';}this.show('HU Inspector',html);},


  buildOrderedRecords:function(){
    var set=this.latestRecordSet();
    if(!set)return {set:null,items:[]};

    var rows=this.visibleTableRows(), candidates=[];
    for(var i=0;i<set.items.length;i++){
      var rec=set.items[i],hu=this.recordHu(rec);
      if(!hu)continue;
      candidates.push({
        apiIndex:i,
        hu:hu,
        qrs:this.recordQrs(rec),
        sum:this.recordSummary(rec),
        rec:rec,
        used:false
      });
    }

    // Cocokkan dari BARIS TABEL 1 -> N.
    // Setiap record API hanya boleh dipakai sekali.
    var ordered=[];
    for(var r=0;r<rows.length;r++){
      var row=rows[r], best=null;

      for(var c=0;c<candidates.length;c++){
        var x=candidates[c];
        if(x.used)continue;

        var vals=[],ks=[];
        try{ks=Object.keys(x.rec||{});}catch(e){}
        for(var k=0;k<ks.length;k++){
          var key=ks[k],v=x.rec[key];
          if(v==null||typeof v==='object'||this.huKeyRe.test(key))continue;
          var s=String(v).replace(/\s+/g,' ').trim();
          if(s.length>=2&&s.length<=160)vals.push({k:key,v:s.toLowerCase()});
        }

        var rt=row.text.toLowerCase(),score=0,hits=[];
        for(var j=0;j<vals.length;j++){
          if(rt.indexOf(vals[j].v)>=0){
            var add=Math.min(30,vals[j].v.length);
            // Bobot lebih tinggi untuk field penting
            if(/size/i.test(vals[j].k))add+=25;
            if(/matdesc|description|desc|style|article|material|product|item/i.test(vals[j].k))add+=35;
            if(/status/i.test(vals[j].k))add+=10;
            score+=add;
            hits.push(vals[j].k+':'+vals[j].v);
          }
        }

        // Penalti kecil bila record tidak punya kecocokan field penting
        var hasImportant=hits.some(function(h){return /size:|matdesc:|description:|desc:|style:|article:|material:|product:|item:/i.test(h);});
        if(!hasImportant)score-=20;

        if(!best||score>best.score)best={cand:x,score:score,hits:hits};
      }

      if(best && best.score>=4){
        best.cand.used=true;
        ordered.push({
          tableRow:row.index,
          rowText:row.text,
          score:best.score,
          hits:best.hits,
          apiIndex:best.cand.apiIndex,
          hu:best.cand.hu,
          qrs:best.cand.qrs,
          sum:best.cand.sum,
          rec:best.cand.rec,
          exact:best.score>=70
        });
      }else{
        ordered.push({
          tableRow:row.index,
          rowText:row.text,
          score:0,
          hits:[],
          apiIndex:-1,
          hu:'',
          qrs:[],
          sum:[],
          rec:null,
          exact:false
        });
      }
    }

    // Kalau ada record API sisa yang tak punya baris tabel, taruh di bawah.
    for(var z=0;z<candidates.length;z++){
      var rem=candidates[z];
      if(!rem.used){
        ordered.push({
          tableRow:null,
          rowText:'',
          score:0,
          hits:[],
          apiIndex:rem.apiIndex,
          hu:rem.hu,
          qrs:rem.qrs,
          sum:rem.sum,
          rec:rem.rec,
          exact:false,
          orphan:true
        });
      }
    }

    return {set:set,items:ordered};
  },


  hiddenHu:function(){
    this.rescan();
    var data=this.buildOrderedRecords(),set=data.set,recs=data.items,html='';

    if(!set){
      html='<div class=c><b>Record/header API belum tertangkap.</b><div class=m>Buka/refresh halaman lalu coba lagi.</div></div>';
      this.show('Hidden HU Finder • Pilih Baris',html);
      return;
    }

    var tableRows=[];
    for(var ri=0;ri<recs.length;ri++){
      if(recs[ri].tableRow!=null)tableRows.push(recs[ri].tableRow);
    }
    tableRows=this.uniq(tableRows).sort(function(a,b){return a-b;});

    html+='<div class=c><b>Pilih HU / Baris yang ingin ditampilkan</b>'+
      '<div class=m>Mode ini bisa menampilkan SEMUA atau hanya 1 baris/HU yang kamu pilih.</div>'+
      '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">'+
        '<button id=__ice_pick_from_table>🎯 Pilih dari tabel</button>'+
        '<button id=__ice_show_all>Semua</button>'+
        '<button id=__ice_prev_row>◀</button>'+
        '<button id=__ice_next_row>▶</button>'+
      '</div>'+
      '<select id=__ice_row_select style="width:100%;box-sizing:border-box;padding:9px;border-radius:8px;border:1px solid #475569;background:#020617;color:#fff;margin-top:8px">'+
        '<option value="">-- Tampilkan semua baris --</option>'+
        tableRows.map(function(n){return '<option value="'+n+'">BARIS '+n+'</option>';}).join('')+
      '</select>'+
      '<input id=__ice_rec_filter placeholder="Cari HU / description / size / status / QR..." style="width:100%;box-sizing:border-box;padding:9px;border-radius:8px;border:1px solid #475569;background:#020617;color:#fff;margin-top:8px">'+
      '<div class=m style="margin-top:6px">API: '+this.esc(set.path)+' • '+this.esc(set.type)+' • '+this.esc(set.url)+'</div></div>'+
      '<div id=__ice_rec_list></div>';

    this.show('Hidden HU Finder • Pilih Baris',html);

    var self=this,p=document.getElementById('__ice_v30_panel'),
        list=p&&p.querySelector('#__ice_rec_list'),
        inp=p&&p.querySelector('#__ice_rec_filter'),
        sel=p&&p.querySelector('#__ice_row_select');

    if(typeof this.huSelectedTableRow==='undefined')this.huSelectedTableRow=null;
    if(sel && this.huSelectedTableRow!=null)sel.value=String(this.huSelectedTableRow);

    function confidence(x){
      if(x.orphan)return '<span style="color:#fca5a5">Record API tidak punya pasangan baris</span>';
      if(!x.hu)return '<span style="color:#fca5a5">⚠ Belum ditemukan pasangan HU</span>';
      if(x.exact)return '<span style="color:#86efac">✓ Cocok kuat</span>';
      if(x.score>=30)return '<span style="color:#fde68a">≈ Cocok sedang</span>';
      return '<span style="color:#fca5a5">⚠ Cocok rendah</span>';
    }

    function card(x,idx){
      var h='<div class=c>';
      if(x.tableRow!=null){
        h+='<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">'+
           '<div style="font-size:18px;font-weight:800;flex:1">BARIS '+x.tableRow+'</div>'+
           '<button data-only="'+x.tableRow+'">Tampilkan ini saja</button></div>'+
           '<div class=m>'+self.esc(x.rowText)+'</div>';
      }else{
        h+='<div style="font-size:18px;font-weight:800;color:#fca5a5">RECORD API SISA</div>';
      }

      h+='<div class=m style="margin-top:7px">'+confidence(x)+' • score '+x.score+
         (x.apiIndex>=0?' • API record ['+x.apiIndex+']':'')+'</div>';

      if(x.hu){
        h+='<div style="margin-top:8px"><span class=m>HU:</span> <b style="font-size:17px">'+self.esc(x.hu)+'</b></div>';
      }

      if(x.sum&&x.sum.length){
        h+='<div style="margin-top:7px">';
        for(var a=0;a<x.sum.length;a++){
          h+='<div><span class=m>'+self.esc(x.sum[a].k)+':</span> '+self.esc(x.sum[a].v)+'</div>';
        }
        h+='</div>';
      }

      if(x.qrs&&x.qrs.length){
        h+='<div style="margin-top:9px"><b>Split QR:</b>';
        for(var b=0;b<x.qrs.length;b++){
          h+='<div style="margin-top:4px"><code>'+self.esc(x.qrs[b])+'</code> '+
             '<button onclick="window.__ICEToolsV30.copy(\''+self.esc(x.qrs[b])+'\')">Copy QR</button></div>';
        }
        h+='</div>';
      }else if(x.hu){
        h+='<div class=m style="margin-top:8px">Split QR belum ditemukan di record ini.</div>';
      }

      if(x.hu)h+='<button onclick="window.__ICEToolsV30.copy(\''+self.esc(x.hu)+'\')">Copy HU</button>';
      if(x.rec)h+='<button data-json="'+idx+'">Lihat JSON record</button>';
      h+='</div>';
      return h;
    }

    function filtered(){
      var q=(inp&&inp.value||'').toLowerCase().trim(),arr=[];
      for(var i=0;i<recs.length;i++){
        var x=recs[i];

        // Jika user memilih BARIS, hanya baris tersebut yang ditampilkan.
        if(self.huSelectedTableRow!=null && x.tableRow!==self.huSelectedTableRow)continue;

        if(q){
          var search=[];
          if(x.tableRow!=null)search.push('baris '+x.tableRow,String(x.tableRow));
          search.push(x.hu||'',x.rowText||'');
          for(var s=0;s<(x.sum||[]).length;s++)search.push(x.sum[s].k+' '+x.sum[s].v);
          for(var z=0;z<(x.qrs||[]).length;z++)search.push(x.qrs[z]);
          if(search.join(' ').toLowerCase().indexOf(q)<0)continue;
        }
        arr.push({x:x,i:i});
      }
      return arr;
    }

    function draw(){
      if(!list)return;
      var arr=filtered(),h='';

      if(self.huSelectedTableRow!=null){
        h+='<div class=c style="border-color:#3b82f6"><b>Mode 1 Baris</b><div class=m>Hanya BARIS '+self.huSelectedTableRow+' yang ditampilkan.</div><button id=__ice_reset_single>✕ Tampilkan semua lagi</button></div>';
        if(self.huSelectedPickedText){
          h+='<div class=c style="border-color:#38bdf8"><b>Bagian yang kamu pilih</b><div class=m>'+self.esc(self.huSelectedPickedText)+'</div><div class=m>Deteksi: '+self.esc(self.huSelectedPickSource||'')+'</div></div>';
        }
        if(self.huSelectedDetailText || (self.huSelectedDetailFields&&self.huSelectedDetailFields.length)){
          h+='<div class=c style="border-color:#f59e0b"><b>Detail yang kamu tap</b>';
          if(self.huSelectedDetailFields&&self.huSelectedDetailFields.length){
            for(var df=0;df<self.huSelectedDetailFields.length;df++){
              var fld=self.huSelectedDetailFields[df];
              h+='<div style="margin-top:6px"><span class=m>'+self.esc(fld.label)+':</span> <b>'+self.esc(fld.value)+'</b></div>';
            }
          }else{
            h+='<div class=m>'+self.esc(self.huSelectedDetailText)+'</div>';
          }
          h+='</div>';
        }
      }

      for(var i=0;i<arr.length;i++)h+=card(arr[i].x,arr[i].i);
      if(!h)h='<div class=c>Tidak ada record yang cocok dengan pilihan/filter.</div>';
      list.innerHTML=h;

      var reset=list.querySelector('#__ice_reset_single');
      if(reset)reset.onclick=function(){self.huSelectedTableRow=null;self.huSelectedDetailText='';self.huSelectedDetailFields=[];self.huSelectedPickedText='';self.huSelectedPickSource='';self.huSelectedPickedText='';self.huSelectedPickSource='';if(sel)sel.value='';draw();};

      var onlyBtns=list.querySelectorAll('[data-only]');
      for(var oi=0;oi<onlyBtns.length;oi++){
        onlyBtns[oi].onclick=function(){
          self.huSelectedTableRow=parseInt(this.getAttribute('data-only'),10);
          if(sel)sel.value=String(self.huSelectedTableRow);
          draw();
        };
      }

      var bs=list.querySelectorAll('[data-json]');
      for(var bi=0;bi<bs.length;bi++){
        bs[bi].onclick=function(){
          var idx=parseInt(this.getAttribute('data-json'),10),x=recs[idx];
          self.show('BARIS '+(x.tableRow==null?'-':x.tableRow)+' • HU '+(x.hu||'-'),
            '<div class=c><button onclick="window.__ICEToolsV30.hiddenHu()">← Kembali</button>'+
            '<button onclick="window.__ICEToolsV30.copy(JSON.stringify(window.__ICEToolsV30.buildOrderedRecords().items['+idx+'].rec,null,2))">Copy JSON</button>'+
            '<pre>'+self.esc(JSON.stringify(x.rec,null,2))+'</pre></div>');
        };
      }
    }

    if(inp)inp.oninput=draw;

    if(sel)sel.onchange=function(){
      var v=this.value;
      self.huSelectedTableRow=v===''?null:parseInt(v,10);self.huSelectedDetailText='';self.huSelectedDetailFields=[];self.huSelectedPickedText='';self.huSelectedPickSource='';
      draw();
    };

    var all=p&&p.querySelector('#__ice_show_all'),
        prev=p&&p.querySelector('#__ice_prev_row'),
        next=p&&p.querySelector('#__ice_next_row'),
        pick=p&&p.querySelector('#__ice_pick_from_table');

    if(all)all.onclick=function(){
      self.huSelectedTableRow=null;
      self.huSelectedDetailText='';
      self.huSelectedDetailFields=[];
      self.huSelectedPickedText='';self.huSelectedPickSource='';
      if(sel)sel.value='';
      draw();
    };

    function move(delta){
      if(!tableRows.length)return;
      var cur=self.huSelectedTableRow,idx=tableRows.indexOf(cur);
      if(idx<0)idx=(delta>0?-1:0);
      idx+=delta;
      if(idx<0)idx=tableRows.length-1;
      if(idx>=tableRows.length)idx=0;
      self.huSelectedTableRow=tableRows[idx];
      if(sel)sel.value=String(self.huSelectedTableRow);
      draw();
    }
    if(prev)prev.onclick=function(){move(-1);};
    if(next)next.onclick=function(){move(1);};

    if(pick)pick.onclick=function(){self.pickHuRowFromTable();};

    draw();
  },




  pickHuRowFromTable:function(){
    var self=this,p=document.getElementById('__ice_v30_panel');
    if(p)p.remove();

    var rows=this.visibleTableRows();
    var ordered=this.buildOrderedRecords();
    var orderedItems=(ordered&&ordered.items)||[];

    if(!rows.length){
      this.hiddenHu();
      return;
    }

    function norm(s){
      return String(s||'').replace(/\s+/g,' ').trim().toLowerCase();
    }

    function tokenScore(a,b){
      a=norm(a);b=norm(b);
      if(!a||!b)return 0;
      if(a===b)return 1000;
      if(a.indexOf(b)>=0||b.indexOf(a)>=0)return 700+Math.min(a.length,b.length);
      var aa=a.split(' '),bb=b.split(' '),set={};
      for(var i=0;i<aa.length;i++)if(aa[i].length>1)set[aa[i]]=1;
      var score=0;
      for(var j=0;j<bb.length;j++)if(set[bb[j]])score+=Math.min(20,bb[j].length+4);
      return score;
    }

    function findBestOrderedByText(txt){
      var best=null;
      for(var i=0;i<orderedItems.length;i++){
        var x=orderedItems[i];
        if(x.tableRow==null)continue;
        var sc=tokenScore(txt,x.rowText);
        if(!best||sc>best.score)best={row:x.tableRow,score:sc,item:x};
      }
      return best&&best.score>=18?best:null;
    }

    function getRawTr(target){
      try{return target.closest&&target.closest('tr');}catch(e){return null;}
    }

    function getRowFromTarget(target){
      // 1. Cara paling kuat: ambil text dari <tr> yang benar-benar disentuh.
      var tr=getRawTr(target);
      if(tr){
        var trText=(tr.innerText||tr.textContent||'').replace(/\s+/g,' ').trim();

        // Bila row ini sudah diberi nomor picker, pakai langsung.
        if(tr.hasAttribute('data-ice-pick-row')){
          return {row:parseInt(tr.getAttribute('data-ice-pick-row'),10),text:trText,source:'tr-direct'};
        }

        // Kalau responsive/clone row tidak punya nomor, cocokkan isi row ke record terurut.
        var best=findBestOrderedByText(trText);
        if(best)return {row:best.row,text:trText,source:'tr-text-match'};
      }

      // 2. Khusus cell Material Description / Size / Status:
      // naik beberapa parent dan cari container dengan text yang cocok dengan row record.
      var cur=target,depth=0,bestEl=null,bestMatch=null;
      while(cur&&cur!==document.body&&depth<8){
        var tx=(cur.innerText||cur.textContent||'').replace(/\s+/g,' ').trim();
        if(tx && tx.length>=3 && tx.length<=600){
          var bm=findBestOrderedByText(tx);
          if(bm && (!bestMatch||bm.score>bestMatch.score)){
            bestMatch=bm;bestEl=cur;
          }
        }
        cur=cur.parentElement;depth++;
      }
      if(bestMatch)return {row:bestMatch.row,text:(bestEl.innerText||bestEl.textContent||'').replace(/\s+/g,' ').trim(),source:'parent-text-match'};

      // 3. Geometry fallback.
      var er;try{er=target.getBoundingClientRect();}catch(e){er=null;}
      if(er){
        var mid=(er.top+er.bottom)/2,best=null,dist=Infinity;
        for(var r=0;r<rows.length;r++){
          var rr;try{rr=rows[r].el.getBoundingClientRect();}catch(e){continue;}
          var d=Math.abs(mid-(rr.top+rr.bottom)/2);
          if(d<dist){dist=d;best=rows[r].index;}
        }
        if(best!=null)return {row:best,text:'',source:'geometry'};
      }
      return null;
    }

    function detailScore(el){
      if(!el||el.nodeType!==1)return 0;
      var tx=(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim().toUpperCase();
      if(!tx||tx.length>2500)return 0;
      var labels=['LINE','DEFECT','ACCURACY BY','ACCURACY DATE','HANDOVER BY','HANDOVER DATE','HANDOVER TO','ASSIGNED LINE','PICKED BY','RECEIVED BY'];
      var s=0;
      for(var i=0;i<labels.length;i++)if(tx.indexOf(labels[i])>=0)s++;
      return s;
    }

    function findDetailContainer(target){
      var cur=target,best=null,bestScore=0,depth=0;
      while(cur&&cur!==document.body&&depth<10){
        var sc=detailScore(cur);
        if(sc>bestScore){best=cur;bestScore=sc;}
        cur=cur.parentElement;depth++;
      }
      return bestScore>=2?best:null;
    }

    function extractDetail(el){
      if(!el)return {text:'',fields:[]};
      var text=(el.innerText||el.textContent||'').replace(/\s+/g,' ').trim();
      var fields=[];
      var labels=['LINE','DEFECT','ACCURACY BY','ACCURACY DATE','HANDOVER BY','HANDOVER DATE','HANDOVER TO','ASSIGNED LINE','PICKED BY','RECEIVED BY'];
      var all=[];
      try{all=[].slice.call(el.querySelectorAll('*'));}catch(e){}
      for(var li=0;li<labels.length;li++){
        var lab=labels[li],found=null;
        for(var a=0;a<all.length;a++){
          var t=(all[a].innerText||all[a].textContent||'').replace(/\s+/g,' ').trim();
          if(t.toUpperCase()===lab){found=all[a];break;}
        }
        if(found){
          var box=found.parentElement||found;
          var bt=(box.innerText||box.textContent||'').replace(/\s+/g,' ').trim();
          var val=bt.replace(new RegExp('^'+lab.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'\\s*','i'),'').trim();
          fields.push({label:lab,value:val||'-'});
        }
      }
      return {text:text,fields:fields};
    }

    var old=[];
    for(var i=0;i<rows.length;i++){
      var el=rows[i].el;
      old.push({el:el,outline:el.style.outline});
      el.style.outline='2px solid #38bdf8';
      el.setAttribute('data-ice-pick-row',String(rows[i].index));
    }

    var tip=document.createElement('div');
    tip.id='__ice_hu_pick_tip';
    tip.innerHTML='<b>Tap bagian baris yang kamu mau</b><br><span style="font-size:12px">Material Description, Size, Status, Detail, atau panel detail semuanya bisa dipilih.</span>';
    tip.style.cssText='position:fixed;left:10px;right:10px;top:10px;z-index:2147483647;background:#0f172a;color:#fff;padding:12px;border-radius:10px;border:1px solid #38bdf8;font:13px system-ui;text-align:center';
    document.documentElement.appendChild(tip);

    function cleanup(){
      document.removeEventListener('click',handler,true);
      document.removeEventListener('touchstart',handler,true);
      for(var i=0;i<old.length;i++){
        old[i].el.style.outline=old[i].outline;
        old[i].el.removeAttribute('data-ice-pick-row');
      }
      var t=document.getElementById('__ice_hu_pick_tip');if(t)t.remove();
    }

    function handler(e){
      var target=e.target;
      if(!target)return;

      var detail=findDetailContainer(target);
      var detailData=detail?extractDetail(detail):{text:'',fields:[]};
      var picked=getRowFromTarget(target);

      // Kalau tap panel detail dan target text kurang cocok, pakai container detail untuk cari row.
      if(detail){
        var dPicked=getRowFromTarget(detail);
        if(dPicked)picked=dPicked;
      }

      if(!picked||picked.row==null)return;

      e.preventDefault();e.stopPropagation();e.stopImmediatePropagation();
      cleanup();

      self.huSelectedTableRow=picked.row;
      self.huSelectedPickedText=picked.text||'';
      self.huSelectedPickSource=picked.source||'';
      self.huSelectedDetailText=detailData.text||'';
      self.huSelectedDetailFields=detailData.fields||[];

      setTimeout(function(){self.hiddenHu();},40);
    }

    document.addEventListener('click',handler,true);
    document.addEventListener('touchstart',handler,true);
  },
  qrFinder:function(){this.rescan();var map={},html='';for(var i=0;i<this.qrs.length;i++){var x=this.qrs[i];if(!map[x.code])map[x.code]=[];map[x.code].push(x);}for(var q in map){html+='<div class=c><b>'+this.esc(q)+'</b><div class=m>'+map[q].map(function(x){return T.esc(x.source)+' • '+T.esc(x.context);}).join('<br>')+'</div><button onclick="window.__ICEToolsV30.copy(\''+this.esc(q)+'\')">Copy QR</button></div>';}if(!html)html='<div class=c>MPA-... belum ditemukan.</div>';this.show('Split QR Finder',html);},
  hunter:function(){this.hookNet();var html='<div class=c><b>QR Hunter aktif.</b><div class=m>Request berikutnya akan dipantau. Jika request sudah terjadi sebelum hook aktif, buka ulang/refresh halaman terkait.</div></div>';for(var i=this.requests.length-1;i>=0&&i>this.requests.length-80;i--){var r=this.requests[i];html+='<div class=c><b>'+this.esc(r.type.toUpperCase())+' '+this.esc(r.status)+'</b><div class=m>'+this.esc(r.url)+'</div><details><summary>Response</summary><pre>'+this.esc(r.body)+'</pre></details></div>';}this.show('QR Hunter',html);},
  devtools:function(){this.hookNet();var html='<div class=c><button onclick="window.__ICEToolsV30.devElements()">Elements</button><button onclick="window.__ICEToolsV30.devSource()">Source</button><button onclick="window.__ICEToolsV30.devNetwork()">Network</button><button onclick="window.__ICEToolsV30.devStorage()">Storage</button><button onclick="window.__ICEToolsV30.devFind()">Find</button></div><div class=c><b>Mini DevTools ICE</b><div class=m>Bukan Chrome DevTools penuh, tetapi bisa melihat DOM, source, request yang tertangkap, storage, dan pencarian teks.</div></div>';this.show('DevTools',html);},
  devElements:function(){var s='';try{s=document.documentElement.outerHTML.slice(0,500000);}catch(e){}this.show('DevTools • Elements','<div class=c><button onclick="window.__ICEToolsV30.copy(document.documentElement.outerHTML)">Copy DOM</button><pre>'+this.esc(s)+'</pre></div>');},
  devSource:function(){var s='';try{s='<!DOCTYPE html>\n'+document.documentElement.outerHTML;}catch(e){}this.show('DevTools • Source','<div class=c><button onclick="window.__ICEToolsV30.copy(\'source copied\')">Gunakan Copy DOM di Elements</button><pre>'+this.esc(s.slice(0,500000))+'</pre></div>');},
  devNetwork:function(){var h='';for(var i=this.requests.length-1;i>=0&&i>this.requests.length-100;i--){var r=this.requests[i];h+='<div class=c><b>'+this.esc(r.type)+' '+this.esc(r.status)+'</b><div class=m>'+this.esc(r.url)+'</div><details><summary>Response</summary><pre>'+this.esc(r.body)+'</pre></details></div>';}if(!h)h='<div class=c>Belum ada request tertangkap.</div>';this.show('DevTools • Network',h);},
  devStorage:function(){var o={localStorage:{},sessionStorage:{}};try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);o.localStorage[k]=localStorage.getItem(k);}}catch(e){}try{for(var j=0;j<sessionStorage.length;j++){var q=sessionStorage.key(j);o.sessionStorage[q]=sessionStorage.getItem(q);}}catch(e){}this.show('DevTools • Storage','<div class=c><pre>'+this.esc(JSON.stringify(o,null,2))+'</pre></div>');},
  devFind:function(){this.show('DevTools • Find','<div class=c><input id=__ice_find style="width:100%;box-sizing:border-box;padding:9px;background:#020617;color:#fff;border:1px solid #475569;border-radius:8px" placeholder="Cari MPA-, HU, key..."><button onclick="window.__ICEToolsV30.doFind()">Cari</button><div id=__ice_find_out></div></div>');},
  doFind:function(){var inp=document.getElementById('__ice_find'),out=document.getElementById('__ice_find_out');if(!inp||!out)return;var q=(inp.value||'').trim(),html='';if(!q){out.innerHTML='Masukkan teks.';return;}var src='';try{src=document.documentElement.outerHTML;}catch(e){}var low=src.toLowerCase(),n=q.toLowerCase(),p=0,c=0;while((p=low.indexOf(n,p))>=0&&c<80){html+='<pre>'+this.esc(src.slice(Math.max(0,p-140),Math.min(src.length,p+n.length+220)))+'</pre>';p+=n.length;c++;}out.innerHTML=html||'Tidak ditemukan.';}
};
w.__ICEToolsV30=T;
T.hookNet();
try{T.rescan();}catch(e){}
})();

/* ===== ICE V30 FULL DEVTOOLS INSPECT PICKER START ===== */

(function(){
'use strict';

// IMPORTANT:
 // bridge.js dapat diinjeksi ulang beberapa kali oleh WebView.
 // Jika instance DevTools sudah ada, JANGAN buka panel otomatis.
 // DevTools hanya boleh terbuka karena aksi user dari menu ICE.
if (window.__ICE_FULL_DEVTOOLS__) {
  return;
}

const D = {
  version: '1.0.3-record-filter',
  panel: null,
  bubble: null,
  currentEl: null,
  hoverEl: null,
  pickerOn: false,
  oldOutline: new WeakMap(),
  requests: [],
  logs: [],
  consoleOrig: {},
  installedNetwork: false,
  installedConsole: false,

  esc(s){ return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); },
  txt(v,max=5000){ let s=''; try{s=typeof v==='string'?v:JSON.stringify(v)}catch(e){s=String(v)} return s.length>max?s.slice(0,max)+'…':s; },
  cssPath(el){
    if(!el || el.nodeType!==1) return '';
    const parts=[];
    while(el && el.nodeType===1 && el!==document.documentElement){
      let p=el.tagName.toLowerCase();
      if(el.id){ p += '#'+CSS.escape(el.id); parts.unshift(p); break; }
      const cls=[...el.classList].slice(0,3).filter(Boolean);
      if(cls.length) p += '.'+cls.map(CSS.escape).join('.');
      const parent=el.parentElement;
      if(parent){
        const same=[...parent.children].filter(x=>x.tagName===el.tagName);
        if(same.length>1) p += `:nth-of-type(${same.indexOf(el)+1})`;
      }
      parts.unshift(p);
      el=parent;
    }
    return parts.join(' > ');
  },
  xpath(el){
    if(!el || el.nodeType!==1) return '';
    if(el.id) return `//*[@id="${el.id}"]`;
    const seg=[];
    while(el && el.nodeType===1){
      let i=1, sib=el.previousElementSibling;
      while(sib){ if(sib.tagName===el.tagName)i++; sib=sib.previousElementSibling; }
      seg.unshift(`${el.tagName.toLowerCase()}[${i}]`);
      el=el.parentElement;
      if(el===document.documentElement){ seg.unshift('html[1]'); break; }
    }
    return '/'+seg.join('/');
  },
  copy(s){
    s=String(s??'');
    if(navigator.clipboard?.writeText) navigator.clipboard.writeText(s).catch(()=>this.copyFallback(s));
    else this.copyFallback(s);
    this.toast('Disalin');
  },
  copyFallback(s){
    const t=document.createElement('textarea');
    t.value=s; t.style.cssText='position:fixed;opacity:0;z-index:-1';
    document.documentElement.appendChild(t); t.focus(); t.select();
    try{document.execCommand('copy')}catch(e){} t.remove();
  },
  toast(s){
    const d=document.createElement('div');
    d.textContent=s;
    d.style.cssText='position:fixed;z-index:2147483647;left:50%;bottom:80px;transform:translateX(-50%);background:#111;color:#fff;border:1px solid #444;padding:8px 12px;border-radius:9px;font:13px sans-serif';
    document.documentElement.appendChild(d); setTimeout(()=>d.remove(),1200);
  },

  installConsole(){
    if(this.installedConsole) return;
    this.installedConsole=true;
    ['log','info','warn','error','debug'].forEach(k=>{
      try{
        this.consoleOrig[k]=console[k].bind(console);
        console[k]=(...a)=>{
          this.logs.push({time:new Date().toLocaleTimeString(),type:k,msg:a.map(x=>this.txt(x,3000)).join(' ')});
          if(this.logs.length>1500)this.logs.splice(0,this.logs.length-1500);
          this.consoleOrig[k](...a);
        };
      }catch(e){}
    });
    addEventListener('error',e=>this.logs.push({time:new Date().toLocaleTimeString(),type:'error',msg:`${e.message} @ ${e.filename}:${e.lineno}`}));
    addEventListener('unhandledrejection',e=>this.logs.push({time:new Date().toLocaleTimeString(),type:'promise',msg:this.txt(e.reason)}));
  },

  installNetwork(){
    if(this.installedNetwork)return;
    this.installedNetwork=true;

    if(window.fetch){
      const of=window.fetch.bind(window);
      window.fetch=async(...a)=>{
        const start=Date.now();
        let url=''; try{url=typeof a[0]==='string'?a[0]:a[0]?.url||''}catch(e){}
        try{
          const r=await of(...a); let body='';
          try{body=await r.clone().text()}catch(e){}
          this.requests.push({kind:'fetch',method:a[1]?.method||'GET',url,status:r.status,ms:Date.now()-start,body:this.txt(body,100000)});
          if(this.requests.length>1000)this.requests.shift();
          return r;
        }catch(e){
          this.requests.push({kind:'fetch',method:a[1]?.method||'GET',url,status:'ERR',ms:Date.now()-start,body:String(e)});
          throw e;
        }
      };
    }

    if(window.XMLHttpRequest){
      const op=XMLHttpRequest.prototype.open, sp=XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open=function(m,u,...rest){this.__iceNet={m,u:String(u),t:0}; return op.call(this,m,u,...rest)};
      XMLHttpRequest.prototype.send=function(body){
        if(this.__iceNet)this.__iceNet.t=Date.now();
        this.addEventListener('loadend',()=>{
          try{
            let txt='';
            if(!this.responseType||this.responseType==='text')txt=this.responseText||'';
            else if(this.responseType==='json')txt=JSON.stringify(this.response);
            const m=this.__iceNet||{};
            D.requests.push({kind:'xhr',method:m.m||'',url:m.u||'',status:this.status,ms:Date.now()-(m.t||Date.now()),body:D.txt(txt,100000)});
            if(D.requests.length>1000)D.requests.shift();
          }catch(e){}
        });
        return sp.call(this,body);
      };
    }
  },

  ensureUI(){
    if(document.getElementById('__ice_full_devtools_style'))return;
    const st=document.createElement('style');
    st.id='__ice_full_devtools_style';
    st.textContent=`
#__ice_full_devtools_bubble{position:fixed;right:16px;bottom:90px;z-index:2147483643;width:56px;height:56px;border-radius:50%;border:1px solid #555;background:#111;color:#fff;font:700 13px sans-serif;box-shadow:0 5px 22px #0008}
#__ice_full_devtools{position:fixed;inset:1.5%;z-index:2147483646;background:#0f0f0f;color:#eee;border:1px solid #444;border-radius:12px;display:none;box-shadow:0 0 0 9999px #0008,0 12px 40px #000;font:12px/1.4 sans-serif;overflow:hidden}
#__ice_full_devtools .top{height:46px;background:#1a1a1a;border-bottom:1px solid #333;display:flex;align-items:center;gap:6px;padding:0 8px}
#__ice_full_devtools .top b{flex:1}
#__ice_full_devtools button{background:#292929;color:#eee;border:1px solid #444;border-radius:6px;padding:7px 9px}
#__ice_full_devtools button.active{background:#474747}
#__ice_full_devtools .tabs{height:42px;background:#151515;border-bottom:1px solid #333;display:flex;gap:4px;align-items:center;overflow:auto;padding:0 7px}
#__ice_full_devtools .main{height:calc(100% - 89px);display:grid;grid-template-columns:minmax(260px,44%) 1fr}
#__ice_full_devtools .left,#__ice_full_devtools .right{overflow:auto;padding:8px}
#__ice_full_devtools .left{border-right:1px solid #333}
#__ice_full_devtools .card{border:1px solid #333;background:#171717;border-radius:8px;padding:8px;margin-bottom:7px}
#__ice_full_devtools .code{font:11px/1.45 monospace;white-space:pre-wrap;word-break:break-word;background:#090909;border:1px solid #292929;padding:7px;border-radius:6px}
#__ice_full_devtools .muted{color:#aaa}
#__ice_full_devtools input,#__ice_full_devtools textarea{box-sizing:border-box;width:100%;background:#0d0d0d;color:#eee;border:1px solid #444;border-radius:6px;padding:7px;margin:4px 0}
#__ice_full_devtools table{width:100%;border-collapse:collapse}
#__ice_full_devtools td,#__ice_full_devtools th{border-bottom:1px solid #292929;padding:5px;text-align:left;vertical-align:top}
#__ice_full_devtools .tree-row{font-family:monospace;padding:3px 2px;border-radius:4px}
#__ice_full_devtools .tree-row:hover{background:#222}
#__ice_full_devtools details{margin:5px 0}
#__ice_full_devtools .kv{display:grid;grid-template-columns:minmax(100px,35%) 1fr;gap:5px}
@media(max-width:720px){#__ice_full_devtools{inset:0;border-radius:0}#__ice_full_devtools .main{grid-template-columns:1fr;display:block}#__ice_full_devtools .left{border-right:0;border-bottom:1px solid #333;max-height:42%}#__ice_full_devtools .right{height:58%}}
`;
    document.documentElement.appendChild(st);

    const b=document.createElement('button'); b.id='__ice_full_devtools_bubble'; b.textContent='DEV'; b.onclick=()=>this.open(); b.style.display='none'; document.documentElement.appendChild(b); this.bubble=b;

    const p=document.createElement('div'); p.id='__ice_full_devtools';
    p.innerHTML=`<div class="top"><b>ICE Full DevTools</b><button data-picker>🎯 Inspect</button><button data-refresh>↻</button><button data-close>✕</button></div><div class="tabs"></div><div class="main"><div class="left"></div><div class="right"></div></div>`;
    document.documentElement.appendChild(p); this.panel=p;
    p.querySelector('[data-close]').onclick=()=>this.close();
    p.querySelector('[data-picker]').onclick=()=>this.startPicker();
    p.querySelector('[data-refresh]').onclick=()=>this.render(this.activeTab||'elements');
  },

  open(){
    this.ensureUI();
    this._userOpened = true;
    this.panel.style.display='block';
    this.render(this.activeTab || 'elements');
  },
  close(){
    this._userOpened = false;
    this.stopPicker();
    if(this.panel)this.panel.style.display='none';
  },

  tabs(){
    return [
      ['elements','Elements'],['styles','Styles'],['console','Console'],['network','Network'],
      ['sources','Sources'],['storage','Storage'],['cookies','Cookies'],['forms','Forms'],
      ['scripts','Scripts'],['find','Find'],['huqr','HU/QR']
    ];
  },

  render(tab){
    this.activeTab=tab;
    const P=this.panel,L=P.querySelector('.left'),R=P.querySelector('.right'),T=P.querySelector('.tabs');
    T.innerHTML=this.tabs().map(([id,n])=>`<button data-tab="${id}" class="${id===tab?'active':''}">${n}</button>`).join('');
    T.onclick=e=>{const id=e.target.closest('button')?.dataset?.tab;if(id)this.render(id)};
    L.innerHTML=''; R.innerHTML='';
    if(tab==='elements')this.renderElements(L,R);
    if(tab==='styles')this.renderStyles(L,R);
    if(tab==='console')this.renderConsole(L,R);
    if(tab==='network')this.renderNetwork(L,R);
    if(tab==='sources')this.renderSources(L,R);
    if(tab==='storage')this.renderStorage(L,R);
    if(tab==='cookies')this.renderCookies(L,R);
    if(tab==='forms')this.renderForms(L,R);
    if(tab==='scripts')this.renderScripts(L,R);
    if(tab==='find')this.renderFind(L,R);
    if(tab==='huqr')this.renderHUQR(L,R);
  },

  startPicker(){
    this.stopPicker();
    this.pickerOn=true;
    this.panel.style.display='none';
    const move=e=>{
      if(!this.pickerOn)return;
      const el=e.target;
      if(this.hoverEl && this.oldOutline.has(this.hoverEl)) this.hoverEl.style.outline=this.oldOutline.get(this.hoverEl);
      this.hoverEl=el; this.oldOutline.set(el,el.style.outline); el.style.outline='2px solid #00ffff';
    };
    const pick=e=>{
      if(!this.pickerOn)return;
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      const el=e.target;
      this.currentEl=el;
      this.stopPicker();
      this.panel.style.display='block';
      this.render('elements');
    };
    this._pickerMove=move; this._pickerPick=pick;
    document.addEventListener('mousemove',move,true);
    document.addEventListener('touchstart',pick,true);
    document.addEventListener('click',pick,true);
    this.toast('Tap bagian halaman yang ingin di-inspect');
  },
  stopPicker(){
    this.pickerOn=false;
    if(this.hoverEl && this.oldOutline.has(this.hoverEl))this.hoverEl.style.outline=this.oldOutline.get(this.hoverEl);
    this.hoverEl=null;
    if(this._pickerMove)document.removeEventListener('mousemove',this._pickerMove,true);
    if(this._pickerPick){document.removeEventListener('touchstart',this._pickerPick,true);document.removeEventListener('click',this._pickerPick,true)}
  },

  renderElements(L,R){
    const root=this.currentEl||document.body;
    const ancestors=[]; let x=root;
    while(x&&x.nodeType===1){ancestors.unshift(x);x=x.parentElement}
    L.innerHTML=`<div class="card"><b>Selected</b><div class="code">${this.esc(this.cssPath(root))}</div><button id="pick2">🎯 Pilih bagian halaman</button></div>`+
      `<div class="card"><b>Breadcrumb</b>${ancestors.map((e,i)=>`<div class="tree-row" data-bc="${i}">&lt;${e.tagName.toLowerCase()}${e.id?'#'+this.esc(e.id):''}&gt;</div>`).join('')}</div>`+
      `<div class="card"><b>Children</b>${[...root.children].slice(0,200).map((e,i)=>`<div class="tree-row" data-child="${i}">&lt;${e.tagName.toLowerCase()}${e.id?'#'+this.esc(e.id):''}${e.className?' .'+this.esc(String(e.className).split(/\s+/).slice(0,3).join('.')):''}&gt; ${this.esc((e.innerText||'').trim().slice(0,80))}</div>`).join('')||'<span class="muted">Tidak ada child.</span>'}</div>`;
    L.querySelector('#pick2').onclick=()=>this.startPicker();
    L.querySelectorAll('[data-bc]').forEach(n=>n.onclick=()=>{this.currentEl=ancestors[+n.dataset.bc];this.render('elements')});
    L.querySelectorAll('[data-child]').forEach(n=>n.onclick=()=>{this.currentEl=root.children[+n.dataset.child];this.render('elements')});

    const attrs=[...(root.attributes||[])];
    const ds={}; try{Object.keys(root.dataset||{}).forEach(k=>ds[k]=root.dataset[k])}catch(e){}
    R.innerHTML=`
      <div class="card"><b>Element</b><div class="code">${this.esc(root.outerHTML?.slice(0,100000)||'')}</div>
      <button id="copyhtml">Copy HTML</button><button id="copycss">Copy CSS Selector</button><button id="copyxp">Copy XPath</button></div>
      <div class="card"><b>Text / Value</b><div class="code">${this.esc(('value' in root?root.value:'')||root.innerText||'')}</div></div>
      <div class="card"><b>Attributes</b><table>${attrs.map(a=>`<tr><td>${this.esc(a.name)}</td><td class="code">${this.esc(a.value)}</td></tr>`).join('')||'<tr><td>Tidak ada</td></tr>'}</table></div>
      <div class="card"><b>data-*</b><div class="code">${this.esc(JSON.stringify(ds,null,2))}</div></div>
      <div class="card"><b>Geometry</b><div class="code">${this.esc(JSON.stringify((()=>{const q=root.getBoundingClientRect();return {x:q.x,y:q.y,width:q.width,height:q.height,scrollX,scrollY}})(),null,2))}</div></div>
      <div class="card"><b>Quick scan</b><button id="scanmpa">Cari MPA di element</button><button id="scanhu">Cari HU context</button><div id="scanout"></div></div>`;
    R.querySelector('#copyhtml').onclick=()=>this.copy(root.outerHTML||'');
    R.querySelector('#copycss').onclick=()=>this.copy(this.cssPath(root));
    R.querySelector('#copyxp').onclick=()=>this.copy(this.xpath(root));
    R.querySelector('#scanmpa').onclick=()=>{
      const s=(root.outerHTML||'')+' '+(root.innerText||'');
      const m=[...new Set(s.match(/\bMPA-[A-Z0-9._:/-]{3,}\b/gi)||[])];
      R.querySelector('#scanout').innerHTML=`<div class="code">${this.esc(m.join('\n')||'Tidak ditemukan')}</div>`;
    };
    R.querySelector('#scanhu').onclick=()=>{
      const s=(root.outerHTML||'')+' '+(root.innerText||'');
      const lines=s.split(/\n/).filter(z=>/\b(hu|handling\s*unit)\b/i.test(z)).slice(0,100);
      R.querySelector('#scanout').innerHTML=`<div class="code">${this.esc(lines.join('\n')||'Tidak ada konteks HU yang jelas')}</div>`;
    };
  },

  renderStyles(L,R){
    const el=this.currentEl||document.body;
    L.innerHTML=`<div class="card"><b>${this.esc(this.cssPath(el))}</b><br><button id="pickstyle">🎯 Pilih element</button></div>`;
    L.querySelector('#pickstyle').onclick=()=>this.startPicker();
    const inline=el.getAttribute?.('style')||'';
    let comp={};
    try{
      const cs=getComputedStyle(el);
      for(const k of cs){const v=cs.getPropertyValue(k);if(v)comp[k]=v}
    }catch(e){}
    R.innerHTML=`<div class="card"><b>Inline style</b><div class="code">${this.esc(inline||'(kosong)')}</div></div>
    <div class="card"><b>Computed style</b><input id="stylefilter" placeholder="filter: display, color, width..."><div id="stylelist"></div></div>`;
    const draw=()=>{
      const q=(R.querySelector('#stylefilter').value||'').toLowerCase();
      R.querySelector('#stylelist').innerHTML=Object.entries(comp).filter(([k,v])=>!q||k.includes(q)||v.toLowerCase().includes(q)).slice(0,1000).map(([k,v])=>`<div class="kv"><span>${this.esc(k)}</span><span class="code">${this.esc(v)}</span></div>`).join('');
    };
    R.querySelector('#stylefilter').oninput=draw; draw();
  },

  renderConsole(L,R){
    L.innerHTML=`<div class="card"><button id="clearlog">Clear</button><button id="refreshlog">Refresh</button></div>
    <div class="card">${this.logs.slice().reverse().slice(0,500).map((x,i)=>`<div class="tree-row" data-log="${i}">[${this.esc(x.type)}] ${this.esc(x.msg.slice(0,100))}</div>`).join('')||'Belum ada log.'}</div>`;
    R.innerHTML=`<div class="card"><b>Console evaluator</b><textarea id="evaljs" rows="5" placeholder="JavaScript..."></textarea><button id="runeval">Run</button><div id="evalout" class="code"></div></div>`;
    L.querySelector('#clearlog').onclick=()=>{this.logs=[];this.render('console')};
    L.querySelector('#refreshlog').onclick=()=>this.render('console');
    L.querySelectorAll('[data-log]').forEach((n,i)=>n.onclick=()=>{const x=this.logs.slice().reverse()[i];R.innerHTML=`<div class="card"><div class="muted">${this.esc(x.time)} ${this.esc(x.type)}</div><div class="code">${this.esc(x.msg)}</div></div>`});
    R.querySelector('#runeval').onclick=()=>{
      const code=R.querySelector('#evaljs').value;
      try{const v=(0,eval)(code);R.querySelector('#evalout').textContent=this.txt(v,20000)}catch(e){R.querySelector('#evalout').textContent=String(e)}
    };
  },

  renderNetwork(L,R){
    const rev=this.requests.slice().reverse();
    L.innerHTML=`<div class="card"><button id="netrefresh">Refresh</button><button id="netclear">Clear</button><input id="netfilter" placeholder="Filter URL / method / status"></div><div id="netrows"></div>`;
    const draw=()=>{
      const q=(L.querySelector('#netfilter').value||'').toLowerCase();
      const a=rev.filter(x=>!q||`${x.method} ${x.url} ${x.status}`.toLowerCase().includes(q));
      L.querySelector('#netrows').innerHTML=a.slice(0,700).map((x,i)=>`<div class="card" data-req="${this.requests.indexOf(x)}"><b>${this.esc(x.method)} ${this.esc(x.status)}</b><div class="muted">${this.esc(x.kind)} • ${this.esc(x.ms)}ms</div><div>${this.esc(x.url)}</div></div>`).join('')||'<div class="card">Belum ada request setelah hook aktif.</div>';
      L.querySelectorAll('[data-req]').forEach(n=>n.onclick=()=>{
        const x=this.requests[+n.dataset.req];
        R.innerHTML=`<div class="card"><b>${this.esc(x.method)} ${this.esc(x.url)}</b><div class="muted">status ${this.esc(x.status)} • ${this.esc(x.ms)}ms</div></div><div class="card"><b>Response</b><button id="copyresp">Copy</button><div class="code">${this.esc(x.body)}</div></div>`;
        R.querySelector('#copyresp').onclick=()=>this.copy(x.body);
      });
    };
    L.querySelector('#netrefresh').onclick=()=>this.render('network');L.querySelector('#netclear').onclick=()=>{this.requests=[];this.render('network')};L.querySelector('#netfilter').oninput=draw;draw();
    R.innerHTML='<div class="card">Pilih request untuk melihat response.</div>';
  },

  renderSources(L,R){
    const html='<!DOCTYPE html>\n'+document.documentElement.outerHTML;
    L.innerHTML=`<div class="card"><b>Document</b><div>${this.esc(location.href)}</div><button id="copysource">Copy Source</button></div>`;
    R.innerHTML=`<div class="code">${this.esc(html.slice(0,1000000))}</div>`;
    L.querySelector('#copysource').onclick=()=>this.copy(html);
  },

  renderStorage(L,R){
    const stores=[['localStorage',localStorage],['sessionStorage',sessionStorage]];
    L.innerHTML=stores.map(([n,s])=>`<div class="card"><b>${n}</b>${(()=>{let h='';try{for(let i=0;i<s.length;i++){const k=s.key(i);h+=`<div class="tree-row" data-store="${n}" data-key="${this.esc(k)}">${this.esc(k)}</div>`}}catch(e){}return h||'<div class="muted">kosong</div>'})()}</div>`).join('');
    L.querySelectorAll('[data-store]').forEach(n=>n.onclick=()=>{
      const s=n.dataset.store==='localStorage'?localStorage:sessionStorage,k=n.dataset.key,v=s.getItem(k);
      R.innerHTML=`<div class="card"><b>${this.esc(k)}</b><button id="copyval">Copy</button><div class="code">${this.esc(v)}</div></div>`;R.querySelector('#copyval').onclick=()=>this.copy(v);
    });
  },

  renderCookies(L,R){
    const arr=document.cookie?document.cookie.split(/;\s*/):[];
    L.innerHTML=`<div class="card">${arr.map((x,i)=>`<div class="tree-row" data-cookie="${i}">${this.esc(x.split('=')[0])}</div>`).join('')||'Tidak ada cookie yang dapat dibaca JavaScript.'}</div>`;
    L.querySelectorAll('[data-cookie]').forEach(n=>{const v=arr[+n.dataset.cookie];n.onclick=()=>R.innerHTML=`<div class="card code">${this.esc(v)}</div>`});
  },

  renderForms(L,R){
    const fs=[...document.forms];
    L.innerHTML=fs.map((f,i)=>`<div class="card" data-form="${i}"><b>Form ${i+1}</b><div class="muted">${this.esc(f.action)} • ${this.esc(f.method)}</div></div>`).join('')||'<div class="card">Tidak ada form.</div>';
    L.querySelectorAll('[data-form]').forEach(n=>n.onclick=()=>{
      const f=fs[+n.dataset.form];
      R.innerHTML=`<div class="card"><b>Fields</b><table>${[...f.elements].map(e=>`<tr><td>${this.esc(e.name||e.id||e.tagName)}</td><td>${this.esc(e.type||'')}</td><td class="code">${this.esc(e.value||'')}</td></tr>`).join('')}</table></div>`;
    });
  },

  renderScripts(L,R){
    const ss=[...document.scripts];
    L.innerHTML=ss.map((s,i)=>`<div class="card" data-script="${i}"><b>Script ${i+1}</b><div class="muted">${this.esc(s.src||'inline')}</div></div>`).join('');
    L.querySelectorAll('[data-script]').forEach(n=>n.onclick=()=>{
      const s=ss[+n.dataset.script],txt=s.src?`External script:\n${s.src}`:(s.textContent||'');
      R.innerHTML=`<div class="card"><button id="copyscript">Copy</button><div class="code">${this.esc(txt.slice(0,500000))}</div></div>`;R.querySelector('#copyscript').onclick=()=>this.copy(txt);
    });
  },

  renderFind(L,R){
    L.innerHTML=`<div class="card"><input id="findq" placeholder="Cari text, MPA-, HU, data-id..."><button id="findgo">Cari seluruh DOM</button><button id="findsel">Cari di selected element</button></div>`;
    const go=(selected)=>{
      const q=L.querySelector('#findq').value.trim(); if(!q)return;
      const src=selected?(this.currentEl?.outerHTML||''):document.documentElement.outerHTML;
      const low=src.toLowerCase(),needle=q.toLowerCase(),out=[];let p=0;
      while((p=low.indexOf(needle,p))>=0&&out.length<200){out.push(src.slice(Math.max(0,p-180),Math.min(src.length,p+needle.length+300)));p+=needle.length}
      R.innerHTML=`<div class="card"><b>${out.length} hasil</b></div>`+out.map(x=>`<div class="card code">${this.esc(x)}</div>`).join('');
    };
    L.querySelector('#findgo').onclick=()=>go(false);L.querySelector('#findsel').onclick=()=>go(true);
    R.innerHTML='<div class="card">Masukkan kata pencarian.</div>';
  },


  renderHUQR(L,R){
    const qrMap = new Map();

    const addQR = (code, source, context) => {
      if(!code) return;
      const c = String(code).toUpperCase().trim();
      if(!/^MPA-[A-Z0-9._:/-]{3,}$/.test(c)) return;
      if(!qrMap.has(c)) qrMap.set(c, []);
      qrMap.get(c).push({source:source||'unknown', context:context||''});
    };

    const normalizeTexts = (raw) => {
      const out = [];
      const base = String(raw ?? '');
      out.push(base);

      // JSON / unicode escaped form, contoh MPA\u002D12345
      try {
        const u = base.replace(/\\u([0-9a-fA-F]{4})/g, (_,h)=>String.fromCharCode(parseInt(h,16)));
        if(u !== base) out.push(u);
      } catch(e) {}

      // HTML entity encoded
      try {
        const ta = document.createElement('textarea');
        ta.innerHTML = base;
        const h = ta.value;
        if(h && h !== base) out.push(h);
      } catch(e) {}

      // URL encoded
      try {
        const d = decodeURIComponent(base.replace(/\+/g,'%20'));
        if(d && d !== base) out.push(d);
      } catch(e) {}

      // Backslash escaped slash/dash variants
      try {
        const s = base.replace(/\\\//g,'/').replace(/\\-/g,'-').replace(/\\"/g,'"');
        if(s !== base) out.push(s);
      } catch(e) {}

      return [...new Set(out)];
    };

    const scanQRText = (raw, source, context) => {
      normalizeTexts(raw).forEach(txt => {
        const found = txt.match(/\bMPA[\s:_-]*[A-Z0-9][A-Z0-9._:/-]{2,}\b/gi) || [];
        found.forEach(v => {
          // normalisasi separator setelah MPA menjadi "-"
          const c = v.replace(/^MPA[\s:_-]*/i,'MPA-').replace(/\s+/g,'');
          addQR(c, source, context);
        });
      });
    };

    // 1. Current DOM
    try { scanQRText(document.documentElement.outerHTML, 'DOM HTML', location.href); } catch(e) {}

    // 2. Scan tiap element lebih dalam: text/value/attributes
    const allEls = [...document.querySelectorAll('*')];
    allEls.forEach((el,idx)=>{
      try {
        const ctx = this.cssPath(el) || `${el.tagName||'EL'}[${idx}]`;
        if('value' in el && typeof el.value === 'string') scanQRText(el.value, 'DOM value', ctx);
        const txt = (el.textContent||'');
        if(txt && txt.length < 20000) scanQRText(txt, 'DOM text', ctx);
        [...(el.attributes||[])].forEach(a=>scanQRText(a.value, `attr:${a.name}`, ctx));
      } catch(e) {}
    });

    // 3. Inline scripts
    [...document.scripts].forEach((s,i)=>{
      try {
        if(s.textContent) scanQRText(s.textContent, 'inline script', `script[${i}]`);
        if(s.src) scanQRText(s.src, 'script src', s.src);
      } catch(e) {}
    });

    // 4. localStorage + sessionStorage
    const scanStore = (store,name)=>{
      try {
        for(let i=0;i<store.length;i++){
          const k=store.key(i);
          const v=store.getItem(k);
          scanQRText(k, name+' key', k);
          scanQRText(v, name, k);
        }
      } catch(e) {}
    };
    scanStore(localStorage,'localStorage');
    scanStore(sessionStorage,'sessionStorage');

    // 5. Network responses yang sudah ditangkap DevTools
    try {
      this.requests.forEach((req,i)=>{
        scanQRText(req.url, 'network URL', `${req.kind} ${req.method}`);
        scanQRText(req.body, 'network response', req.url || `request[${i}]`);
      });
    } catch(e) {}

    // 6. Performance resource URLs
    try {
      performance.getEntriesByType('resource').forEach((e,i)=>{
        scanQRText(e.name, 'performance resource', `resource[${i}]`);
      });
    } catch(e) {}

    const mpa = [...qrMap.keys()].sort();

    // HU tetap konservatif: hanya field/key dengan konteks HU
    const huCandidates=[];
    const keyRx=/^(hu|hu[_\s-]?code|hu[_\s-]?no|hu[_\s-]?number|handling[_\s-]?unit|handling[_\s-]?unit[_\s-]?(code|no|number))$/i;

    document.querySelectorAll('*').forEach(el=>{
      try{
        for(const a of [...el.attributes]){
          if(keyRx.test(a.name)||/\b(hu|handling\s*unit)\b/i.test(a.name)){
            huCandidates.push({v:a.value,src:`attr ${a.name}`,el});
          }
        }
        const n=el.getAttribute?.('name')||'';
        const id=el.id||'';
        const lab=el.getAttribute?.('aria-label')||'';
        const title=el.getAttribute?.('title')||'';
        const ph=el.getAttribute?.('placeholder')||'';

        if([n,id,lab,title,ph].some(x=>keyRx.test(x)||/\b(hu|handling\s*unit)\b/i.test(x))){
          const v=('value'in el?el.value:'')||(el.innerText||'').trim();
          if(v) huCandidates.push({v,src:'field',el});
        }
      }catch(e){}
    });

    const uniq=[]; const seen=new Set();
    huCandidates.forEach(x=>{
      const v=String(x.v||'').trim();
      const k=v+'|'+x.src;
      if(v && !seen.has(k)){ seen.add(k); uniq.push({...x,v}); }
    });

    const warn = uniq.length > mpa.length
      ? `<div class="card" style="border-color:#a66"><b>⚠ HU ${uniq.length}, Split QR ${mpa.length}</b><div class="muted">Masih ada ${uniq.length-mpa.length} QR yang belum terlihat/tertangkap. Aktifkan QR Hunter lalu buka/refresh data yang terkait HU tersebut.</div></div>`
      : '';

    L.innerHTML =
      `<div class="card"><button id="qrdeeprefresh">↻ Deep Scan ulang</button><div class="muted">Scan: DOM + hidden/value + attributes + scripts + storage + network response + encoded text</div></div>`+
      warn+
      `<div class="card"><b>Split QR ditemukan: ${mpa.length}</b>${
        mpa.map(x=>`<div class="tree-row" data-mpa="${this.esc(x)}">${this.esc(x)} <span class="muted">(${qrMap.get(x).length} sumber)</span></div>`).join('')
        || '<div class="muted">Belum ada MPA-...</div>'
      }</div>`+
      `<div class="card"><b>Kandidat HU valid-context: ${uniq.length}</b>${
        uniq.map((x,i)=>`<div class="tree-row" data-hu="${i}">${this.esc(x.v)}</div>`).join('')
        || '<div class="muted">HU belum ditemukan.</div>'
      }</div>`;

    L.querySelector('#qrdeeprefresh').onclick=()=>this.render('huqr');

    L.querySelectorAll('[data-mpa]').forEach(n=>n.onclick=()=>{
      const q=n.dataset.mpa;
      const srcs=qrMap.get(q)||[];
      R.innerHTML=`<div class="card"><b>${this.esc(q)}</b><button id="copyq">Copy</button><div class="muted">Ditemukan dari:</div>${srcs.map(s=>`<div class="code">${this.esc(s.source)} • ${this.esc(s.context)}</div>`).join('')}</div>`;
      R.querySelector('#copyq').onclick=()=>this.copy(q);
    });

    L.querySelectorAll('[data-hu]').forEach(n=>n.onclick=()=>{
      const x=uniq[+n.dataset.hu];
      this.currentEl=x.el;
      const localQR = new Set();
      try {
        const neighborhood = [
          x.el?.outerHTML||'',
          x.el?.parentElement?.outerHTML||'',
          x.el?.closest?.('tr')?.outerHTML||'',
          x.el?.closest?.('[data-id]')?.outerHTML||''
        ].join('\n');
        normalizeTexts(neighborhood).forEach(t=>{
          (t.match(/\bMPA[\s:_-]*[A-Z0-9][A-Z0-9._:/-]{2,}\b/gi)||[]).forEach(v=>localQR.add(v.replace(/^MPA[\s:_-]*/i,'MPA-').replace(/\s+/g,'')));
        });
      } catch(e) {}

      R.innerHTML=`<div class="card"><b>HU: ${this.esc(x.v)}</b><div class="muted">${this.esc(x.src)}</div><button id="inspecthu">Inspect element</button></div>
      <div class="card"><b>QR dekat HU ini</b>${[...localQR].map(q=>`<div class="code">${this.esc(q)}</div>`).join('')||'<div class="muted">Belum ditemukan di DOM sekitar HU ini.</div>'}</div>`;
      R.querySelector('#inspecthu').onclick=()=>this.render('elements');
    });

    if(!R.innerHTML) R.innerHTML='<div class="card">Pilih HU atau QR untuk detail.</div>';
  },

  init(){
    this.installConsole();
    this.installNetwork();
    this.ensureUI();
  }
};

window.__ICE_FULL_DEVTOOLS__=D;
D.init();
})();


(function(){
  try {
    if (window.__ICEToolsV30) {
      window.__ICEToolsV30.devtools = function(){
        try {
          if (window.__ICE_FULL_DEVTOOLS__) {
            window.__ICE_FULL_DEVTOOLS__.open();
            return;
          }
        } catch (_) {}
      };
      window.__ICEToolsV30.devElements = function(){
        try { window.__ICE_FULL_DEVTOOLS__ && window.__ICE_FULL_DEVTOOLS__.open(); } catch (_) {}
      };
    }
  } catch (_) {}
})();

/* ===== ICE V30 FULL DEVTOOLS INSPECT PICKER END ===== */
