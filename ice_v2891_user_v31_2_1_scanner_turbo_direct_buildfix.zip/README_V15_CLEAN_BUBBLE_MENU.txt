ICE v15 - Clean Bubble Menu

Perubahan:
- Menu gelembung hanya berisi Cari di halaman dan COPY HU.
- Unduhan hanya tersedia di menu titik tiga kanan atas.
- Muat ulang dihapus dari menu gelembung karena sudah tersedia di toolbar/menu browser.
- Sembunyikan gelembung dihapus dari menu gelembung dan tetap tersedia di menu titik tiga.
