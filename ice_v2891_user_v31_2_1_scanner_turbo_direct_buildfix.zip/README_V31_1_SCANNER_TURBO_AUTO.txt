ICE v2.8.9.1 v31.1 — SCANNER TURBO OTOMATIS

Perubahan utama:
- Scanner ICE Turbo aktif otomatis saat website meminta akses kamera.
- Tidak perlu membuka Scanner Turbo dari menu terlebih dahulu.
- Kamera website diberi waktu untuk menyiapkan callback, lalu ICE mengambil alih kamera native.
- Hasil scan tetap dikirim ke alur scanner halaman tanpa menekan Submit otomatis.
- Mode otomatis aktif secara default dan dapat dimatikan dari menu ICE.
- Tombol Scanner ICE Turbo manual tetap tersedia sebagai cadangan.
- Setelah scanner ditutup, ada jeda 3 detik agar tidak langsung terbuka kembali.

Cara kerja:
1. Buka halaman scanner perusahaan.
2. Tekan tombol scan milik website seperti biasa.
3. Saat website meminta kamera, Scanner ICE Turbo terbuka otomatis.
4. Arahkan barcode/QR; hasil diteruskan ke halaman.
