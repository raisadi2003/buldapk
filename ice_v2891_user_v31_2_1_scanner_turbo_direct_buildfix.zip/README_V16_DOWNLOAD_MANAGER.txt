ICE v16 — Manajer Unduhan

Perubahan:
- Progres unduhan diperbarui otomatis setiap 0,5 detik.
- Persentase bergerak sesuai data DownloadManager.
- Riwayat dikelompokkan: Hari ini, Kemarin, atau tanggal lengkap.
- Waktu menampilkan “baru saja”, “menit lalu”, jam, tanggal, bulan, dan tahun.
- Menu tiga titik pada setiap unduhan: Buka, Ganti nama, Hapus.
- Ganti nama menjaga ekstensi file jika pengguna tidak menuliskannya.
- Hapus menghapus file dari penyimpanan dan daftar unduhan.
