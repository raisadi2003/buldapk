ICE v20 — Menu Icon & QR Accounts Polish

Perubahan:
- Menu ICE memakai ikon Android asli di dalam kotak ikon yang seragam.
- Ikon Unduhan sekarang jelas dan diberi aksen biru.
- Teks simbol lama yang kadang berubah menjadi karakter aneh sudah tidak dipakai sebagai ikon utama.
- Kartu akun QR diubah menjadi tema gelap Material 3.
- Ditambahkan avatar inisial akun.
- Nama akun dibuat satu baris dan dipotong otomatis jika terlalu panjang.
- Tombol aksi memiliki ukuran sama: LOGIN, EDIT, PINDAH, HAPUS.
- Tombol PINDAH tetap membuka pilihan Pindahkan atau Salin, sehingga fungsi lama tidak hilang.
