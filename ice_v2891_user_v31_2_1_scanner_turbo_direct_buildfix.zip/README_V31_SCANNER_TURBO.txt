ICE v2.8.9.1 v31 — SCANNER ICE TURBO

Fitur baru:
- Scanner kamera native real-time untuk QR dan barcode.
- Dibuka dari gelembung Menu ICE atau menu titik tiga.
- Autofocus berulang dan ketuk layar untuk fokus area.
- Auto-zoom jika barcode belum terbaca.
- Tombol zoom manual, flash, fokus, dan selesai.
- Membaca dua frame untuk memastikan hasil dan mencegah scan ganda.
- Bunyi/getar saat kode berhasil terbaca.
- Hasil dikirim ke bridge scanner website aktif.
- ICE tidak menekan tombol Submit secara langsung.
- Kamera milik website dihentikan sementara agar tidak bentrok dengan kamera native.
- Fitur v30 Centang Semua Hijau pada semua URL tetap dipertahankan.

Cara pakai:
1. Buka halaman perusahaan dan masuk ke menu/halaman scan seperti biasa.
2. Tekan lama gelembung ICE.
3. Pilih Scanner ICE Turbo.
4. Arahkan QR/barcode ke kotak kamera. Tidak perlu menekan tombol jepret.
5. Setelah status Terkirim muncul, lanjutkan barcode berikutnya.
6. Tekan SELESAI untuk kembali ke halaman.

Catatan:
- Jika tertulis scanner website belum siap, buka ulang menu scan pada halaman perusahaan lalu jalankan Turbo lagi.
- Pengiriman tetap mengikuti fungsi scanner website perusahaan; fitur ini tidak mengubah server perusahaan.
