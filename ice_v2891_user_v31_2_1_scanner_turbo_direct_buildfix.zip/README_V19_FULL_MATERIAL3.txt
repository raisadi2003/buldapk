ICE v19 — Full Material 3 UI

- Tema aplikasi keseluruhan memakai surface gelap modern yang konsisten.
- Toolbar, address bar, navigasi bawah, panel scanner, menu, dialog, input, dan tombol dirapikan.
- Semua AlertDialog memakai tema ICE dengan sudut 28dp, border halus, warna teks konsisten, dan aksen biru.
- Tombol toolbar memakai ripple Android, tanpa latar kotak lama.
- Menu ICE tetap memakai panel Material 3 dan mode desktop dari v18 dipertahankan.
