ICE v2.8.9.1 v27 - COPY KODE QR PACK
=======================================

Fitur baru:
- Menu gelembung ICE sekarang memiliki tombol "Copy Kode QR".
- Digunakan pada halaman /Pack/Index setelah tabel Content of Barcode tampil.
- Mengambil seluruh nilai pada kolom QR CODE, urut dari atas ke bawah.
- Setiap kode otomatis diberi awalan MAT-.
- Hasil clipboard satu kode per baris, contoh MAT-00067906.
- Kode kosong dan duplikat tidak ikut disalin.
- Mendukung tabel DataTables; bila data tersedia di sisi browser, semua hasil filter ikut diambil.

Varian: USER
Nama APK hasil build: ice_v2891_user_v27_copy_qr_pack.apk
