ICE v2.8.9.1 V30 - Centang Hijau Semua URL

- Tombol tetap berada di menu gelembung ICE.
- Tidak berjalan otomatis saat halaman dibuka.
- Dapat digunakan pada URL/folder mana pun yang dibuka di ICE.
- Mendeteksi kolom PASSED/lulus/sesuai atau kolom kontrol berwarna hijau.
- Hanya radio/checkbox pada kolom hijau yang dipilih.
- Tombol submit/kirim tidak pernah ditekan otomatis.
- Jika halaman tidak memiliki tabel/kolom hijau yang dikenali, tidak ada perubahan.
