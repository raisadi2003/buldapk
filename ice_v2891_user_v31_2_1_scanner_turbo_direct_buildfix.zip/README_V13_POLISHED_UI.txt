V13: bar Cari di halaman overlay kecil, menu ICE modern, gelembung bulat dengan logo ICE, hide/show tetap tersedia.
