ICE v17
- Toast petunjuk tekan lama gelembung dihapus total.
- Tap/geser gelembung tidak memunculkan spam notifikasi.
- Tekan lama tetap membuka menu gelembung.
- Folder akun QR kini memiliki tombol Export dan Import.
- Export menyimpan akun, isi QR, dan folder dalam file JSON.
- Import menyediakan pilihan Gabungkan atau Ganti semua.
- Data duplikat identik dilewati saat mode Gabungkan.
