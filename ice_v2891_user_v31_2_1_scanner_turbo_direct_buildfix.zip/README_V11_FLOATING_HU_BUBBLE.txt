V11 - Floating HU Bubble

- Tombol COPY HU lama dipindahkan ke gelembung HU mengambang.
- Gelembung dapat digeser ke seluruh area halaman dan posisi terakhir disimpan.
- Tekan lama gelembung untuk membuka menu COPY HU.
- Menu titik tiga memiliki pilihan Sembunyikan/Tampilkan gelembung HU.
