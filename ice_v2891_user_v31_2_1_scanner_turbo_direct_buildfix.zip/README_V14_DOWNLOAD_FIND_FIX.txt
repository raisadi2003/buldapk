ICE v14
- Tombol hasil pencarian menggunakan ikon Android bawaan agar tidak berubah menjadi huruf acak.
- Bar cari ringkas: input, jumlah hasil, atas, bawah, tutup.
- Dukungan download HTTP/HTTPS melalui Android Download Manager.
- File otomatis disimpan ke Internal Storage/Download/ICE Download.
- Menu Unduhan tersedia di menu titik tiga dan menu gelembung.
- Daftar unduhan menampilkan status dan file selesai dapat diketuk untuk dibuka.
