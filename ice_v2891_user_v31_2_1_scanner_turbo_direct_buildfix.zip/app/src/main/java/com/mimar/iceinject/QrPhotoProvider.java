package com.mimar.iceinject;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.os.Environment;
import android.webkit.MimeTypeMap;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Provider kecil khusus foto QR sementara di cache aplikasi.
 * Tidak memberi akses ke file lain dan tidak memakai penyimpanan/galeri publik.
 */
public class QrPhotoProvider extends ContentProvider {
    private static final String CACHE_FOLDER = "qr_photos";

    public static Uri getDownloadUriForFile(Context context, File file) throws IOException {
        File allowedDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ICE Download").getCanonicalFile();
        File requested = file.getCanonicalFile();
        String allowedPath = allowedDir.getPath() + File.separator;
        if (!requested.getPath().startsWith(allowedPath)) {
            throw new SecurityException("File berada di luar folder ICE Download");
        }
        return new Uri.Builder()
                .scheme("content")
                .authority(context.getPackageName() + ".fileprovider")
                .appendPath("download")
                .appendPath(requested.getName())
                .build();
    }

    public static Uri getUriForFile(Context context, File file) throws IOException {
        File allowedDir = new File(context.getCacheDir(), CACHE_FOLDER).getCanonicalFile();
        File requested = file.getCanonicalFile();
        String allowedPath = allowedDir.getPath() + File.separator;
        if (!requested.getPath().startsWith(allowedPath)) {
            throw new SecurityException("File foto berada di luar cache QR");
        }
        return new Uri.Builder()
                .scheme("content")
                .authority(context.getPackageName() + ".fileprovider")
                .appendPath(requested.getName())
                .build();
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public String getType(Uri uri) {
        if (uri != null && uri.getPathSegments().size() > 1 && "download".equals(uri.getPathSegments().get(0))) {
            String name = uri.getLastPathSegment();
            String ext = MimeTypeMap.getFileExtensionFromUrl(name == null ? "" : name);
            String type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
            return type == null ? "application/octet-stream" : type;
        }
        return "image/jpeg";
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        File file = resolveFile(uri);
        int accessMode;
        if ("r".equals(mode)) {
            accessMode = ParcelFileDescriptor.MODE_READ_ONLY;
        } else if ("w".equals(mode) || "wt".equals(mode)) {
            accessMode = ParcelFileDescriptor.MODE_WRITE_ONLY
                    | ParcelFileDescriptor.MODE_CREATE
                    | ParcelFileDescriptor.MODE_TRUNCATE;
        } else if ("rw".equals(mode) || "rwt".equals(mode)) {
            accessMode = ParcelFileDescriptor.MODE_READ_WRITE
                    | ParcelFileDescriptor.MODE_CREATE;
            if ("rwt".equals(mode)) accessMode |= ParcelFileDescriptor.MODE_TRUNCATE;
        } else {
            throw new FileNotFoundException("Mode file tidak didukung: " + mode);
        }
        return ParcelFileDescriptor.open(file, accessMode);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        File file;
        try {
            file = resolveFile(uri);
        } catch (FileNotFoundException error) {
            return null;
        }
        String[] columns = projection == null
                ? new String[] { OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE }
                : projection;
        MatrixCursor cursor = new MatrixCursor(columns, 1);
        MatrixCursor.RowBuilder row = cursor.newRow();
        for (String column : columns) {
            if (OpenableColumns.DISPLAY_NAME.equals(column)) row.add(file.getName());
            else if (OpenableColumns.SIZE.equals(column)) row.add(file.length());
            else row.add(null);
        }
        return cursor;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException("Insert tidak didukung");
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        try {
            return resolveFile(uri).delete() ? 1 : 0;
        } catch (FileNotFoundException error) {
            return 0;
        }
    }

    private File resolveFile(Uri uri) throws FileNotFoundException {
        if (uri == null || uri.getLastPathSegment() == null) {
            throw new FileNotFoundException("URI file tidak valid");
        }
        try {
            if (uri.getPathSegments().size() > 1 && "download".equals(uri.getPathSegments().get(0))) {
                File allowedDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ICE Download").getCanonicalFile();
                File file = new File(allowedDir, uri.getLastPathSegment()).getCanonicalFile();
                if (!file.getPath().startsWith(allowedDir.getPath() + File.separator)) {
                    throw new FileNotFoundException("Lokasi unduhan tidak diizinkan");
                }
                return file;
            }
            File allowedDir = new File(getContext().getCacheDir(), CACHE_FOLDER).getCanonicalFile();
            File file = new File(allowedDir, uri.getLastPathSegment()).getCanonicalFile();
            if (!file.getPath().startsWith(allowedDir.getPath() + File.separator)) {
                throw new FileNotFoundException("Lokasi foto tidak diizinkan");
            }
            return file;
        } catch (IOException error) {
            throw new FileNotFoundException(error.getMessage());
        }
    }
}
