ICE v2.8.9.1 - HTTPS Otomatis Toggle

Menu titik tiga kini memiliki tombol:
- HTTPS otomatis: ON
- HTTPS otomatis: OFF

ON: alamat HTTP dinaikkan ke HTTPS.
OFF: ICE membiarkan HTTP/HTTPS dan DNS mengikuti jaringan Android/Wi-Fi.
Status tersimpan setelah aplikasi ditutup.

Catatan: Android WebView tidak menyediakan DNS-over-HTTPS per aplikasi seperti Firefox. Tombol ini mengatur HTTPS otomatis pada navigasi ICE, bukan mengubah Private DNS seluruh perangkat.
