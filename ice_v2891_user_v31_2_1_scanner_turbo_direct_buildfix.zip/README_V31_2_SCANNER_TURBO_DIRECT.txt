ICE v2.8.9.1 v31.2 — SCANNER TURBO DIRECT

Perubahan utama:
- Saat scanner website meminta kamera, ICE Turbo terbuka otomatis.
- Setelah QR/barcode terbaca stabil, hasil langsung dikirim ke callback scanner website.
- Tidak ada tombol konfirmasi atau tombol kirim tambahan.
- Jika website mengonfirmasi berhasil, kamera Turbo otomatis tertutup dan kembali ke halaman.
- Tombol Submit/finalisasi halaman tidak ditekan oleh ICE dan tetap manual.
- Jika pengiriman gagal, kamera tetap terbuka agar pengguna dapat mencoba ulang.
- Scanner Turbo yang dibuka manual tetap dapat dipakai terus-menerus untuk beberapa scan.

Alur otomatis:
1. Tekan tombol scanner milik website.
2. ICE Turbo mengambil alih kamera.
3. Arahkan barcode/QR.
4. Kode langsung diproses oleh alur scanner website.
5. Kamera tertutup otomatis dan halaman tampil kembali.
