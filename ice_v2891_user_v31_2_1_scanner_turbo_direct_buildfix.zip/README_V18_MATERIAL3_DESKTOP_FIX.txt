ICE v18
- Menu ICE dirapikan dengan gaya Material 3.
- Mode desktop memakai desktop user-agent, wide viewport, overview mode, dan viewport 1280px.
- Saat mode desktop diubah, halaman dimuat ulang tanpa cache.
