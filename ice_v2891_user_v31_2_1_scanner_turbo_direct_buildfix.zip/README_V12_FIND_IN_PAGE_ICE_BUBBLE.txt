ICE v12
- Gelembung memakai logo aplikasi ICE/ICE 404.
- Tekan lama gelembung untuk membuka menu.
- Menu berisi COPY HU dan Cari di halaman.
- Cari di halaman mendukung hasil berikutnya dan sebelumnya seperti browser.
- Gelembung tetap dapat digeser dan disembunyikan dari menu titik tiga.
