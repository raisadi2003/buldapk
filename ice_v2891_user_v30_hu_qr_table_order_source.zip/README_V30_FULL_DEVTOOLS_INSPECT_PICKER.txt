ICE v2.8.9.1 v30 - Full DevTools + Inspect Picker

Tambahan:
- Full DevTools dibuka dari menu gelembung ICE: "🛠 Full DevTools".
- Tidak menampilkan gelembung DEV kedua.
- 🎯 Inspect Element: tutup panel sementara, lalu tap bagian halaman yang ingin diperiksa.
- Elements: parent/breadcrumb, children, outerHTML, text/value, attributes, data-*, geometry.
- Copy HTML, CSS selector, XPath.
- Styles: inline + computed CSS.
- Console: log/error + JavaScript evaluator.
- Network: fetch/XHR setelah hook aktif.
- Sources, Storage, Cookies, Forms, Scripts, Find.
- HU/QR scan:
  * Split QR: pola MPA-...
  * HU hanya dianggap kandidat jika konteks field/key/attribute benar-benar HU / Handling Unit.
  * Kode record seperti BKLXA10137_M tidak dianggap HU.

Catatan:
- Ini Full DevTools internal ICE, bukan Chrome DevTools Protocol native.
- Request sebelum hook aktif tidak dapat direkonstruksi.
- Mekanisme build/signing lama tetap dipertahankan melalui build_admin.sh / build_user.sh.
