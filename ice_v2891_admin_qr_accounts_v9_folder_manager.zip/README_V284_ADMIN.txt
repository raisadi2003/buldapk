ICE Inject Admin v2.8.4

- Build admin tanpa key/login.
- Package terpisah: com.mimar.iceinject.admin, sehingga bisa dipasang berdampingan dengan versi user.
- Nama aplikasi: ICE Inject Admin.
