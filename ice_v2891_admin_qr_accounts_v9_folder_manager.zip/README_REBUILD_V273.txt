ICE Inject v2.7.3 - rebuilt source fix license

Yang difix:
1. APK tidak lagi wajib menerima callback iceinject://activated dari halaman web.
2. Setelah aktivasi sukses di WebView, APK cek langsung ke server:
   /check-app.php?device_id=ANDROID_ID
3. Jika server balas ok=1 / valid=true / active=true, APK menyimpan status aktif dan membuka browser.
4. Saat buka ulang, APK bisa cek hanya dengan device_id.
5. Tanggal expired format MariaDB seperti 2026-07-10 04:25:35 sudah bisa dibaca.

Catatan build:
- Source ini default USER build: ADMIN_BUILD=false.
- Jika mau admin build tanpa lisensi, ubah ADMIN_BUILD=true dan label aplikasi menjadi ICE Inject Admin.
- Script build_admin.sh hanya nama lama, output sudah diubah menjadi ice_v273_user.apk.
