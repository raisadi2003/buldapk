package com.mimar.iceinject;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.GradientDrawable;
import android.hardware.Camera;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.RGBLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressWarnings("deprecation")
public class MultiPhotoCameraActivity extends Activity implements SurfaceHolder.Callback {
    public static final String ACTION_RESULT = "com.mimar.iceinject.MULTI_PHOTO_RESULT";
    public static final String ACTION_FEEDBACK = "com.mimar.iceinject.MULTI_PHOTO_FEEDBACK";
    public static final String EXTRA_KIND = "kind";
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_ADDED = "added";
    public static final String EXTRA_QUEUE_SIZE = "queue_size";
    public static final String EXTRA_MODE = "mode";
    public static final String MODE_QUEUE = "queue";
    public static final String MODE_SINGLE = "single";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService decodeExecutor = Executors.newFixedThreadPool(2);
    private final AtomicInteger pendingDecodes = new AtomicInteger(0);
    private final Set<String> sessionSeen = Collections.synchronizedSet(new HashSet<String>());
    private final List<String> successfulCodes = Collections.synchronizedList(new ArrayList<String>());

    private SurfaceView previewView;
    private SurfaceHolder previewHolder;
    private Camera camera;
    private int cameraId = -1;
    private boolean surfaceReady = false;
    private boolean captureInProgress = false;
    private boolean finishWhenIdle = false;
    private boolean receiverRegistered = false;
    private boolean singleMode = false;
    private boolean singleResultReady = false;

    private TextView statusText;
    private TextView countText;
    private Button captureButton;
    private Button flashButton;
    private Button doneButton;
    private boolean flashEnabled = false;

    private int addedCount = 0;
    private int duplicateCount = 0;
    private int failedCount = 0;

    private final BroadcastReceiver feedbackReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null || !ACTION_FEEDBACK.equals(intent.getAction())) return;
            final String code = safe(intent.getStringExtra(EXTRA_CODE));
            final boolean added = intent.getBooleanExtra(EXTRA_ADDED, false);
            final int queueSize = intent.getIntExtra(EXTRA_QUEUE_SIZE, 0);
            if (added) {
                addedCount++;
                showStatus("✓ Masuk antrean: " + code + "\nTotal antrean " + queueSize, true);
            } else {
                duplicateCount++;
                showStatus("Duplikat dilewati: " + code + "\nTotal antrean " + queueSize, false);
            }
            updateCounts();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        singleMode = MODE_SINGLE.equals(getIntent() == null
                ? "" : getIntent().getStringExtra(EXTRA_MODE));

        if (Build.VERSION.SDK_INT >= 23
                && checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Izin kamera belum diberikan", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        if (!singleMode) registerFeedbackReceiver();
        buildUi();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new SurfaceView(this);
        previewHolder = previewView.getHolder();
        previewHolder.addCallback(this);
        root.addView(previewView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView guide = new TextView(this);
        guide.setText(singleMode
                ? "Arahkan QR ke kamera lalu tekan JEPRET\nHasil yang terbaca akan ditampilkan"
                : "Arahkan QR ke kamera lalu tekan JEPRET\nKamera tetap terbuka setelah foto");
        guide.setTextColor(Color.WHITE);
        guide.setTextSize(15);
        guide.setGravity(Gravity.CENTER);
        guide.setPadding(dp(14), dp(10), dp(14), dp(10));
        guide.setBackground(rounded(Color.argb(205, 15, 23, 42), dp(14)));
        FrameLayout.LayoutParams guideParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP);
        guideParams.setMargins(dp(14), dp(18), dp(14), 0);
        root.addView(guide, guideParams);

        statusText = new TextView(this);
        statusText.setText("Siap menjepret");
        statusText.setTextColor(Color.WHITE);
        statusText.setTextSize(15);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(14), dp(10), dp(14), dp(10));
        statusText.setBackground(rounded(Color.argb(220, 30, 41, 59), dp(14)));
        FrameLayout.LayoutParams statusParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        statusParams.setMargins(dp(14), 0, dp(14), dp(126));
        root.addView(statusText, statusParams);

        countText = new TextView(this);
        countText.setTextColor(Color.WHITE);
        countText.setTextSize(14);
        countText.setGravity(Gravity.CENTER);
        countText.setPadding(dp(10), dp(7), dp(10), dp(7));
        countText.setBackground(rounded(Color.argb(210, 2, 6, 23), dp(12)));
        FrameLayout.LayoutParams countParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.RIGHT);
        countParams.setMargins(0, dp(104), dp(14), 0);
        root.addView(countText, countParams);
        if (singleMode) countText.setVisibility(View.GONE);
        updateCounts();

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(12), dp(10), dp(12), dp(14));
        controls.setBackgroundColor(Color.argb(230, 2, 6, 23));

        flashButton = button("FLASH", Color.rgb(71, 85, 105));
        flashButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleFlash();
            }
        });
        controls.addView(flashButton, new LinearLayout.LayoutParams(0, dp(58), 0.8f));

        captureButton = button("JEPRET", Color.rgb(124, 58, 237));
        captureButton.setTextSize(19);
        captureButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePhoto();
            }
        });
        LinearLayout.LayoutParams captureParams = new LinearLayout.LayoutParams(0, dp(68), 1.45f);
        captureParams.setMargins(dp(10), 0, dp(10), 0);
        controls.addView(captureButton, captureParams);

        doneButton = button(singleMode ? "BATAL" : "SELESAI", Color.rgb(22, 163, 74));
        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAfterPending();
            }
        });
        controls.addView(doneButton, new LinearLayout.LayoutParams(0, dp(58), 0.9f));

        FrameLayout.LayoutParams controlParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        root.addView(controls, controlParams);

        setContentView(root);
    }

    private Button button(String text, int color) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextColor(Color.WHITE);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(rounded(color, dp(14)));
        return button;
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(radius);
        return shape;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (surfaceReady && camera == null) openCamera();
    }

    @Override
    protected void onPause() {
        releaseCamera();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        releaseCamera();
        if (receiverRegistered) {
            try { unregisterReceiver(feedbackReceiver); } catch (Throwable ignored) {}
            receiverRegistered = false;
        }
        decodeExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        surfaceReady = true;
        openCamera();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (camera == null) return;
        try {
            camera.stopPreview();
        } catch (Throwable ignored) {}
        configureCamera();
        startPreview();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        surfaceReady = false;
        releaseCamera();
    }

    private void openCamera() {
        if (!surfaceReady || camera != null || isFinishing()) return;
        try {
            cameraId = findBackCamera();
            camera = cameraId >= 0 ? Camera.open(cameraId) : Camera.open();
            configureCamera();
            camera.setPreviewDisplay(previewHolder);
            startPreview();
            showStatus(singleMode
                    ? "Siap. Jepret satu QR."
                    : "Siap. Jepret QR satu per satu.", false);
        } catch (Throwable error) {
            releaseCamera();
            showStatus("Kamera gagal dibuka: " + safeError(error), false);
            Toast.makeText(this, "Kamera gagal dibuka", Toast.LENGTH_LONG).show();
        }
    }

    private int findBackCamera() {
        try {
            int count = Camera.getNumberOfCameras();
            Camera.CameraInfo info = new Camera.CameraInfo();
            for (int i = 0; i < count; i++) {
                Camera.getCameraInfo(i, info);
                if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) return i;
            }
        } catch (Throwable ignored) {}
        return -1;
    }

    private void configureCamera() {
        if (camera == null) return;
        try {
            Camera.Parameters parameters = camera.getParameters();

            List<String> focusModes = parameters.getSupportedFocusModes();
            if (focusModes != null) {
                if (focusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                    parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
                } else if (focusModes.contains(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                }
            }

            Camera.Size pictureSize = choosePictureSize(parameters.getSupportedPictureSizes());
            if (pictureSize != null) parameters.setPictureSize(pictureSize.width, pictureSize.height);

            Camera.Size previewSize = choosePreviewSize(parameters.getSupportedPreviewSizes());
            if (previewSize != null) parameters.setPreviewSize(previewSize.width, previewSize.height);

            parameters.setJpegQuality(90);
            parameters.setRotation(calculateJpegRotation());
            applyFlash(parameters);
            camera.setParameters(parameters);
            camera.setDisplayOrientation(calculateDisplayOrientation());
        } catch (Throwable ignored) {
            try { camera.setDisplayOrientation(90); } catch (Throwable ignoredAgain) {}
        }
    }

    private Camera.Size choosePictureSize(List<Camera.Size> sizes) {
        if (sizes == null || sizes.size() == 0) return null;
        Camera.Size best = sizes.get(0);
        long target = 2560L * 1440L;
        long bestDistance = Math.abs((long) best.width * best.height - target);
        for (Camera.Size size : sizes) {
            long area = (long) size.width * size.height;
            if (area < 1600L * 900L) continue;
            long distance = Math.abs(area - target);
            if (distance < bestDistance) {
                best = size;
                bestDistance = distance;
            }
        }
        return best;
    }

    private Camera.Size choosePreviewSize(List<Camera.Size> sizes) {
        if (sizes == null || sizes.size() == 0) return null;
        Camera.Size best = sizes.get(0);
        long target = 1280L * 720L;
        long bestDistance = Math.abs((long) best.width * best.height - target);
        for (Camera.Size size : sizes) {
            long distance = Math.abs((long) size.width * size.height - target);
            if (distance < bestDistance) {
                best = size;
                bestDistance = distance;
            }
        }
        return best;
    }

    private int calculateDisplayOrientation() {
        if (cameraId < 0) return 90;
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(cameraId, info);
        int degrees = rotationDegrees();
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            int result = (info.orientation + degrees) % 360;
            return (360 - result) % 360;
        }
        return (info.orientation - degrees + 360) % 360;
    }

    private int calculateJpegRotation() {
        if (cameraId < 0) return 90;
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(cameraId, info);
        int degrees = rotationDegrees();
        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            return (info.orientation - degrees + 360) % 360;
        }
        return (info.orientation + degrees) % 360;
    }

    private int rotationDegrees() {
        int rotation = getWindowManager().getDefaultDisplay().getRotation();
        if (rotation == Surface.ROTATION_90) return 90;
        if (rotation == Surface.ROTATION_180) return 180;
        if (rotation == Surface.ROTATION_270) return 270;
        return 0;
    }

    private void startPreview() {
        if (camera == null) return;
        try {
            camera.startPreview();
            captureInProgress = false;
            setCaptureEnabled(true);
        } catch (Throwable error) {
            showStatus("Preview kamera gagal", false);
        }
    }

    private void releaseCamera() {
        Camera old = camera;
        camera = null;
        if (old != null) {
            try { old.setPreviewCallback(null); } catch (Throwable ignored) {}
            try { old.stopPreview(); } catch (Throwable ignored) {}
            try { old.release(); } catch (Throwable ignored) {}
        }
        captureInProgress = false;
    }

    private void takePhoto() {
        if (camera == null || captureInProgress || finishWhenIdle) return;
        if (pendingDecodes.get() >= 6) {
            showStatus("Tunggu sebentar, foto sedang dibaca…", false);
            return;
        }
        captureInProgress = true;
        setCaptureEnabled(false);
        showStatus("Menjepret…", false);
        try {
            camera.takePicture(null, null, new Camera.PictureCallback() {
                @Override
                public void onPictureTaken(byte[] data, Camera source) {
                    try { source.startPreview(); } catch (Throwable ignored) {}
                    captureInProgress = false;
                    setCaptureEnabled(!singleMode);
                    if (data == null || data.length == 0) {
                        onDecodeFailed("Hasil foto kosong");
                        return;
                    }
                    pendingDecodes.incrementAndGet();
                    showStatus(singleMode
                            ? "Foto diambil. Sedang membaca QR…"
                            : "Foto diambil. Silakan jepret lagi — foto sebelumnya sedang dibaca…", false);
                    decodePhoto(data);
                }
            });
        } catch (Throwable error) {
            captureInProgress = false;
            setCaptureEnabled(true);
            showStatus("Gagal menjepret: " + safeError(error), false);
            try { camera.startPreview(); } catch (Throwable ignored) {}
        }
    }

    private void decodePhoto(final byte[] jpegData) {
        decodeExecutor.execute(new Runnable() {
            @Override
            public void run() {
                String code = "";
                Bitmap bitmap = null;
                try {
                    bitmap = decodeScaledBitmap(jpegData, 2400);
                    if (bitmap != null) code = decodeBarcodeFromBitmap(bitmap);
                } catch (Throwable ignored) {
                    code = "";
                } finally {
                    if (bitmap != null && !bitmap.isRecycled()) {
                        try { bitmap.recycle(); } catch (Throwable ignored) {}
                    }
                }

                final String result = safe(code).trim();
                if (result.length() == 0) {
                    if (!singleMode) sendFailureBroadcast();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            failedCount++;
                            updateCounts();
                            showStatus("QR gagal dibaca — langsung jepret lagi", false);
                            Toast.makeText(MultiPhotoCameraActivity.this,
                                    "QR tidak terbaca, jepret ulang",
                                    Toast.LENGTH_SHORT).show();
                            setCaptureEnabled(true);
                            finishDecodeUnit();
                        }
                    });
                    return;
                }

                if (!singleMode && !sessionSeen.add(result)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            duplicateCount++;
                            updateCounts();
                            showStatus("Duplikat sesi dilewati: " + result, false);
                            finishDecodeUnit();
                        }
                    });
                    return;
                }

                if (singleMode) {
                    successfulCodes.add(result);
                    singleResultReady = true;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            setCaptureEnabled(false);
                            showStatus("HASIL TERBACA:\n" + result + "\n\nMengirim ke scanner…", true);
                            Toast.makeText(MultiPhotoCameraActivity.this,
                                    "Terbaca: " + result, Toast.LENGTH_LONG).show();
                            Intent singleResult = new Intent();
                            singleResult.putExtra(EXTRA_KIND, "single_code");
                            singleResult.putExtra(EXTRA_CODE, result);
                            setResult(RESULT_OK, singleResult);
                            finishDecodeUnit();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (!isFinishing()) finish();
                                }
                            }, 1800L);
                        }
                    });
                    return;
                }

                successfulCodes.add(result);
                Intent intent = new Intent(ACTION_RESULT);
                intent.setPackage(getPackageName());
                intent.putExtra(EXTRA_KIND, "code");
                intent.putExtra(EXTRA_CODE, result);
                sendBroadcast(intent);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showStatus("QR terbaca. Menambahkan ke antrean…", true);
                        finishDecodeUnit();
                    }
                });
            }
        });
    }

    private void sendFailureBroadcast() {
        Intent intent = new Intent(ACTION_RESULT);
        intent.setPackage(getPackageName());
        intent.putExtra(EXTRA_KIND, "failed");
        sendBroadcast(intent);
    }

    private void finishDecodeUnit() {
        int remaining = pendingDecodes.decrementAndGet();
        if (remaining < 0) pendingDecodes.set(0);
        if (finishWhenIdle && pendingDecodes.get() == 0) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    finishNow();
                }
            }, 250L);
        }
    }

    private Bitmap decodeScaledBitmap(byte[] data, int maxSide) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        int sample = 1;
        while ((bounds.outWidth / sample) > maxSide || (bounds.outHeight / sample) > maxSide) {
            sample *= 2;
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = Math.max(1, sample);
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        return BitmapFactory.decodeByteArray(data, 0, data.length, options);
    }

    private String decodeBarcodeFromBitmap(Bitmap bitmap) throws Exception {
        int[] rotations = new int[] { 0, 90, 180, 270 };
        Exception lastError = null;
        for (int degrees : rotations) {
            Bitmap candidate = degrees == 0 ? bitmap : rotateBitmap(bitmap, degrees);
            try {
                String value = decodeBarcodeCandidate(candidate);
                if (value != null && value.trim().length() > 0) return value.trim();
            } catch (Exception error) {
                lastError = error;
            } finally {
                if (candidate != bitmap && candidate != null && !candidate.isRecycled()) {
                    candidate.recycle();
                }
            }
        }
        if (lastError != null) throw lastError;
        throw NotFoundException.getNotFoundInstance();
    }

    private Bitmap rotateBitmap(Bitmap source, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(source, 0, 0,
                source.getWidth(), source.getHeight(), matrix, true);
    }

    private String decodeBarcodeCandidate(Bitmap bitmap) throws Exception {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int[] pixels = new int[width * height];
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height);
        LuminanceSource source = new RGBLuminanceSource(width, height, pixels);

        EnumMap<DecodeHintType, Object> hints = new EnumMap<DecodeHintType, Object>(DecodeHintType.class);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        hints.put(DecodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Arrays.asList(
                BarcodeFormat.QR_CODE,
                BarcodeFormat.DATA_MATRIX,
                BarcodeFormat.AZTEC,
                BarcodeFormat.PDF_417,
                BarcodeFormat.CODE_128,
                BarcodeFormat.CODE_39,
                BarcodeFormat.EAN_13,
                BarcodeFormat.EAN_8,
                BarcodeFormat.UPC_A,
                BarcodeFormat.UPC_E,
                BarcodeFormat.ITF,
                BarcodeFormat.CODABAR));

        MultiFormatReader reader = new MultiFormatReader();
        reader.setHints(hints);
        try {
            Result result = reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(source)));
            return result == null ? "" : result.getText();
        } catch (NotFoundException first) {
            reader.reset();
            try {
                Result result = reader.decodeWithState(
                        new BinaryBitmap(new GlobalHistogramBinarizer(source)));
                return result == null ? "" : result.getText();
            } catch (NotFoundException second) {
                reader.reset();
                Result result = reader.decodeWithState(
                        new BinaryBitmap(new HybridBinarizer(source.invert())));
                return result == null ? "" : result.getText();
            }
        } finally {
            reader.reset();
        }
    }

    private void toggleFlash() {
        if (camera == null) return;
        try {
            Camera.Parameters parameters = camera.getParameters();
            List<String> modes = parameters.getSupportedFlashModes();
            if (modes == null || !modes.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
                Toast.makeText(this, "Flash tidak didukung kamera ini", Toast.LENGTH_SHORT).show();
                return;
            }
            flashEnabled = !flashEnabled;
            applyFlash(parameters);
            camera.setParameters(parameters);
            flashButton.setText(flashEnabled ? "FLASH ON" : "FLASH");
            flashButton.setBackground(rounded(
                    flashEnabled ? Color.rgb(234, 179, 8) : Color.rgb(71, 85, 105), dp(14)));
        } catch (Throwable error) {
            Toast.makeText(this, "Flash gagal diubah", Toast.LENGTH_SHORT).show();
        }
    }

    private void applyFlash(Camera.Parameters parameters) {
        List<String> modes = parameters.getSupportedFlashModes();
        if (modes == null) return;
        if (flashEnabled && modes.contains(Camera.Parameters.FLASH_MODE_TORCH)) {
            parameters.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
        } else if (modes.contains(Camera.Parameters.FLASH_MODE_OFF)) {
            parameters.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
        }
    }

    private void onDecodeFailed(String message) {
        failedCount++;
        updateCounts();
        if (!singleMode) sendFailureBroadcast();
        showStatus(message + " — jepret lagi", false);
        setCaptureEnabled(true);
    }

    private void setCaptureEnabled(final boolean enabled) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (captureButton != null) {
                    captureButton.setEnabled(enabled && !finishWhenIdle);
                    captureButton.setText(enabled ? "JEPRET" : "...");
                    captureButton.setAlpha(enabled ? 1f : 0.65f);
                }
            }
        });
    }

    private void showStatus(final String message, final boolean success) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (statusText == null) return;
                statusText.setText(message);
                statusText.setBackground(rounded(
                        success ? Color.argb(225, 21, 128, 61) : Color.argb(225, 30, 41, 59),
                        dp(14)));
            }
        });
    }

    private void updateCounts() {
        if (countText == null || singleMode) return;
        countText.setText("Masuk " + addedCount
                + "  •  Duplikat " + duplicateCount
                + "  •  Gagal " + failedCount);
    }

    private void registerFeedbackReceiver() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter(ACTION_FEEDBACK);
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(feedbackReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(feedbackReceiver, filter);
            }
            receiverRegistered = true;
        } catch (Throwable ignored) {}
    }

    private void finishAfterPending() {
        finishWhenIdle = true;
        setCaptureEnabled(false);
        int pending = pendingDecodes.get();
        if (pending > 0) {
            showStatus("Menunggu " + pending + " foto selesai dibaca…", false);
        } else {
            finishNow();
        }
    }

    private void finishNow() {
        if (singleMode) {
            if (!singleResultReady) setResult(RESULT_CANCELED);
            finish();
            return;
        }
        Intent result = new Intent();
        result.putExtra("added", addedCount);
        result.putExtra("duplicates", duplicateCount);
        result.putExtra("failed", failedCount);
        synchronized (successfulCodes) {
            result.putStringArrayListExtra("codes", new ArrayList<String>(successfulCodes));
        }
        setResult(RESULT_OK, result);
        finish();
    }

    @Override
    public void onBackPressed() {
        finishAfterPending();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private static String safe(String value) {
        return value == null ? "" : value;
    }

    private static String safeError(Throwable error) {
        if (error == null) return "tidak diketahui";
        String message = error.getMessage();
        if (message == null || message.trim().length() == 0) {
            message = error.getClass().getSimpleName();
        }
        return message;
    }
}
