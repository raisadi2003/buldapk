ICE Inject v2.8.9.1 User - QR Accounts v8 Folders

Fitur:
- Akun QR tersimpan tetap dikirim melalui jalur scanner manual.
- Bisa membuat banyak folder akun QR.
- Folder bawaan: Akun Utama.
- Akun dapat dipindahkan ke folder lain lewat Edit.
- Contoh folder: Akun Utama, Operator Bagian Lain, Shift Malam.
- Data tersimpan lokal pada aplikasi.
