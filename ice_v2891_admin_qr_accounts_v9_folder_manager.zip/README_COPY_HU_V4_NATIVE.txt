COPY HU v4 Native
- Tombol dibuat oleh UI Android, bukan DOM/Tampermonkey.
- Selalu terlihat setelah refresh dan navigasi operator.
- Tekan tombol untuk membaca ulang HU pada halaman aktif dan menyalin satu kode per baris.
