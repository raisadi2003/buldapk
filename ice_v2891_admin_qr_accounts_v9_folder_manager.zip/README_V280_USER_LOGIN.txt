ICE Inject v2.8.0 USER LOGIN BUILD

Mode baru: username + password, bukan key.

Alur:
1. User wajib login pakai internet/data setiap membuka APK dari awal.
2. Setelah login berhasil, APK bisa dipakai di WiFi perusahaan tanpa internet selama aplikasi masih terbuka.
3. Kalau APK ditutup/proses mati, sesi memori hilang dan harus login ulang pakai internet.
4. Saat APK sedang terbuka dan ada internet, APK cek server berkala. Jika akun dinonaktifkan/dihapus/reset perangkat, APK terkunci saat cek berikutnya.
5. Jika WiFi lokal tanpa internet, APK tidak terkunci selama sesi login masih hidup.

Server yang cocok: ICE Login Server v7.0.
Endpoint APK: /login-app.php dan /check-session.php.
