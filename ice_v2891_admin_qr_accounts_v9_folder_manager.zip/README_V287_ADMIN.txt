ICE Inject Admin v2.8.7

PERBAIKAN JEPRET BANYAK
- Kamera foto banyak sekarang berada di dalam aplikasi dan tetap terbuka sesudah setiap jepretan.
- Hasil QR langsung masuk Antrean QR, tidak dimasukkan ke kolom ketik.
- Jika QR gagal dibaca, notifikasi muncul di layar kamera dan pengguna bisa langsung menjepret lagi.
- Foto diproses dari memori, tidak masuk galeri dan tidak disimpan permanen.
- Preview kamera kembali aktif segera setelah foto diambil, sementara pembacaan QR berjalan di belakang.
- Duplikat dilewati otomatis dan tersedia tombol FLASH.
- Tekan SELESAI atau Kembali untuk menutup kamera.
- Antrean tidak terbuka secara paksa setelah kamera ditutup.

VERSI
- Version code: 27
- Version name: 2.8.7-admin
- Package: com.mimar.iceinject.admin
- Mode admin / ADMIN_BUILD=true.

BUILD
- Jalankan build_admin.sh atau workflow .github/workflows/build-apk.yml.
- Hasil release: ice_v287_admin.apk.
