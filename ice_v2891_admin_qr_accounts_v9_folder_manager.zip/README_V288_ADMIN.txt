ICE Inject ADMIN v2.8.8

Fitur baru:
- Tombol "Kirim 1 dari antrean" berada di panel utama, di luar dialog Antrean QR.
- Setiap ditekan hanya kode paling depan yang dikirim.
- Setelah sukses, kode tersebut dihapus dari antrean dan jumlah sisa diperbarui.
- Kode berikutnya tidak dikirim otomatis; tekan tombol lagi untuk mengirim satu per satu.
- Jika gagal, kode tetap berada di antrean agar dapat dicoba lagi.
- Tombol otomatis nonaktif ketika antrean kosong atau saat proses kirim sedang berlangsung.

Version code: 28
