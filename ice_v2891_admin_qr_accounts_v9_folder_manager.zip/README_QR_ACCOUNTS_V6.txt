ICE Inject v2.8.9.1 - Akun QR Tersimpan (Native)
- Menu titik tiga > Akun QR tersimpan.
- Simpan banyak akun QR dengan nama operator.
- Login, edit, dan hapus akun dari popup native.
- Saat Login dipilih, aplikasi mengisi input QR manual dan mencoba menekan tombol login otomatis.
- Tombol melayang baru tidak ditambahkan.
