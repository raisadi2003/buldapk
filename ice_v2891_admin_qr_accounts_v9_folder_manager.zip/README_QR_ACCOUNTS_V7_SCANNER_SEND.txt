ICE Inject QR Accounts v7

Tombol LOGIN pada Akun QR Tersimpan sekarang mengirim isi QR melalui bridge scanner yang sama dengan fitur Input Keyboard Manual. Tidak lagi mencari kolom input atau tombol login HTML.
