COPY HU v5 NATIVE ONLY
- Hanya satu tombol COPY HU native Android.
- Tombol Tampermonkey/DOM dan injeksi tombol web dihapus.
- Tombol tetap tersedia setelah refresh dan pindah operator.
