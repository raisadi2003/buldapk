COPY HU v3
- Tombol permanen, tidak menunggu deteksi teks halaman.
- Dipasang ulang setiap 500 ms jika halaman SPA menghapus elemen.
- Membaca tabel di dokumen utama dan iframe same-origin.
- Bisa dipakai berkali-kali tanpa refresh.
